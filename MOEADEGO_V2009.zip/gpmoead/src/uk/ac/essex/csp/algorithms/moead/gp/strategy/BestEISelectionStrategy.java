package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.List;

import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;

public class BestEISelectionStrategy extends UtilSelectionStrategy {

	public BestEISelectionStrategy(int number) {
		super(number);
	}

	@Override
	public void computeSelUtil(List<GPSubproblem> subs, SelectionContext context) {
		//init(subs.size());
		for (int i = 0; i < subs.size(); i++) {
			this.prescreenvutil[i] = subs.get(i).currentValue;
		}
	}

	public String getName() {
		return "Best EI Strategy";
	}

}
