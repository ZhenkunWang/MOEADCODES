package uk.ac.essex.csp.algorithms.moead.gp;

import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.DistributionFactory;
import org.apache.commons.math.distribution.NormalDistribution;

import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoeaGenotype;

public class TeSubproblem extends GPSubproblem {

	private native double nativeEIObj2(double fmin, double[] means,
			double[] dev, double[] weight, double[] z);

	// ideal point.
	// private double[] z = { 0, 0 };

	public TeSubproblem(MoeaGenotype genotype) {
		super(genotype);
	}

	@Override
	protected double ei(MoChromosome var) {
		double[] idealpoint = this.genotype.getMultiObjectiveProblem()
				.getIdealPoint();
		GpMOEADConfigurator configuration = (GpMOEADConfigurator) this.genotype
				.getConfiguration();
		boolean appr = configuration.isUsingTEEIApproximation();
		// String stringProperty = configuration
		// .getStringProperty(Property_Tchebycheff_EI_Approximation);
		// boolean appr = Boolean.parseBoolean(stringProperty);

		if (appr) {
			return eiapproximate(var, idealpoint);
		} else {
			return this.nativeEIObj2(this.bestSubproblemObjective,
					var.estimatedObjectiveValue,
					var.estimatedObjectiveDevitation, this.weight, idealpoint);
		}
	}

	@Override
	protected double wei(MoChromosome var) {
		double[] idealpoint = this.genotype.getMultiObjectiveProblem()
				.getIdealPoint();

		double eisearchweight = ((GpMOEAD) this.genotype).getEISearchWeight();

		teDirectEstimate(var, weight, idealpoint);

		if (te_direct_estimation[1] <= 10e-6) {
			return Math.max(0, bestSubproblemObjective
					- te_direct_estimation[0]);
		} else if (Double.isNaN(te_direct_estimation[1])) {
			return -Double.MAX_VALUE;
		}

		double u = (bestSubproblemObjective - te_direct_estimation[0])
				/ te_direct_estimation[1];

		try {
			double d1 = 0;
			if (u > 10)
				d1 = 1;
			else if (u < -10)
				d1 = 0;
			else
				d1 = normalDist.cumulativeProbability(u);
			double d2 = normalDistPdf(u);

			double d3 = eisearchweight * u * d1 + (1 - eisearchweight) * d2;
			double ei = te_direct_estimation[1] * d3;

			// assert e>=0;
			assert !Double.isNaN(ei);
			return ei;
		} catch (MathException e) {
			e.printStackTrace();
			return 0;
		}
	}

	protected double eiapproximate(MoChromosome var, double[] idealpoint) {
		teDirectEstimate(var, weight, idealpoint);
		// System.out.println(Arrays.toString(te_direct_estimation));
		// teDirectEstimate2(var, weight, idealpoint);
		// System.out.println(Arrays.toString(te_direct_estimation));

		if (te_direct_estimation[1] <= 10e-6) {
			return Math.max(0, bestSubproblemObjective
					- te_direct_estimation[0]);
		} else if (Double.isNaN(te_direct_estimation[1])) {
			return -Double.MAX_VALUE;
		}

		double u = (bestSubproblemObjective - te_direct_estimation[0])
				/ te_direct_estimation[1];
		try {
			double d1 = 0;
			if (u > 10)
				d1 = 1;
			else if (u < -10)
				d1 = 0;
			else
				d1 = normalDist.cumulativeProbability(u);
			double d2 = normalDistPdf(u);

			double d3 = 0.5 * u * d1 + (1 - 0.5) * d2;
			double ei = te_direct_estimation[1] * d3;

			// assert e>=0;
			assert !Double.isNaN(ei);
			return ei;
		} catch (MathException e) {
			e.printStackTrace();
			return 0;
		}
	}

	// double[] normalizationweight = new double[2];
	private double[] temp_direct_u = new double[2];
	private double[] temp_direct_s = new double[2];
	private double[] te_direct_estimation = new double[2];

	/**
	 * 
	 * @param estimatedObjectiveValue
	 * @param estimatedObjectiveDevitation
	 * @param weight
	 * @param z
	 * @return
	 */
	public double[] teDirectEstimate(MoChromosome var, double[] weight,
			double[] z) {
		temp_direct_u[0] = weight[0] * (var.estimatedObjectiveValue[0] - z[0]);
		temp_direct_s[0] = weight[0] * var.estimatedObjectiveDevitation[0];

		temp_direct_u[1] = weight[1] * (var.estimatedObjectiveValue[1] - z[1]);
		temp_direct_s[1] = weight[1] * var.estimatedObjectiveDevitation[1];
		if (var.objectDimension == 2) {
			estimate_temp();
			return te_direct_estimation;
		} else if (var.objectDimension == 3) {
			estimate_temp();

			temp_direct_u[0] = te_direct_estimation[0];
			temp_direct_s[0] = te_direct_estimation[1];

			temp_direct_u[1] = weight[2]
					* (var.estimatedObjectiveValue[2] - z[2]);
			temp_direct_s[1] = weight[2] * var.estimatedObjectiveDevitation[2];

			estimate_temp();
			return te_direct_estimation;
		} else
			throw new RuntimeException(
					"The algorithms not support 4 or more objective at the moment.");
	}

	private void estimate_temp() {
		double a = Math.sqrt(temp_direct_s[0] * temp_direct_s[0]
				+ temp_direct_s[1] * temp_direct_s[1]);
		double alpha = (temp_direct_u[0] - temp_direct_u[1]) / a;

		double mean = temp_direct_u[0] * normcdf(alpha);
		mean += temp_direct_u[1] * normcdf(-alpha);
		mean += a * normpdf(alpha);
		te_direct_estimation[0] = mean;

		double std = (temp_direct_u[0] * temp_direct_u[0] + temp_direct_s[0]
				* temp_direct_s[0])
				* normcdf(alpha);
		std += (temp_direct_u[1] * temp_direct_u[1] + temp_direct_s[1]
				* temp_direct_s[1])
				* normcdf(-alpha);
		std += (temp_direct_u[0] + temp_direct_u[1]) * a * normpdf(alpha);

		std -= mean * mean;

		te_direct_estimation[1] = Math.sqrt(std);
	}

	/**
	 * 
	 * @param estimatedObjectiveValue
	 * @param estimatedObjectiveDevitation
	 * @param weight
	 * @param z
	 * @return
	 */
	public double[] teDirectEstimate2(MoChromosome var, double[] weight,
			double[] z) {
		temp_direct_u[0] = weight[0] * (var.estimatedObjectiveValue[0] - z[0]);
		temp_direct_u[1] = weight[1] * (var.estimatedObjectiveValue[1] - z[1]);

		temp_direct_s[0] = weight[0] * var.estimatedObjectiveDevitation[0];
		temp_direct_s[1] = weight[1] * var.estimatedObjectiveDevitation[1];
		if (var.objectDimension == 2) {
			gaussianmax(temp_direct_u, temp_direct_s, te_direct_estimation);
			return te_direct_estimation;
		} else if (var.objectDimension == 3) {
			gaussianmax(temp_direct_u, temp_direct_s, te_direct_estimation);

			temp_direct_u[0] = weight[2]
					* (var.estimatedObjectiveValue[2] - z[2]);
			temp_direct_u[1] = te_direct_estimation[0];

			temp_direct_s[0] = weight[2] * var.estimatedObjectiveDevitation[2];
			temp_direct_s[1] = te_direct_estimation[1];

			gaussianmax(temp_direct_u, temp_direct_s, te_direct_estimation);

			return te_direct_estimation;
		} else {
			throw new RuntimeException(
					"The algorithms not support 4 or more objective at the moment.");
		}
	}

	public static void gaussianmax(double[] mean, double[] std,
			double[] gaussian) {
		double a = Math.sqrt(std[0] * std[0] + std[1] + std[1]);
		double alpha = (mean[0] - mean[1]) / a;

		double m = mean[0] * normcdf(alpha);
		m += mean[1] * normcdf(-alpha);
		m += a * normpdf(alpha);

		double s = (mean[0] * mean[0] + std[0] * std[0]) * normcdf(alpha);
		s += (mean[1] * mean[1] + std[1] * std[1]) * normcdf(-alpha);
		s += (mean[0] + mean[1]) * a * normpdf(alpha);

		s -= m * m;
		gaussian[0] = m;
		gaussian[1] = Math.sqrt(s);
	}

	@Override
	public void objProb(MoChromosome var, double[] result) {
		double[] idealPoint = mop.getIdealPoint();
		double[] ted = teDirectEstimate(var, weight, idealPoint);
		System.arraycopy(ted, 0, result, 0, 2);
	}

	@Override
	public double subobject(MoChromosome var) {
		double max = -Double.MAX_VALUE;

		double[] idealpoint = genotype.getMultiObjectiveProblem()
				.getIdealPoint();

		// double[][] range = theMOP.getRange();

		for (int i = 0; i < weight.length; i++) {
			double d = weight[i] * (var.objectivesValue[i] - idealpoint[i]);
			// normalization.
			// d /= (range[i][1]-range[i][0]);
			if (d > max) {
				max = d;
			}
		}
		return max;
	}

	private static double normcdf(double mu) {
		if (mu > 16)
			return 1;
		else if (mu < -16)
			return 0;
		else
			try {
				return nd.cumulativeProbability(mu);
			} catch (MathException e) {
				e.printStackTrace();
				return 0;
			}
	}

	private static NormalDistribution nd = DistributionFactory.newInstance()
			.createNormalDistribution();

	// private double normpdf(double x, double u, double s) {
	// return Math.exp(-0.5 * ((x - u) / s) * ((x - u) / s))
	// / (Math.sqrt(2 * Math.PI) * s);
	// }

	private static double normpdf(double x) {
		return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
	}

	// public static void main(String[] args) {
	// System.loadLibrary("ego");
	// TeSubproblem subproblem = new TeSubproblem(12);
	// double d = Double.MAX_VALUE;
	// long l = System.currentTimeMillis();
	// // for (int i = 0; i < 10000; i++) {
	// d = subproblem.eiIntegration(5.9996, new double[] { 4.4390, 13.60304 },
	// new double[] { 4.6711, 3.5140 }, new double[] { 0.5, 0.5 },
	// new double[] { 0, 0 });
	// // }
	// System.out
	// .println(d + "Java Time: " + (System.currentTimeMillis() - l));
	//
	// l = System.currentTimeMillis();
	// // for (int i = 0; i < 10000; i++) {
	// d = subproblem.nativeEIObj2(5.9996, new double[] { 4.4390, 13.60304 },
	// new double[] { 4.6711, 3.5140 }, new double[] { 0.5, 0.5 },
	// new double[] { 0, 0 });
	// // }
	// System.out.println(d + "Native Time: "
	// + (System.currentTimeMillis() - l));
	//
	// }

	// private IntegralFun2 ifun2 = new IntegralFun2();
	//
	// private class IntegralFun2 implements IntegralFunction {
	// private double u, s, fmin;
	//
	// private void setParameters(double mu1, double so1, double f) {
	// this.u = mu1;
	// this.s = so1;
	// this.fmin = f;
	// }
	//
	// public double function(double x) {
	// return x * normpdf(x, fmin - u, s);
	// }
	// }
	//
	// private IntegralFun1 ifun1 = new IntegralFun1();
	//
	// private class IntegralFun1 implements IntegralFunction {
	// private double u1, u2, s1, s2, fmin;
	//
	// private void setParameters(double mu1, double mu2, double so1,
	// double so2, double f) {
	// this.u1 = mu1;
	// this.u2 = mu2;
	// this.s1 = so1;
	// this.s2 = so2;
	// this.fmin = f;
	// }
	//
	// public double function(double x) {
	// return x
	// * (partcompute(x, u1, u2, s1, s2, fmin) + partcompute(x,
	// u2, u1, s2, s1, fmin));
	// }
	//
	// private double partcompute(double x, double u1, double u2, double x1,
	// double x2, double fmin) {
	// double mu = (fmin - x - u1) / s1;
	// return normcdf(mu) * normpdf(x, (fmin - u2), s2);
	// };
	// }

	// private double eiIntegration(final double fmin, double[] means,
	// double[] dev, double[] weight, double[] z) {
	// final double u1, u2, s1, s2;
	// double ep = 1e-10;
	// u1 = weight[0] * (means[0] - z[0]);
	// u2 = weight[1] * (means[1] - z[1]);
	// s1 = weight[0] * dev[0];
	// s2 = weight[1] * dev[1];
	//
	// if (s1 < ep && s2 < ep) {
	// return Math.max(Math.max(fmin - u1, fmin - u2), 0);
	// } else if (s1 < ep) {
	// return eiwithzerosigma(fmin, u1, u2, s1, s2);
	// } else if (s2 < ep) {
	// return eiwithzerosigma(fmin, u2, u1, s2, s1);
	// }
	//
	// ifun1.setParameters(u1, u2, s1, s2, fmin);
	// double d = Integration.gaussQuad(ifun1, 0, 10, 100);
	// return d;
	// }
	//
	// private double eiwithzerosigma(double fmin, double u1, double u2,
	// double s1, double s2) {
	// // s1==0.
	// double p1 = 0;
	// if ((fmin - u1) <= 0) {
	// p1 = 0;
	// } else {
	// ifun2.setParameters(u2, s2, fmin);
	// p1 = Integration.gaussQuad(ifun2, 0, 10, 100);
	// }
	//
	// double p2 = (fmin - u1) * normcdf((u1 - u2) / s2);
	// return p1 + p2;
	// }
}
