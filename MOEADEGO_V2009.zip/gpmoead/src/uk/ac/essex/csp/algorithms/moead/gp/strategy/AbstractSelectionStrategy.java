package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.math.random.RandomData;

import uk.ac.essex.csp.algorithms.mo.ea.CMoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;
import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;
import uk.ac.essex.csp.algorithms.moead.gp.Subproblem;

/**
 * This is the super class of the selection strategy provide several facility
 * for filtering the individuals.
 * 
 * @author wliui
 * 
 */
public abstract class AbstractSelectionStrategy implements ISelectionStrategy {

	protected double closeTollerence;
	protected double[] prescreenvutil;
	protected boolean[] filterred;
	protected int selectNumber;

	protected ArrayList<Integer> selectSequence = new ArrayList<Integer>();

	public AbstractSelectionStrategy(int number) {
		this.selectNumber = number;
	}

	protected void init(int size) {
		if (this.prescreenvutil == null)
			this.prescreenvutil = new double[size];

		if (this.filterred == null) {
			this.filterred = new boolean[size];
		} else {
			for (int i = 0; i < filterred.length; i++) {
				filterred[i] = false;
			}
		}
	}

	public abstract void computeSelUtil(List<GPSubproblem> subs,
			SelectionContext context);

	// filter the subproblems that is closing to the already evaluated
	// populations.
	public void closenessFilter(List<GPSubproblem> subs,
			SelectionContext context, double tor) {
		for (int i = 0; i < subs.size(); i++) {
			if (!filterred[i]) {
				if (isClose((CMoChromosome) subs.get(i).getCurrentIndividual(),
						context.EvaluatedPoints, tor))
					filterred[i] = true;
			}
		}
	}

	public List<Integer> getUnfilterredIndex() {
		ArrayList<Integer> arrayList = new ArrayList<Integer>();
		for (int i = 0; i < filterred.length; i++) {
			if (!filterred[i]) {
				arrayList.add(i);
			}
		}
		return arrayList;
	}

	// devide the region by regions.
	public void regionFilter(List<GPSubproblem> subs, SelectionContext context) {
		assert (this.prescreenvutil != null) : "Need to compute the prescreen util first before invoke region filter.";
		assert (subs.size() == context.Popsize);

		for (int i = 0; i < subs.size(); i = i + context.areasize) {
			int startpos = i;
			int endpos = (i + context.areasize);
			if (endpos > subs.size()
					|| (subs.size() - endpos < context.areasize / 2)) {
				endpos = subs.size();
			}

			assert (endpos > startpos) : "in no case endpos less then startpos";
			ArrayList<Integer> indexList = new ArrayList<Integer>();
			for (int j = startpos; j < endpos; j++)
				indexList.add(j);

			int selectedIndex = -1;
			do {
				selectedIndex = tournamentsel(context.randomgenerator,
						this.prescreenvutil, indexList, 2);
				for (int j = 0; j < indexList.size(); j++) {
					if (indexList.get(j) == selectedIndex) {
						indexList.remove(j);
						break;
					}
				}
				if (selectedIndex == -1)
					break;
			} while (filterred[selectedIndex] && indexList.size() > 0);

			// filter all the others except this one in the region.
			for (int j = startpos; j < endpos; j++) {
				if (j != selectedIndex)
					filterred[j] = true;
			}
		}
	}

	// /**
	// *
	// * @param rd
	// * @param prescreenvutil2
	// * @param startpos
	// * @param endpos
	// * @param tournamentsize
	// * @return
	// */
	// public static int tournamentsel(RandomData rd, double[] prescreenvutil2,
	// int startpos, int endpos, int tournamentsize) {
	// int size = endpos - startpos;
	// if (size == 0) {
	// System.out.println("size 0: wrong start and end pos");
	// }
	//
	// int[] perm = null;
	// if (size <= tournamentsize) {
	// perm = new int[size];
	// for (int i = 0; i < perm.length; i++)
	// perm[i] = i;
	// } else {
	// perm = rd.nextPermutation(size, tournamentsize);
	// }
	//
	// // finding the largest index of in the perm.
	// int selected = -1;
	// double value = -Double.MAX_VALUE;
	// for (int i = 0; i < perm.length; i++) {
	// int index = perm[i] + startpos;
	// if (prescreenvutil2[index] > value) {
	// value = prescreenvutil2[index];
	// selected = index;
	// }
	// }
	// assert (selected != -1);
	// return selected;
	// }

	/**
	 * 
	 * @param rd
	 * @param prescreenvutil2
	 * @param startpos
	 * @param endpos
	 * @param tournamentsize
	 * @return
	 */
	public static int tournamentsel(RandomData rd, double[] prescreenvutil2,
			List<Integer> index, int tournamentsize) {
		int size = index.size();
		int[] perm = null;
		if (size <= tournamentsize) {
			perm = new int[size];
			for (int i = 0; i < perm.length; i++)
				perm[i] = i;
		} else {
			perm = rd.nextPermutation(size, tournamentsize);
		}

		// finding the largest index of in the perm.
		int selected = -1;
		double value = -Double.MAX_VALUE;
		for (int i = 0; i < perm.length; i++) {
			int idx = index.get(perm[i]);
			if (prescreenvutil2[idx] > value) {
				value = prescreenvutil2[idx];
				selected = idx;
			}
		}
		assert (selected != -1);
		return selected;
	}

	/**
	 * Determine if the selection is very very close to the already evaluated
	 * points, which is needed to be avoid for the goodness of GP.
	 * 
	 * @param selected
	 * @param context
	 * @return
	 */
	public static <T extends MoChromosome> boolean isClose(T selected,
			List<T> context, double torl) {
		boolean close = false;

		close = false;
		for (int i = 0; i < context.size(); i++) {
			double parameterDistance = selected.parameterDistance(context
					.get(i));
			// If the selection is very close to a existed evaluated point.
			// then it should not be used.
			if (parameterDistance < torl) {
				close = true;
				break;
			}
		}
		return (close);
	}

	public static <T extends Subproblem> boolean isClose(T selected,
			List<T> context, double torl) {
		boolean close = false;

		close = false;
		for (int i = 0; i < context.size(); i++) {
			double parameterDistance = selected.getCurrentIndividual()
					.parameterDistance(context.get(i).getCurrentIndividual());
			// If the selection is very close to a existed evaluated point.
			// then it should not be used.
			if (parameterDistance < torl) {
				close = true;
				break;
			}
		}
		return (close);
	}

	/**
	 * The factory method to return a selection strategy according to a name.
	 * When a new strategy is created, it's should be created here and assigned
	 * a name.
	 * 
	 * 
	 * @param name
	 * @return
	 */
	public static ISelectionStrategy getPrescreenStrategy(String name,
			int number) {
		ISelectionStrategy result = null;
		if (name.equalsIgnoreCase("random"))
			result = new RandomSelectionStrategy(number);
		else if (name.equalsIgnoreCase("crandom"))
			result = new ControlledRandomSelectionStrategy(number);
		else if (name.equalsIgnoreCase("prob")
				|| name.equalsIgnoreCase("probability"))
			result = new ProbablitySelectionStrategy(number);
		else if (name.equalsIgnoreCase("bestei"))
			result = new BestEISelectionStrategy(number);
		else if (name.equalsIgnoreCase("hv"))
			result = new HyperVolumnSelectionStrategy(number);
		else if (name.equalsIgnoreCase("ei"))
			result = new NeighbourEISelectionStrategy(number);
		else
			throw new IllegalArgumentException("Invalid Strategy Name:" + name
					+ " is given");
		return result;
	}

	public static ISelectionStrategy getPrescreenStrategy(String pname) {
		int number = 1;
		String name = pname;
		int indexOf = pname.indexOf(':');
		if (indexOf > 0) {
			name = pname.substring(0, indexOf);
			String numberstring = pname.substring(indexOf + 1);
			number = Integer.parseInt(numberstring);
		}
		return getPrescreenStrategy(name, number);
	}

}
