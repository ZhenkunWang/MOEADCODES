package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.ArrayList;
import java.util.List;

import uk.ac.essex.csp.algorithms.cluster.Cluster;
import uk.ac.essex.csp.algorithms.cluster.DataPoint;
import uk.ac.essex.csp.algorithms.cluster.JCA;
import uk.ac.essex.csp.algorithms.moead.gp.Subproblem;

public class WeightCluster {

	public static <T extends Subproblem> List<List<T>> clusterWeight(
			List<T> subproblems, int k) {
		// prepare the datas.
		DataPoint[] dp = new DataPoint[subproblems.size()];
		for (int i = 0; i < subproblems.size(); i++) {
			dp[i] = new DataPoint();
			Subproblem sub = subproblems.get(i);
			dp[i].reNew(sub.weight, sub);
		}
		int dim = subproblems.get(0).weight.length;

		JCA jca = new JCA(k, 1000, dp, dim);
		jca.startAnalysis();

		List<List<T>> result = new ArrayList<List<T>>();

		for (int i = 0; i < k; i++) {
			Cluster cluster = jca.getCluster(i);
			List<DataPoint> dataPoints = cluster.getDataPoints();
			List<T> region = new ArrayList<T>();
			for (DataPoint dpp : dataPoints) {
				region.add((T) dpp.getSubject());
			}
			result.add(region);
		}
		return result;
	}
}
