package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.List;

import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;

public interface ISelectionStrategy {
	
	public List<GPSubproblem> select(List<GPSubproblem> subproblems, SelectionContext context);
	public String getName();

	
	
}
