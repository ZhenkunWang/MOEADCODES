package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.ArrayList;
import java.util.List;

import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;

public class RandomSelectionStrategy extends AbstractSelectionStrategy {

	public RandomSelectionStrategy(int number) {
		super(number);
	}

	@Override
	public void computeSelUtil(List<GPSubproblem> subs, SelectionContext context) {
	}

	public String getName() {
		return "Random Selection";
	}

	public List<GPSubproblem> select(List<GPSubproblem> subproblems,
			SelectionContext context) {

		ArrayList<GPSubproblem> result = new ArrayList<GPSubproblem>();

		while (result.size() < this.selectNumber) {
			int nextInt = context.randomgenerator.nextInt(0,
					subproblems.size() - 1);
			GPSubproblem subproblem = subproblems.get(nextInt);

			if (!result.contains(subproblem))
				result.add(subproblem);
		}
		return result;
	}
}
