package uk.ac.essex.csp.algorithms.moead.gp;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import uk.ac.essex.csp.algorithms.Sorting;
import uk.ac.essex.csp.algorithms.appro.gp.DpGpApproximatorJNI;
import uk.ac.essex.csp.algorithms.appro.gp.GpApproximatorJNI;
import uk.ac.essex.csp.algorithms.mo.MultiObjectiveProblem;
import uk.ac.essex.csp.algorithms.mo.ea.CMoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.Configurator;
import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoPopulation;
import uk.ac.essex.csp.algorithms.mo.ea.MoeaGenotype;
import uk.ac.essex.csp.algorithms.moead.gp.strategy.ISelectionStrategy;
import uk.ac.essex.csp.algorithms.moead.gp.strategy.SelectionContext;

/**
 * MOEAD combined with a GP model for the multi-objective optimization with
 * black-box expensive functions.
 * 
 * GP or DACE model is build to speed up MOEAD.
 * 
 * <p>
 * This is the baseline implementation, which will use only the most basic
 * settings. However, hotspots has been setup to allow easy extension. The
 * consideration to choose the feature set is to keep the idea as simple as
 * possible, while we still have a fairly good performance.
 * <p>
 * In this implementation, the algorithms use the following settings:
 * <ol>
 * <li>Tow layered population. The whole population is used for MOEA/D, to find
 * the optimal estimated pareto front based on the GP model; while only a
 * portion of the whole population is taking part in the selection competetion
 * for evaluation.
 * <li>From the portion of the selection population, randomly selection is
 * employed in this baseline framework. The selection process is done by the
 * interface PrescreenStrategy.
 * <li>No improvement is done for the newly generated individual by genetic
 * operation.
 * <li>Weight-Sum or Tchebycheff is used in the problem decomposition, It's
 * allowed for selection to use which decomposition method. And by default,
 * Weight-Sum is used only for reason of time.
 * <li>
 * </ol>
 * 
 * 
 * @author Wudong LIU
 * 
 */
public class GpMOEAD extends MoeaGenotype {
	public static final String WeightSumDecomposition = "ws";
	public static final String TechbesheffDecomposition = "te";

	public static final int PBIDecomposition = 102;

	public static final String Property_Default_Filename = "gpmoead.properties";

	// public static int updating_limit = 80;

	// whether log the intermiderate informations.
	boolean logged = true;

	// =====The Parameters of GpMOEAD, and it's default value START=======
	// The population size, also the subproblems size.
	// Be aware that this size may be different from the population size setted
	// as parameter.
	int PopulationSize = 100;

	// The pre-screen Strategy used in the algorithms.
	protected ISelectionStrategy selectStrategy;
	// =====The Parameters of GpMOEAD, and it's default value END=======

	// The global GP approximation evaluator.
	protected GpApproximatorJNI[] estimators;

	// The whole subproblems, as well as the whole population.
	protected List<GPSubproblem> subproblems = new ArrayList<GPSubproblem>();

	// The subproblems chosen for evaluation, it's a subset of the
	// 'subproblems'.
	protected List<GPSubproblem> evalSubProblems = new ArrayList<GPSubproblem>();

	// The sequence of evaluation of the subproblem. the index should be
	// referred
	// to the 'subproblems' list.
	protected List<Integer> evaluationSequence = new ArrayList<Integer>();

	// The set of all the evaluated points.
	protected ArrayList<CMoChromosome> evaluated = new ArrayList<CMoChromosome>();

	// the index for updating.
	protected List<Integer> updatingIndex = new ArrayList<Integer>();

	// the updating criteria.
	public int Updating_Criteria = GPSubproblem.Criteria_EI;

	public GpMOEAD() {
		Configurator configurator = this.getConfiguration();

		configurator.loadDefaultProperties(Property_Default_Filename);

	}

	@Override
	protected Configurator createConfigurator() {
		GpMOEADConfigurator gpMOEADConfigurator = new GpMOEADConfigurator();

		gpMOEADConfigurator.loadDefaultProperties("gpmoead.properties");

		return gpMOEADConfigurator;
	}

	public GpMOEADConfigurator getSelfConfiguration() {
		return (GpMOEADConfigurator) config;
	}

	@Override
	protected void doSolve() {
		initialize();
		this.getEventManager().fireInitFinished(subproblems);

		// How to do it with a parameter?
		String rawProperty = this.getSelfConfiguration().getUpdatingCriteria();

		if (rawProperty != null) {
			if (rawProperty.equalsIgnoreCase("wei")) {
				this.Updating_Criteria = GPSubproblem.Criteria_WEI;
			} else if (rawProperty.equalsIgnoreCase("ei")) {
				this.Updating_Criteria = GPSubproblem.Criteria_EI;
			}
		}
		setUpdateCriteria(this.Updating_Criteria);
		System.out.println("Updating Criteria: " + this.Updating_Criteria
				+ "\n");

		int evals = config.getTotalEvaluation();
		this.ItrCounter = 0;

		while (EvalCounter < evals && (this.stoped == false)) {
			this.getEventManager().fireGenerationBegin(subproblems, null,
					this.ItrCounter);

			System.out.println("Evaluation Iteration" + this.ItrCounter);

			long l = System.currentTimeMillis();
			// MOEAD Iteration on the GP MODEL.
			moeadIter();
			long l2 = System.currentTimeMillis();
			System.out.println("Time for MOEAD in This iteration: " + (l2 - l));

			// MoChromosome chromosome = preScreen();
			//
			// long l3 = System.currentTimeMillis();
			// // System.out.println("Time for PreSCREEN in This iteration:
			// // "+(l3-l2));
			// if (chromosome == null) {
			// System.out
			// .println("Point Selected Generated before, The iteration is
			// wasted and should be rerun");
			// reInitiateMainpop(0);
			// continue;
			// } else {
			// System.out.println("Point Selected: " + chromosome.toString());
			// }
			//
			// System.out.println("Eval Sequence: ");
			// for (int index = 0; index < this.evaluationSequence.size();
			// index++)
			// System.out.print(this.evaluationSequence.get(index) + ", ");
			// System.out.println("Over");
			//
			// evaluate(chromosome);
			// // how?? has to sleep for the evaluate to be finished.

			List<GPSubproblem> preScreenBulk = this.preScreenBulk();

			long l3 = System.currentTimeMillis();
			// System.out.println("Time for PreSCREEN in This iteration:
			// "+(l3-l2));
			if (preScreenBulk.size() == 0) {
				System.out
						.println("Point Selected Generated before, The iteration is wasted and should be rerun");
				reInitiateMainpop(0);
				continue;
			}

			ArrayList<MoChromosome> modelassess = new ArrayList<MoChromosome>();
			for (int idx = 0; idx < preScreenBulk.size(); idx++) {
				GPSubproblem subproblem = preScreenBulk.get(idx);
				this.evaluationSequence.add(subproblem.mainpopIndex);
				MoChromosome currentIndividual = subproblem
						.getCurrentIndividual();
				MoChromosome createChromosome = this.createChromosome();
				currentIndividual.copyTo(createChromosome);
				evaluate(createChromosome);
				modelassess.add(createChromosome);

				System.out.println("Subproblem Selected: "
						+ createChromosome.toString());
				// onlineUpdateModel();
				// preScreenBulk.get(idx).evaluated[EvalCounter-1] = true;
				// preScreenBulk.get(idx).evalcounter++;
			}

			System.out.println("Eval Sequence: ");
			for (int index = 0; index < this.evaluationSequence.size(); index++)
				System.out.print(this.evaluationSequence.get(index) + ", ");
			System.out.println("Over");

			// after the evaluate. assess the model at the moment.
			double ass = assessModel(modelassess);

			// how?? has to sleep for the evaluate to be finished.

			// long l4 = System.currentTimeMillis();
			// System.out.println("Time for Evaluation in This iteration: "
			// + (l4 - l3));

			// if (preScreenBulk.size()==1) {
			// onlineUpdateModel();
			// System.out.println("Online Model Updation");
			// }
			// else {
			updatemodel();
			// System.out.println("Normal Model Updation");
			// }

			long l5 = System.currentTimeMillis();
			System.out.println("Time for MODEL update in This iteration: "
					+ (l5 - l3));

			// finish log the runtime.
			if (this.getConfiguration().doLog()) {
				runtimeoutput();
			}

			this.getEventManager().fireGenerationEnd(subproblems,
					this.ItrCounter);

			reInitiateMainpop(0.01);
			long l6 = System.currentTimeMillis();
			System.out.println("Time for ReInitiateion in This iteration: "
					+ (l6 - l5));

			System.out.println("Evall Iteration: " + EvalCounter
					+ ", Time Used: " + (System.currentTimeMillis() - l));
			// output the runtime.
			System.out.println();

			this.ItrCounter++;
		}
		// Just for test.
		// moeadIter();
		//
	}

	private double assessModel(ArrayList<MoChromosome> modelassess) {
		// caculate the MSE on every objective.
		int size = modelassess.size();
		int dim = this.getMultiObjectiveProblem().getObjectiveSpaceDimension();

		double[] mse = new double[dim];
		double result = 0;
		for (int j = 0; j < dim; j++) {
			for (int i = 0; i < size; i++) {
				MoChromosome moChromosome = modelassess.get(i);
				double d = (moChromosome.estimatedObjectiveValue[j] - moChromosome.objectivesValue[j]);
				mse[j] += d * d;
			}
			mse[j] /= size;
			mse[j] = Math.sqrt(mse[j]);
			result += mse[j];
		}
		System.out.println("MSE for Objective Models: " + Arrays.toString(mse));
		System.out.println("Models Assess Score: " + result);
		return result;
	}

	/**
	 * Reset the algorithms so that it can starting again.
	 */
	@Override
	public void reset() {
		for (GPSubproblem sub : this.subproblems) {
			this.destroyChromosome(sub.getCurrentIndividual());
		}

		this.subproblems.clear();
		this.evalSubProblems.clear();

		this.evaluationSequence.clear();

		for (int i = 0; i < evaluated.size(); i++) {
			this.destroyChromosome(evaluated.get(i));
		}

		this.evaluated.clear();
		// reset the counters.
		super.reset();
	}

	@Override
	public void evaluate(MoChromosome chrom) {
		List<Subproblem> list = new ArrayList<Subproblem>();
		for (GPSubproblem sub : subproblems)
			list.add(sub);

		this.eventManager.fireEvaluationStart(chrom, list, this.EvalCounter);

		super.evaluate(chrom);
		this.evaluated.add((CMoChromosome) chrom);
		updateSubproblemBestValue(chrom);

		// update the ideal point.
		MultiObjectiveProblem mop = this.getMultiObjectiveProblem();
		double[] idealPoint = mop.getIdealPoint();
		for (int j = 0; j < chrom.objectivesValue.length; j++)
			if (chrom.objectivesValue[j] < idealPoint[j])
				idealPoint[j] = chrom.objectivesValue[j] - 1e-3;

		this.eventManager.fireEvaluationEnd(chrom, list, this.EvalCounter);
	}

	protected CMoChromosome GeneticOPDE(int i) {

		// private final double F = 0.5;
		// private final double CR = 1;

		double CR = this.getSelfConfiguration().getDECrossrate();
		double F = this.getSelfConfiguration().getDEF();
		;

		int NeighbourSize = this.getSelfConfiguration().getNeighbourSize();

		int k, l, m;
		do
			k = this.randomData.nextInt(0, NeighbourSize - 1);
		while (k == 0);
		do
			l = this.randomData.nextInt(0, NeighbourSize - 1);
		while (l == k || l == 0);
		do
			m = this.randomData.nextInt(0, NeighbourSize - 1);
		while (m == l || m == k || m == 0);
		GPSubproblem subproblem = subproblems.get(i);

		CMoChromosome chromosome1 = (CMoChromosome) subproblem.neighbours
				.get(k).getCurrentIndividual();
		CMoChromosome chromosome2 = (CMoChromosome) subproblem.neighbours
				.get(l).getCurrentIndividual();
		CMoChromosome chromosome3 = (CMoChromosome) subproblem.neighbours
				.get(m).getCurrentIndividual();

		// generic operation crossover and mutation.
		CMoChromosome offSpring = (CMoChromosome) this.createChromosome();
		CMoChromosome current = (CMoChromosome) subproblem
				.getCurrentIndividual();
		int D = offSpring.realGenes.length;
		double jrandom = Math.floor(Math.random() * D);

		for (int index = 0; index < D; index++) {
			double value = 0;
			if (Math.random() < CR || index == jrandom)
				value = chromosome1.realGenes[index]
						+ F
						* (chromosome2.realGenes[index] - chromosome3.realGenes[index]);
			else
				value = current.realGenes[index];
			// REPAIR.
			double high = offSpring.domainInfo[index][1];
			double low = offSpring.domainInfo[index][0];
			if (value > high)
				value = high;
			else if (value < low)
				value = low;
			offSpring.realGenes[index] = value;
		}

		// GeneraticOperators.realMutation2(offSpring, 1d / this
		// .getMultiObjectiveProblem().getParameterSpaceDimension(), this
		// .getMultiObjectiveProblem().getDomain());

		// using the polynomial mutation.
		double mutationProbablity = this.getSelfConfiguration()
				.getMutationProbablity();
		int mutationDistributionIndex = this.getSelfConfiguration()
				.getMutationDistributionIndex();
		offSpring.mutate(getRandomGenerator(), mutationProbablity);
		return offSpring;
	}

	private double[] evaluateWithModel_result_array = { 0, 0 };

	protected void evaluateWithModel(CMoChromosome chrom) {
		for (int i = 0; i < estimators.length; i++) {
			estimators[i].estimate(chrom.realGenes,
					evaluateWithModel_result_array);
			chrom.estimatedObjectiveValue[i] = evaluateWithModel_result_array[0];
			chrom.estimatedObjectiveDevitation[i] = evaluateWithModel_result_array[1];
		}
	}

	// only used in reInitiateMainpop to avoid memory leak.
	private boolean[] REINI_selected;

	/**
	 * This method reinitiate the mainpop by randomly choose the some to reserve
	 * according to a given ratio, and the others will be resetted to random
	 * values.
	 * 
	 * @param rp
	 *            the ratio to determine how many individual should be reserved
	 *            for the next evaluation.
	 */
	protected void reInitiateMainpop(double rp) {
		if (REINI_selected == null)
			REINI_selected = new boolean[PopulationSize];

		int reserve = (int) (PopulationSize * rp);
		for (int i = 0; i < reserve; i++) {
			int j = -1;
			do {
				j = this.getRandomData().nextInt(0, PopulationSize - 1);
			} while (REINI_selected[j] == true);
			REINI_selected[j] = true;
		}

		for (int i = 0; i < PopulationSize; i++) {
			CMoChromosome chromosome = (CMoChromosome) subproblems.get(i)
					.getCurrentIndividual();
			if (REINI_selected[i] == false) {
				chromosome.randomize(this.getRandomData());
			} else
				REINI_selected[i] = false;

			this.evaluateWithModel(chromosome);
			subproblems.get(i).recomputeCurrentCriteria();
			subproblems.get(i).selected = false;
		}
	}

	/**
	 * Update the model with the newly generated points. However, here the model
	 * are updated from scratch, but not instead graduately, which increase the
	 * training cost. somehow more advanced algorithms can be used instead here.
	 */
	protected void updatemodel() {
		// if (evaluated.size() > 80) return;

		CMoChromosome[] chromosomes = evaluated
				.toArray(new CMoChromosome[evaluated.size()]);
		double[][] datas = new double[chromosomes.length][];
		double[][] values = new double[estimators.length][chromosomes.length];
		for (int i = 0; i < datas.length; i++) {
			datas[i] = chromosomes[i].realGenes;
			for (int j = 0; j < estimators.length; j++) {
				values[j][i] = chromosomes[i].objectivesValue[j];
			}
		}

		for (int i = 0; i < estimators.length; i++) {
			estimators[i].setData(datas, values[i]);
			long l = System.currentTimeMillis();
			estimators[i].solve();
			System.out.println("***Model native solve time: "
					+ (System.currentTimeMillis() - l));
		}
	}

	// using online updating feature of the approximator.
	protected void onlineUpdateModel() {
		// get last evalated.
		CMoChromosome moChromosome = evaluated.get(evaluated.size() - 1);
		for (int i = 0; i < estimators.length; i++) {
			long l = System.currentTimeMillis();
			estimators[i].onlineSolve(moChromosome.realGenes,
					moChromosome.objectivesValue[i]);
			System.out.println("***Model native solve time: "
					+ (System.currentTimeMillis() - l));
		}
	}

	// using the sum of the expected improvement on all the subproblems.

	public void setPrescreenStrategy(ISelectionStrategy s) {
		this.selectStrategy = s;
	}

	// also, only used in the prescreen process for memory consideration.
	private SelectionContext context = new SelectionContext();

	/**
	 * Prescreen the population from the EvalSubproblems using the given
	 * PrescrenStrategy. However, this method also guarantee the selection
	 * result is not conflicting with the point that evaluated before.
	 * Otherwise, null value is returned.
	 * 
	 * @return
	 */
	// private MoChromosome preScreen() {
	// // update the context.
	// context.TotalNumberofEvaluation = config.getTotalEvaluation();
	// context.EvalCounter = this.EvalCounter;
	//
	// context.Popsize = this.subproblems.size();
	// context.EvaluatedPoints = this.evaluated;
	// context.randomgenerator = this.randomData;
	// context.evaluationSequence = this.evaluationSequence;
	// context.allSubproblems = this.subproblems;
	//
	// int regionsize = this.getSelfConfiguration().getRegionSize();
	//
	// context.areasize = regionsize;
	// context.config = this.getSelfConfiguration();
	//
	// // int[] selectedSroting = this.selectStrategy.prescreen(
	// // this.evalSubProblems, context);
	//
	// // using not fixed evalsubproblems.
	// /*
	// * this.evalSubProblems.clear(); for (int i = 0; i <
	// * this.subproblems.size(); i = i + regionsize) { int startpos = i; int
	// * endpos = i + regionsize - 1; if (endpos > subproblems.size() - 1)
	// * endpos = subproblems.size() - 1;
	// *
	// * if (startpos == endpos) break; // select one from startpos and
	// * endpos. randomly? or what? // a simple toturment select. randomly
	// * select two and then select // the best on EI. int sel1 =
	// * this.randomData.nextInt(startpos, endpos); int sel2 =
	// * this.randomData.nextInt(startpos, endpos); // TODO why should i use
	// * current value here to be used as the // selection // value???
	// * GPSubproblem subproblem1 = subproblems.get(sel1); GPSubproblem
	// * subproblem2 = subproblems.get(sel2); if (subproblem1.currentValue >
	// * subproblem2.currentValue) evalSubProblems.add(subproblem1); else
	// * evalSubProblems.add(subproblem2); } context.areanumber =
	// * evalSubProblems.size();
	// */
	//
	// /*
	// * DOUBLE[] SELECTEDSROTING = THIS.SELECTSTRATEGY.COMPUTEUTIL(
	// * THIS.EVALSUBPROBLEMS, CONTEXT);
	// */
	//
	// // GPSubproblem selectedC = this.selectStrategy.select(evalSubProblems,
	// // context);
	// GPSubproblem selectedC = this.selectStrategy.select(this.subproblems,
	// context);
	//
	// if (selectedC == null)
	// return null;
	//
	// // output the selection result for log.
	// if (this.getConfiguration().doLog()) {
	// runtimeoutput(selectedC);
	// }
	//
	// int index = subproblems.indexOf(selectedC);
	// this.evaluationSequence.add(index);
	//
	// MoChromosome chromosome = this.createChromosome();
	// selectedC.getCurrentIndividual().copyTo(chromosome);
	// selectedC.evaluated[EvalCounter] = true;
	// selectedC.evalcounter++;
	//
	// for (GPSubproblem sub : subproblems) {
	// sub.criteriaHistory[EvalCounter] = sub.currentValue;
	// }
	//
	// return chromosome;
	// }
	/**
	 * Prescreen the population using the given PrescrenStrategy. However, this
	 * method also guarantee the selection result is not conflicting with the
	 * point that evaluated before. Otherwise, null value is returned.
	 * 
	 * the number indicate how many point is selected in iteration at once for
	 * evaluation.
	 * 
	 * @return
	 */
	private List<GPSubproblem> preScreenBulk() {
		// update the context.
		context.TotalNumberofEvaluation = config.getTotalEvaluation();
		context.EvalCounter = this.EvalCounter;

		context.Popsize = this.subproblems.size();
		context.EvaluatedPoints = this.evaluated;
		context.randomgenerator = this.randomData;
		context.evaluationSequence = this.evaluationSequence;
		context.allSubproblems = this.subproblems;

		int regionsize = this.getSelfConfiguration().getRegionSize();

		context.areasize = regionsize;
		context.config = this.getSelfConfiguration();

		List<GPSubproblem> bulkSelect = this.selectStrategy.select(subproblems,
				context);
		for (GPSubproblem sub : bulkSelect)
			sub.selected = true;

		// output the selection result for log.

		return bulkSelect;
	}

	/**
	 * Output log for an evaluation iteration.
	 * 
	 * @param selectedC
	 */
	private void runtimeoutput() {
		String name = this.getMultiObjectiveProblem().getName();
		String evalfile = name + "_" + runid + "/" + name + "_eva_"
				+ runningtime + "_" + EvalCounter + ".txt";
		String popfile = name + "_" + runid + "/" + name + "_pop_"
				+ runningtime + "_" + EvalCounter + ".txt";
		FileOutputStream fos1 = null;
		FileOutputStream fos2 = null;

		try {
			fos1 = new FileOutputStream(evalfile);

			PrintStream printer = new PrintStream(fos1);
			for (CMoChromosome ind : evaluated) {
				printer.println(ind.vectorString());
			}
			printer.close();

			fos2 = new FileOutputStream(popfile);
			printer = new PrintStream(fos2);
			printer.println();

			int i = 0;

			for (GPSubproblem sub : subproblems) {
				if (sub.selected)
					printer.print(1 + "\t");
				else
					printer.print(0 + "\t");

				this.mop.evaluate(sub.getCurrentIndividual());

				for (int j = 0; j < sub.weight.length; j++) {
					printer.print(sub.weight[j] + "\t");
				}

				for (int j = 0; j < ((CMoChromosome) sub.getCurrentIndividual()).realGenes.length; j++) {
					printer
							.print(((CMoChromosome) sub.getCurrentIndividual()).realGenes[j]
									+ "\t");
				}

				for (int j = 0; j < sub.getCurrentIndividual().objectivesValue.length; j++) {
					printer.print(sub.getCurrentIndividual().objectivesValue[j]
							+ "\t");
					printer
							.print(sub.getCurrentIndividual().estimatedObjectiveValue[j]
									+ "\t");
					printer
							.print(sub.getCurrentIndividual().estimatedObjectiveDevitation[j]
									+ "\t");
				}

				printer.print(sub.currentValue + "\t");
				printer.print(sub.bestSubproblemObjective + "\t");
				printer
						.print((sub.worstSubproblemObjective - sub.bestSubproblemObjective)
								+ "\t");

				// need to compute the real objective with the current
				// individual.just for testing purpose.
				double realobject = sub.subobject(sub.getCurrentIndividual());
				printer.print(realobject + "\t");
				printer
						.print((sub.bestSubproblemObjective - realobject)
								+ "\t");
				printer.println(sub.evalcounter);

				// reset the objective array.
				for (int j = 0; j < sub.getCurrentIndividual().objectivesValue.length; j++)
					sub.getCurrentIndividual().objectivesValue[j] = 0;

				i++;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (fos1 != null)
				try {
					fos1.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			if (fos2 != null)
				try {
					fos2.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}

	/**
	 * The iteration of MOEAD with GP.
	 */
	private void moeadIter() {
		int iterationNumber = 0;
		System.out.print("MOEAD Iteration: ");

		if (this.Updating_Criteria == GPSubproblem.Criteria_WEI) {
			System.out.println("WEI Weight: " + this.getEISearchWeight());
		}

		int totalItr = this.getSelfConfiguration().getSearchIteration();
		while (iterationNumber < totalItr && (this.stoped == false)) {
			System.out.print(iterationNumber + ", ");
			// long starttime = System.currentTimeMillis();
			for (int i = 0; i < PopulationSize; i++) {
				// Subproblem sub = subproblems.get(i);
				//
				CMoChromosome offSpring = GeneticOPDE(i);
				improveOffspring(subproblems.get(i), offSpring);

				this.evaluateWithModel(offSpring);

				// update .
				List<Integer> index = preparingUpdatingIndex(i,
						this.updatingIndex);
				searchingUpdating(offSpring, index);
				// update the archive;
				// updateArchive(offSpring);
				// this.destroyChromosome(offSpring1);
				this.destroyChromosome(offSpring);
			}
			iterationNumber++;
		}
		System.out.println("over");
	}

	protected List<Integer> preparingUpdatingIndex(int index, List<Integer> p) {
		p.clear();
		GPSubproblem subproblem = this.subproblems.get(index);
		int size = subproblem.neighbours.size();
		for (int i = 0; i < size; i++) {
			p.add(subproblem.neighbours.get(i).mainpopIndex);
		}
		return p;
	}

	/**
	 * Improve/Repair the offspring using heuristic or local search. It does
	 * nothing in the baseline framework, but local search is incoorporated into
	 * the framework in the Combined Local/Global Approach.
	 * 
	 * @param offSpring
	 *            the newly generated point by the generic operation.
	 */
	protected void improveOffspring(GPSubproblem subp, MoChromosome offSpring) {
	}

	/**
	 * Initiate GP Model.
	 * 
	 * @param number
	 *            How many point needed for the initial GP training.
	 */
	private void initModel(int number) {
		estimators = new DpGpApproximatorJNI[numObjectives];
		for (int i = 0; i < estimators.length; i++)
			estimators[i] = new DpGpApproximatorJNI(numParameters);

		// MoPopulation population = initPopulation(number);

		MoPopulation population = this.createPopulation(number);
		int pd = this.getMultiObjectiveProblem().getParameterSpaceDimension();
		double[][] domain = this.getMultiObjectiveProblem().getDomain();
		double initDesignScore = PopInitiator.lhsRandomPopulation(population,
				number, pd, domain, this.runningtime);

		// double initDesignScore = PopInitiator.lhsInitPopulation(population,
		// number, pd, domain, this.getRandomGenerator());

		System.out.println("The Random Initial Design Generated with score: "
				+ initDesignScore);

		for (int i = 0; i < population.size(); i++) {
			CMoChromosome chromosome = (CMoChromosome) population
					.getChromosome(i);
			this.evaluate(chromosome);
			for (int j = 0; j < estimators.length; j++) {
				estimators[j].addData(chromosome.realGenes,
						chromosome.objectivesValue[j]);
			}
		}
		for (int j = 0; j < estimators.length; j++)
			estimators[j].solve();
	}

	/**
	 * Update the best values for every subproblems after a new point is
	 * evaluated.
	 * 
	 * @param chromosmoe
	 *            the individual just evaluated.
	 */
	private void updateSubproblemBestValue(MoChromosome chromosmoe) {
		for (GPSubproblem sub : this.subproblems) {
			sub.updateSubproblemObj(chromosmoe, this.EvalCounter);
		}
	}

	// private double cEIWeight() {
	// double eiweight = 0.5;
	// int tt = TotalNumberofEvaluation - NumberofInitialLatin;
	// int curp = EvalCounter - NumberofInitialLatin;
	// return 0.5;
	// }

	/**
	 * This method update the mainpop of the given index. With the new offspring
	 * using in the searching(moead) phase. There is the possibility that only
	 * part of the mainpop is updated, to maintain the diversity of it.
	 * 
	 * @param offSpring
	 * @param P
	 */
	protected void searchingUpdating(MoChromosome offSpring, List<Integer> P) {
		// GPSubproblem sub = this.subproblems.get(i);
		// double wei = cEIWeight();
		for (int j = 0; j < P.size(); j++) {
			int index = P.get(j);
			GPSubproblem subproblem = this.subproblems.get(index);
			subproblem.updateCurrentIndividual(offSpring);
		}
	}

	// Try the weighted Expecting Improvement.
	protected void initSubproblem(int m) {
		// this.subproblems = new ArrayList<GPSubproblem>();
		// this.evalSubProblems = new ArrayList<GPSubproblem>();
		int regionsize = this.getSelfConfiguration().getRegionSize();

		int index = 0;
		for (int i = 0; i <= m; i++) {
			if (numObjectives == 2) {
				double[] weight = new double[2];
				weight[0] = i / (double) m;
				weight[1] = (m - i) / (double) m;
				GPSubproblem subproblem2 = generateSubproblem();
				subproblem2.weight = weight;
				this.subproblems.add(i, subproblem2);
				subproblem2.mainpopIndex = i;

				// if (i % regionsize == 0)
				// this.evalSubProblems.add(subproblem2);
			} else if (numObjectives == 3) {
				
				for (int j = 0; j <= m; j++) {
					if (i + j <= m) {
						int k = m - i - j;
						double[] weight = new double[3];
						weight[0] = i / (double) m;
						weight[1] = j / (double) m;
						weight[2] = k / (double) m;

						GPSubproblem subproblem2 = generateSubproblem();
						subproblem2.weight = weight;

						subproblem2.mainpopIndex = index;
						this.subproblems.add(index, subproblem2);
						index++;

						// if (i % regionsize == 0)
						// this.evalSubProblems.add(subproblem2);
					}
				}
			}
		}

		PopulationSize = this.subproblems.size();
		double[][] distancematrix = new double[PopulationSize][PopulationSize];
		for (int i = 0; i < PopulationSize; i++) {
			distancematrix[i][i] = 0;
			for (int j = i + 1; j < PopulationSize; j++) {
				distancematrix[i][j] = distance(subproblems.get(i).weight,
						subproblems.get(j).weight);
				distancematrix[j][i] = distancematrix[i][j];
			}
		}

		for (int i = 0; i < PopulationSize; i++) {
			int ns = this.getSelfConfiguration().getNeighbourSize();
			int[] index2 = Sorting.sorting(distancematrix[i]);
			GPSubproblem subproblem2 = subproblems.get(i);
			for (int j = 0; j < ns; j++) {
				subproblem2.neighbours.add(j, this.subproblems.get(index2[j]));
			}
		}
	}

	/**
	 * Initialization of the algorithms.
	 */
	protected void initialize() {
		int psize = this.getSelfConfiguration().getPopSize();
		int designsize = this.getSelfConfiguration().getDesignPointSize();

		initSubproblem(psize);
		designsize = this.mop.getParameterSpaceDimension() * 11 - 1;

		initModel(designsize);
		for (GPSubproblem sub : this.subproblems) {
			CMoChromosome chromosome1 = (CMoChromosome) this.createChromosome();
			// MoChromosome chromosome2 = this.createChromosome();
			this.evaluateWithModel(chromosome1);
			sub.initialize(chromosome1);
			// this.evaluateWithModel(chromosome2);
			// sub.initialize(chromosome1, chromosome2);
		}
	}

	public static double normalDistPdf(double x) {
		double part1 = 1d / Math.sqrt(2 * Math.PI);
		double part2 = Math.exp(-1 * x * x / 2);
		return part1 * part2;
	}

	/**
	 * Generate a subproblem according to the setted decomposition method.
	 * 
	 * @return
	 */
	protected GPSubproblem generateSubproblem() {
		GPSubproblem result = null;
		String stringProperty = this.getSelfConfiguration()
				.getDecompositionMethod();
		if (stringProperty.equalsIgnoreCase(WeightSumDecomposition))
			result = new WsSubproblem(this);
		else {
			result = new TeSubproblem(this);
		}
		return result;
	}

	@Override
	public String getName() {
		return "BASE GpMOEAD";
	}

	public void setUpdateCriteria(int i) {
		for (GPSubproblem sub : subproblems) {
			sub.criteria = i;
			sub.recomputeCurrentCriteria();
		}
	}

	public double getEISearchWeight() {
		int i = this.ItrCounter % 5;
		return EISearchWeightCycle[i];
		// TODO
		// should checking the modelling facility then decide
		// int i = this.ItrCounter % 4;
		// if (this.ItrCounter < 20) {
		// return EISearchWeightCycle[i];
		// } else if (this.ItrCounter < 30) {
		// return EISearchWeightCycle[i + 1];
		// } else if (this.ItrCounter < 40) {
		// return EISearchWeightCycle[i + 2];
		// } else if (this.ItrCounter < 50) {
		// return EISearchWeightCycle[i + 3];
		// } else if (this.ItrCounter < 70) {
		// return EISearchWeightCycle[i + 4];
		// } else if (this.ItrCounter < 90) {
		// return EISearchWeightCycle[i + 5];
		// } else
		// return EISearchWeightCycle[i + 6];
	}

	// detailed in paper
	// "On the design of Optimization strategies based on global response
	// surface approximation models".
	private static double[] EISearchWeightCycle = { 0.1, 0.3, 0.5, 0.7, 0.9 };

	@Override
	public String reportResult() {
		// TODO Auto-generated method stub
		return "";
	}

	// public double getEISearchWeight() {
	// int i = this.EvalCounter % 5;
	// return EISearchWeightCycle[i];
	// }

	// private static double[] EISearchWeightCycle = { 0.4, 0.45, 0.5, 0.55, 0.6
	// };

}
