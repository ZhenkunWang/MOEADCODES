package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.List;

import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;

public class NeighbourEISelectionStrategy extends UtilSelectionStrategy {

	public NeighbourEISelectionStrategy(int number) {
		super(number);
	}

	@Override
	public void computeSelUtil(List<GPSubproblem> subs, SelectionContext context) {
		for (int i = 0; i < subs.size(); i++) {
			GPSubproblem sub = subs.get(i);
			int neighboursize = sub.neighbours.size();
			double eisum = 0;
			
			for (int j = 0; j < neighboursize/2; j++) {
				GPSubproblem neighbour = (GPSubproblem) sub.neighbours.get(j);
				eisum += neighbour.criteriaValue(sub.getCurrentIndividual());
			}			
			prescreenvutil[i] = eisum;
		}	
	}

	public String getName() {
		return "Neighbour EI Selection";
	}

}
