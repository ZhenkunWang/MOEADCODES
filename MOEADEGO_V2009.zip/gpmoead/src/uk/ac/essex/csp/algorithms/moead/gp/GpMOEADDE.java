package uk.ac.essex.csp.algorithms.moead.gp;

import java.util.List;

import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;

/**
 * MOEA/D-DE with the GP.
 * 
 * It's an imporved algorithms for handling with Hui's functions.
 * 
 * @author wudong
 * 
 */
public class GpMOEADDE extends GpMOEAD {
	// The total size for updating.
	public int UpdatingSize = 2;

	// The probablity to determine using the neighbour or whole population as
	// the updating index.
	public double NeighbourOrWholeProbablity = 0.1;

	@Override
	protected List<Integer> preparingUpdatingIndex(int index, List<Integer> p) {
		double nextUniform = this.randomData.nextUniform(0, 1);
		if (nextUniform < NeighbourOrWholeProbablity) {
			p.clear();
			for (int i = 0; i < PopulationSize; i++)
				p.add(i);
			return p;
		} else
			return super.preparingUpdatingIndex(index, p);
	}

	/**
	 * The IDEA here. The best value of the current GPSubproblem is always
	 * updated, but the pop itself are not necessary updated. Only part of it,
	 * specified by the UpdateingSize will be updated to maintain the diversity.
	 */
	@Override
	protected void searchingUpdating(MoChromosome offSpring, List<Integer> P) {
		int updatednumber = 0;
		// update the best value of all the pop are updated.
//		Iterator<GPSubproblem> iterator = subproblems.iterator();
//		while (iterator.hasNext()) {
//			GPSubproblem next = iterator.next();
//			next.updateBestIndividual(offSpring);
//		}

		// update the current individual with the updating limit in the P.
		while (updatednumber <= UpdatingSize && !P.isEmpty()) {
			int randomindex = -1;
			if (P.size() == 1)
				randomindex = 0;
			else
				randomindex = randomData.nextInt(0, P.size() - 1);

			int nextInt = P.get(randomindex);

			GPSubproblem neighbour = subproblems.get(nextInt);
			if (neighbour.updateCurrentIndividual(offSpring))
				updatednumber++;
			P.remove(randomindex);
		}
	}

	@Override
	public String getName() {
		return "GpMOEAD With DE Operator and Probablity updating";
	}
}
