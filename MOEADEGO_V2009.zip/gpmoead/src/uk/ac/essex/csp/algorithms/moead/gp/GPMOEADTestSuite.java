package uk.ac.essex.csp.algorithms.moead.gp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;

import uk.ac.essex.csp.algorithms.mo.MultiObjectiveProblem;
import uk.ac.essex.csp.algorithms.mo.ea.AbstractMOP;
import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoPopulation;
import uk.ac.essex.csp.algorithms.moead.gp.strategy.AbstractSelectionStrategy;
import uk.ac.essex.csp.algorithms.moead.gp.strategy.ISelectionStrategy;

/**
 * The test suite class for the GPMOEAD. It test the performance of GPMOEAD on
 * several well known test instances.
 * 
 * It takes several parameters, with the same sequence as:
 * <ol>
 * <li><b>p</b>: the problem needed to be tested.
 * <li><b>d</b>: the dimension of the problem to be tested.
 * <li><b>r</b>: the selection strategies used, which can be 'bestei', 'hv',
 * 'random', following by a comma and a digital to indicate how many points are
 * selected in every iteration. for example, '-rhv:10' means running the
 * algorithms with hypervolumn selection strategies and select 10 points a time
 * for evalution.
 * <li><b>i</b>: the running id of this experiment performed.
 * <li><b>t</b>: how many times the experiment should be performed, default is
 * 10.
 * <li><b>x</b>: in the total times defined by <b>t</b>, this parameter defines
 * the starting index of the experiment.
 * </ol>
 * 
 * <p>
 * a typical running of the program will looks like:
 * 
 * <pre>
 * java -Djava.library.path=. -jar gpmoead.jar -pzdt1 -d8 -rbestei:5 -l -ibestei5
 * </pre>
 * 
 */
public class GPMOEADTestSuite {

	public static void main(String[] args) throws InterruptedException,
			IOException {

		String classPath = System.getProperty("java.library.path", ".");
		System.out.print("library: ");
		System.out.println(classPath);

		System.loadLibrary("gpcpp");

		// String classPath = System.getProperty("java.class.path", ".");
		// System.out.print("classpath: ");
		// System.out.println(classPath);

		GPMOEADTestSuite testSuite = new GPMOEADTestSuite();
		Options options = new Options();
		CommandLine cmd = testSuite.commandLineOptions(options, args);

		MultiObjectiveProblem problem = null;
		GpMOEAD solver = null;
		ISelectionStrategy strategy = null;
		long seed = (long) Math.ceil(Math.random() * 10000);

		int times = 10;

		if (cmd.hasOption('t')) {
			times = Integer.parseInt(cmd.getOptionValue('t'));
		}

		if (cmd.hasOption('p')) {
			String prob = cmd.getOptionValue('p');
			if (cmd.hasOption('d'))
				problem = AbstractMOP.getProblem(prob, Integer.parseInt(cmd
						.getOptionValue('d')));
			else {
				problem = AbstractMOP.getProblem(prob, 0);
			}
		} else {
			System.out
					.println("Problem to be solved must be provided. Please refer to the help instruction: ");
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("gpmoead", options);
			System.exit(0);
		}

		if (cmd.hasOption('a')) {
			solver = getSolver(cmd.getOptionValue('a'));
		} else {
			solver = getSolver("baseline");
			System.out.println("# default baseline main algorithms is used: "
					+ solver.getName());
		}

		if (cmd.hasOption('r')) { // parse the selection strategy name.
			String optionValue = cmd.getOptionValue('r');
			strategy = AbstractSelectionStrategy
					.getPrescreenStrategy(optionValue);
		} else {
			strategy = AbstractSelectionStrategy.getPrescreenStrategy(
					"randome", 1);
			System.out.println("# default prescreen algorithms is used: "
					+ strategy.getName());
		}
		solver.setPrescreenStrategy(strategy);

		if (cmd.hasOption('i')) {
			solver.runid = cmd.getOptionValue('i');
		} else {
			long currentTimeMillis = System.currentTimeMillis();
			String string = Long.toString(currentTimeMillis);
			solver.runid = string.substring(string.length() - 7, string
					.length() - 3);
			System.out.println("# rundom runid is generated: " + solver.runid);
		}

		if (cmd.hasOption("default-Propertyfile")) {
			String file = cmd.getOptionValue("default-Propertyfile");
			solver.getConfiguration().loadDefaultProperties(file);
			System.out.println("# a default propertyfile is loaded: " + file);
		}

		if (cmd.hasOption('f')) {
			String file = cmd.getOptionValue('f');
			solver.getConfiguration().addProperties(file);
			System.out.println("# a problem specific propertyfile is loaded: "
					+ file);
		} else {
			File file = new File(problem.getName().toLowerCase()
					+ ".properties");
			if (file.exists()) {
				solver.getConfiguration().addProperties(file.getName());
				System.out
						.println("# a problem specific propertyfile is loaded: "
								+ file.getName());
			}
		}

		if (cmd.hasOption('l')) {
			// solver.logged = false;
			solver.getConfiguration().setDoLog(true);
		} else {
			solver.getConfiguration().setDoLog(false);
		}

		if (cmd.hasOption('s')) {
			seed = Long.parseLong(cmd.getOptionValue('s'));
		} else {
			System.out.println("# a random seed is used: " + seed);
		}
		solver.getConfiguration().setRandomSeed(seed);

		int startindex = 0;
		if (cmd.hasOption('x')) {
			startindex = Integer.parseInt(cmd.getOptionValue('x'));
			System.out.println("# starting index: " + startindex);
		}

		if (cmd.hasOption('D')) {
			String[] optionValues = cmd.getOptionValues('D');
			System.out.println("# additional parameter setting is specified");
			for (int k = 0; k < optionValues.length; k = k + 2) {
				System.out.print(optionValues[k] + "=" + optionValues[k + 1]
						+ "; ");
				solver.getConfiguration().addProperty(optionValues[k],
						optionValues[k + 1]);
			}
			System.out.println();
		}

		// Create the directory problemName;
		String directoryName = problem.getName() + "_" + solver.runid;
		File file = new File(directoryName);
		// if (file.exists() && file.isDirectory()) {
		// deleteDirectory(file);
		// }
		file.mkdir();

		for (int i = 0; i < times; i++) {
			int runtime = i + startindex;
			solver.runningtime = runtime;

			seed = runtime + seed;
			solver.reSeedRandom(seed);

			testSuite.recordParameters(directoryName, problem, seed, strategy,
					solver);

			System.out
					.println("=================================================");
			System.out.println(problem.getName() + " Soving " + runtime
					+ "-run Started");
			System.out.println("Solver: " + solver.getName());
			System.out.println("Prescreen Strategy: " + strategy.getName());
			solver.getConfiguration().listProperties(System.out);
			System.out.println("Random Seed: " + seed);

			System.out
					.println("=================================================");

			solver.solve(problem);
			System.gc();

			String filename = directoryName + "/" + problem.getName() + "_run_"
					+ runtime + ".txt";

			try {
				FileOutputStream stream = new FileOutputStream(filename);
				PrintStream printer = new PrintStream(stream);
				for (MoChromosome ind : solver.evaluated) {
					printer.println(ind.vectorString());
				}
				printer.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

			if (solver.logged) {
				ArrayList<MoChromosome> al = new ArrayList<MoChromosome>();
				for (GPSubproblem sub : solver.subproblems) {
					solver.evaluate(sub.getCurrentIndividual());
					al.add(sub.getCurrentIndividual());
				}

				String popfile = directoryName + "/" + problem.getName()
						+ "_run_" + runtime + "_fpop.txt";
				MoPopulation.writeToFile(al, popfile);
			}

			System.out
					.println("=================================================");
			System.out.println(problem.getName() + " Solving " + runtime
					+ "-run Ended");
			System.out
					.println("=================================================");
			solver.reset();
		}
	}

	private boolean recorded = false;

	private void recordParameters(String dir, MultiObjectiveProblem problem,
			long seed, ISelectionStrategy ps, GpMOEAD impl)
			throws FileNotFoundException {

		if (recorded == true)
			return;
		else
			recorded = true;
		// recording the parameters.
		String params = dir + "/" + "_params.txt";

		PrintStream pss = new PrintStream(new FileOutputStream(params));
		pss.println();
		pss.println("Problem=" + problem.getName());
		pss.println("Solver=" + impl.getName());
		pss.println("SelectionStrategy=" + ps.getName());
		impl.getConfiguration().listProperties(pss);
		pss.close();
	}

	/**
	 * 
	 * @param name
	 * @return
	 */
	private static GpMOEAD getSolver(String name) {
		if (name.equalsIgnoreCase("gpMoeadDE"))
			return new GpMOEADDE();
		else
			return new GpMOEAD();
	}

	/**
	 * 
	 * 
	 * @param path
	 * @return
	 */
	private static boolean deleteDirectory(File path) {
		if (path.exists()) {
			File[] files = path.listFiles();
			for (int i = 0; i < files.length; i++) {
				if (files[i].isDirectory()) {
					deleteDirectory(files[i]);
				} else {
					files[i].delete();
				}
			}
		}
		return (path.delete());
	}

	@SuppressWarnings("static-access")
	private CommandLine commandLineOptions(Options options, String[] args) {

		options.addOption(OptionBuilder.hasArg().withArgName("problemname")
				.withDescription("specify the prolem to be solved.")
				.create('p'));

		options.addOption(OptionBuilder.hasArg().withArgName("runid")
				.withDescription("the run id of current test running.").create(
						'i'));

		options
				.addOption(OptionBuilder
						.hasArg()
						.withArgName("algorithms")
						.withDescription(
								"specify the main algorithms used to solve the problem.")
						.create('a'));

		options
				.addOption(OptionBuilder
						.hasArg()
						.withArgName("selection")
						.withDescription(
								"specify the prescreen strategy used to solve the problem.")
						.create('r'));

		options.addOption(OptionBuilder.hasArg().withArgName("startindex")
				.withDescription("specify the starting index of this run.")
				.create('x'));

		options.addOption(OptionBuilder.hasArg().withArgName("time")
				.withDescription(
						"specify the running times of for the test problem.")
				.create('t'));

		options.addOption("l", false, "specify if the log the whole proces");

		options.addOption(OptionBuilder.hasArg().withType(Integer.class)
				.withArgName("dim").withDescription(
						"specify the the problem dimension, if required")
				.create('d'));

		options.addOption(OptionBuilder.hasArg().withType(Long.class)
				.withArgName("seed").withDescription(
						"the random seed of this test running").create('s'));

		options
				.addOption(OptionBuilder
						.withLongOpt("default-Propertyfile")
						.withDescription(
								"the file for the default parameters, default is gpmoead_default.property.")
						.withValueSeparator('=').hasArg().create());

		options.addOption("f", "problemPropertyFile", true,
				"the file for the problem specific properties.");

		options.addOption("h", "help", false, "print the help information.");

		options.addOption(OptionBuilder.withArgName("property=value").hasArgs()
				.withValueSeparator().withDescription(
						"use value for given property").create('D'));

		CommandLineParser parser = new PosixParser();
		// parse the command line arguments
		try {
			CommandLine cmd = parser.parse(options, args);

			if (cmd.hasOption('h')) {
				HelpFormatter formatter = new HelpFormatter();
				formatter.printHelp("gpmoead", options);
				System.exit(0);
			}
			return cmd;
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}
}
