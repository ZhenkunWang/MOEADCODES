package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.List;

import uk.ac.essex.csp.algorithms.mo.ea.CMoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoeaGenotype;
import uk.ac.essex.csp.algorithms.mo.indicator.HyperVolumnJNI;
import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;

public class HyperVolumnSelectionStrategy extends UtilSelectionStrategy {

	public HyperVolumnSelectionStrategy(int number) {
		super(number);
	}

	@Override
	public void computeSelUtil(List<GPSubproblem> subs, SelectionContext context) {

		// compute the current hypervolumn on the all selected points.
		List<CMoChromosome> evaluatedPoints = context.EvaluatedPoints;
		List<CMoChromosome> nonDomSet = MoeaGenotype.nonDominatingSelect(
				evaluatedPoints, true);
		int size = nonDomSet.size();
		int od = nonDomSet.get(0).objectDimension;
		double[][] front = new double[size + 1][od];
		double[] ref = new double[od];
		for (int i = 0; i < ref.length; i++)
			ref[i] = -Double.MAX_VALUE;

		for (int i = 0; i < size; i++) {
			for (int j = 0; j < od; j++) {
				front[i][j] = nonDomSet.get(i).objectivesValue[j];
				if (front[i][j] > ref[j])
					ref[j] = front[i][j];
			}
		}

		for (int i = 0; i < ref.length; i++) {
			ref[i] += 10;
			front[size][i] = ref[i];
		}

		double oldhv = HyperVolumnJNI.nativeHyperVolumn(front, ref);

		for (int i = 0; i < subs.size(); i++) {
			double[] estimatedOV = subs.get(i).getCurrentIndividual().estimatedObjectiveValue;
			double[] estimatedObjectiveDevitation = subs.get(i).getCurrentIndividual().estimatedObjectiveDevitation;
			for (int j=0;j<od;j++) {
				front[size][j]=estimatedOV[j]+0.5*estimatedObjectiveDevitation[j];
			}
//			System.arraycopy(estimatedOV, 0, front[size], 0, od);
			double newhv = HyperVolumnJNI.nativeHyperVolumn(front, ref);
			this.prescreenvutil[i] = newhv - oldhv;
		}
	}

	public String getName() {
		return "HyperVolumn Selection";
	}

}
