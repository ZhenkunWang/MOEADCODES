package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.ArrayList;
import java.util.List;

import uk.ac.essex.csp.algorithms.Sorting;
import uk.ac.essex.csp.algorithms.mo.ea.CMoChromosome;
import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;

/**
 * The default implementation for Prescreen with random selection.
 * 
 * @author Wudong
 * 
 */
public abstract class PrescreenStrategy {
	protected double[] prescreenvutil;

	/**
	 * Compute the utility of the list of subproblems for the purpose of
	 * selection. The utility is the larger, the better.
	 * 
	 * @param sub
	 * @param context
	 * @return
	 */
	abstract protected void computeUtil(List<GPSubproblem> sub,
			SelectionContext context);

	protected void init(int size) {
		if (this.prescreenvutil == null)
			this.prescreenvutil = new double[size];
	}

	abstract public String getName();

	private List<Integer> list = new ArrayList<Integer>();

	/**
	 * Select the subproblem for evaluation with respect to the computed
	 * utility.
	 * 
	 * @param sub
	 * @param utility
	 * @param context
	 * @return
	 */
	public List<GPSubproblem> bulkSelect(List<GPSubproblem> sub,
			SelectionContext context) {
		List<GPSubproblem> result = new ArrayList<GPSubproblem>();

		this.init(sub.size());
		this.computeUtil(sub, context);

		// divide the whole population by region and choosing the best from
		// according to the util.
		for (int i = 0; i < sub.size(); i = i + context.areasize) {
			int startpos = i;
			int endpos = Math.min(i + context.areasize - 1, sub.size()-1);

			assert (endpos >= startpos):"in no case endpos less then startpos";
			
			// finding the best util. the larger, the better.
			double bestUtil = -Double.MAX_VALUE;
			int selectedIndex = -1;
			for (int j = startpos; j <= endpos; j++) {
				//if it's better and is not close to the existed evaluated points.
				if (this.prescreenvutil[j] > bestUtil
						&& !isClose(sub.get(j), context)) {
					bestUtil = this.prescreenvutil[j];
					selectedIndex = j;
				}
			}
			assert (selectedIndex != -1) : "no selection has been done in this region!";

			if (selectedIndex != -1) {
				result.add(sub.get(selectedIndex));
			}else {
				System.out.println("no selection has been done in this region!");
			}
		}
		return result;
	}

	public GPSubproblem select(List<GPSubproblem> sub, SelectionContext context) {
		this.init(sub.size());
		this.computeUtil(sub, context);

		list.clear();
		for (int i = 0; i < sub.size(); i++)
			list.add(i);

		out: while (!list.isEmpty()) {
			int selectedIndex = -1;

			if (list.size() == 1)
				selectedIndex = list.get(0);
			else
				selectedIndex = nextIndex(list, sub, prescreenvutil, context);

			GPSubproblem subproblem = sub.get(selectedIndex);
			if (isClose(subproblem, context)) {
				int indexOf = list.indexOf(selectedIndex);
				list.remove(indexOf);
				continue out;
			} else {
				// How to do this? if the selected subproblem is in the
				// neighbour of 10 index of the last 10 evaluated subproblem,
				// it should not evaluated in this iteration.

				boolean area_scan = context.config.doRegionScan();

				if (area_scan) {
					int size = context.evaluationSequence.size();
					if (size == 0)
						return subproblem;

					int length = (size < context.areanumber - 1) ? size
							: context.areanumber - 1;
					for (int i = 0; i < length; i++) {
						GPSubproblem subproblem2 = context.allSubproblems
								.get(context.evaluationSequence.get(size - i
										- 1));
						if (subproblem2.neighbourIndex(subproblem) < context.areasize) {
							// in the same area, should be removed.
							int indexOf = list.indexOf(selectedIndex);
							list.remove(indexOf);
							continue out;
						}
					}
				}
				return subproblem;
			}
		}
		return null;
	}

	/**
	 * Determine if the selection is very very close to the already evaluated
	 * points, which is needed to be avoid for the goodness of GP.
	 * 
	 * @param selected
	 * @param context
	 * @return
	 */
	protected boolean isClose(GPSubproblem selected, SelectionContext context) {
		boolean close = false;
		List<CMoChromosome> evaluated = context.EvaluatedPoints;

		close = false;
		for (int i = 0; i < evaluated.size(); i++) {
			double parameterDistance = selected.getCurrentIndividual()
					.parameterDistance(evaluated.get(i));
			// If the selection is very close to a existed evaluated point.
			// then it should not be used.
			if (parameterDistance < 1e-5) {
				close = true;
				break;
			}
		}
		return (close);
	}

	private List<Integer> newselect = new ArrayList<Integer>();

	/**
	 * Determine which subproblem should be selected according to their computed
	 * utility. To be noted that, not all the sub is available for select in
	 * this function. They may have been removed for the sake of closeness. Thus
	 * only the GPSubproblem whose index is listed in theList, should be
	 * considered for the selection.
	 * 
	 * @param theList
	 *            the list of index of the subproblem which should be selected
	 *            from.
	 * @param sub
	 *            all the subproblems.
	 * @param utility
	 *            the utility computed for every subproblem for the purpose of
	 *            selection
	 * @param context
	 *            the selection context
	 * @return the index of the subproblem selected.
	 */
	private int nextIndex(List<Integer> theList, List<GPSubproblem> sub,
			double[] utility, SelectionContext context) {
		// the tournament selection can be used here.
		int[] sortingIndex = Sorting.sorting(utility);
		newselect.clear();

		for (int i = 0; i < sortingIndex.length; i++) {
			if (theList.contains(sortingIndex[i]))
				newselect.add(sortingIndex[i]);
		}

		int newsize = newselect.size();
		int result = -1;

		if (newsize < 2) { // the tournament size is set to be 4 here.
			result = context.randomgenerator.nextInt(0, newsize - 1);
		} else {
			result = context.randomgenerator.nextInt(0, 1);
		}

		return newselect.get(result);
	}

	/**
	 * The factory method to return a selection strategy according to a name.
	 * When a new strategy is created, it's should be created here and assigned
	 * a name.
	 * 
	 * 
	 * @param name
	 * @return
	 */
	public static PrescreenStrategy getPrescreenStrategy(String name) {
		PrescreenStrategy result = null;
		if (name.equalsIgnoreCase("NeighbourHistory"))
			result = new NeighbourHistoryStrategy();
		else
			throw new IllegalArgumentException("Invalid Strategy Name is given");
		return result;
	}
}
