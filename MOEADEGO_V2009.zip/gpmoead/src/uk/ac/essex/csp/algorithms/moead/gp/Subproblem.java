package uk.ac.essex.csp.algorithms.moead.gp;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import uk.ac.essex.csp.algorithms.mo.Scalarization;
import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoeaGenotype;

/**
 * 
 * The scalarization of a multiobjective problem.
 * 
 * @author wudong
 * 
 */
public class Subproblem extends Scalarization {

	public static int ScalarizationMethod_WS = 101;
	public static int ScalarizationMethod_TE = 102;
	public static int ScalarizationMethod_TE_2 = 103;
	public static int ScalarizationMethod_PS = 104;

	private int scalarizationMethod = ScalarizationMethod_TE;

	/**
	 * The index of this subproblem in the main population.
	 */
	public int mainpopIndex;

	/**
	 * The direction weight of this subproblem.
	 */
	public double[] weight;

	/**
	 * The reference of this subproblem.
	 */
	public double[] reference;

	/**
	 * The current individual of this subproblem.
	 */
	protected MoChromosome currentIndividual;

	public int suvrivalGeneration = 0;

	/**
	 * The current objective value of this subproblem computed by the current
	 * individual.
	 */
	public double currentValue;

	// public int eaUpdatingCount;

	public double searchSelectUtility = 1;

	public boolean searchSelected = false;

	protected MoeaGenotype genotype;

	public double itrImprovement;

	public int updateAttemptCount = 0;

	public double decayRate = 0.95d;
	public double thresholdValue = 0.001d;

	// the adaptive DE F control parameter.
	public double deF = 0.5;
	public double deCR = 1;

	/**
	 * The neighbour of this subproblem.
	 */
	public List<Subproblem> neighbours = new ArrayList<Subproblem>();

	/**
	 * The search population of this subproblem.
	 */
	// public List<Subproblem> searchPopulation = new ArrayList<Subproblem>();
	/**
	 * The cloest subproblem's around this subproblem.
	 */
	public List<Subproblem> adjacentSubs = new ArrayList<Subproblem>();

	/**
	 * The constructor.
	 * 
	 * @param moead
	 */
	public Subproblem(MoeaGenotype moead) {
		this.genotype = moead;
		this.mop = this.genotype.getMultiObjectiveProblem();
		// using the argumented scalarization method.
		this.setScalarizationMethod(Subproblem.ScalarizationMethod_TE_2);
	}

	public MoChromosome getCurrentIndividual() {
		return currentIndividual;
	}

	public void setCurrentIndividual(MoChromosome currentIndividual) {
		this.currentIndividual = currentIndividual;
		this.currentValue = scalarObjective(this.currentIndividual);
	}

	public void setScalarizationMethod(int i) {
		this.scalarizationMethod = i;
	}

	/**
	 * choose which scalarization method to be used in this subproblem.
	 * 
	 * @param chrom
	 * @return
	 */
	public double scalarObjective(MoChromosome chrom) {
		return scalarObjective(chrom.objectivesValue);
	}

	public double scalarObjective(double[] obj) {
		if (this.scalarizationMethod == ScalarizationMethod_WS) {
			return wsScalarObj(obj);
		} else if (this.scalarizationMethod == ScalarizationMethod_TE) {
			return tcheScalarObj(obj);
		} else if (this.scalarizationMethod == ScalarizationMethod_TE_2) {
			return argumentedTcheScalarObj(obj);
		} else {
			return tcheScalarObj(obj);
		}
	}

	/**
	 * scalarization by weighted tchebycheff approach.
	 * 
	 * @param var
	 * @return
	 */
	protected double tcheScalarObj(double[] var) {
		double[] idealPoint = mop.getIdealPoint();
		return techScalarObj(this.weight, idealPoint, var);
	}

	protected double argumentedTcheScalarObj(double[] var) {
		double[] idealPoint = mop.getIdealPoint();
		double techScalarObj = techScalarObj(this.weight, idealPoint, var);
		double ws = wsScalarObj(var);
		return techScalarObj + 0.005 * ws;
	}

	/**
	 * scalarization by weighted sum approach.
	 * 
	 * @param var
	 * @return
	 */
	protected double wsScalarObj(double[] var) {
		return wsScalarObj(this.weight, var);
	}

	public String reportResult() {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		String weightString = Arrays.toString(weight);
		String pString = currentIndividual.getParameterString();
		String objString = Arrays.toString(currentIndividual.objectivesValue);
		pw.print(weightString.substring(1, weightString.length() - 1));
		pw.print("; ");
		pw.print(objString.substring(1, objString.length() - 1));
		pw.print("; " + pString);
		pw.print("; " + this.currentValue);
		pw.print("; " + this.suvrivalGeneration);
		return sw.toString();
	}

	public String reportState() {
		return reportResult();
	}

	@Override
	public String toString() {
		return reportResult();
	}

	// sorting according to dimension.
	public static class SubproblemWeightComparator implements
			Comparator<Subproblem> {
		public int compare(Subproblem arg0, Subproblem arg1) {
			int length = arg0.weight.length;
			for (int i = 0; i < length - 1; i++) {
				if (arg0.weight[i] == arg1.weight[i])
					continue;
				else {
					return arg0.weight[i] > arg1.weight[i] ? 1 : -1;
				}
			}
			return 0;
		}
	}

	public static class SubproblemSearchUtilComparator implements
			Comparator<Subproblem> {
		public int compare(Subproblem arg0, Subproblem arg1) {
			if (arg0.searchSelectUtility == arg1.searchSelectUtility)
				return 0;
			else {
				return arg0.searchSelectUtility > arg1.searchSelectUtility ? 1
						: -1;
			}
		}
	}

	/**
	 * Weighted Sum Scalarization.
	 * 
	 * @param namda
	 * @param obj
	 * @return
	 */
	public static double wsScalarObj(double[] namda, double[] obj) {
		double sum = 0;
		for (int n = 0; n < obj.length; n++) {
			sum += (namda[n]) * obj[n];
		}
		return sum;
	}

	/**
	 * Weighted Tchebycheff Scalarization
	 * 
	 * @param namda
	 *            the direction weight parameter.
	 * @param obj
	 *            the objective of mops.
	 * @param idealpoint
	 *            the reference point.
	 * @return
	 */
	public static double techScalarObj(double[] namda, double[] idealpoint,
			double[] obj) {
		double max_fun = -1 * Double.MAX_VALUE;
		for (int n = 0; n < obj.length; n++) {
			double diff = Math.abs(obj[n] - idealpoint[n]);
			double feval;
			if (namda[n] == 0)
				feval = 0.0000001 * diff;
			else
				feval = diff * namda[n];
			if (feval > max_fun)
				max_fun = feval;
		}
		return max_fun;
	}

	public static SubproblemWeightComparator SubproblemWeightComparatorInstance = new SubproblemWeightComparator();
	public static SubproblemSearchUtilComparator SubproblemSearchComparatorInstance = new SubproblemSearchUtilComparator();

}
