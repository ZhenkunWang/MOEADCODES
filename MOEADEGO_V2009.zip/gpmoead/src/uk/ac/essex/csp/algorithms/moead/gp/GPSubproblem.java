package uk.ac.essex.csp.algorithms.moead.gp;

import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.NormalDistribution;
import org.apache.commons.math.distribution.NormalDistributionImpl;

import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoeaGenotype;

/**
 * The current criteria value is saved in currentValue. The current best
 * subproblem objective is saved in bestSubproblemObjective
 * 
 * @author wudong
 * 
 */
public abstract class GPSubproblem extends Subproblem {

	public static final int Criteria_WEI = 9;
	public static final int Criteria_EI = 10;
	public static final int Criteria_PI = 11;
	public static final int Criteria_LCB = 12;
	public static final int Criteria_M = 13;

	/**
	 * How many time this subproblem has been evaluated.
	 */
	public int evalcounter;
	/**
	 * The evaluation history.
	 */
	public boolean[] evaluated;

	public double[] realImpHistory;

	/**
	 * The criteria value history at each evaluation iteration.
	 */
	public double[] criteriaHistory;

	public int criteria = Criteria_EI;

	public boolean selected;

	/**
	 * The value of the best subproblem objective, i.e., fmin as far as now.
	 */
	public double bestSubproblemObjective = Double.MAX_VALUE;
	public double worstSubproblemObjective = -Double.MAX_VALUE;

	public GPSubproblem(MoeaGenotype genotype) {
		super(genotype);
		int totalNum = genotype.getConfiguration().getTotalEvaluation();
		evaluated = new boolean[totalNum];
		criteriaHistory = new double[totalNum];
		realImpHistory = new double[totalNum];
	}

	@Override
	public String toString() {
		return currentIndividual.toString() + ", " + currentValue + "\t"
				+ bestSubproblemObjective + "\t " + evalcounter;
	}

	public boolean isSelected(int evalIteration) {
		return this.evaluated[evalIteration - 1];
	}

	public boolean isJustSelected() {
		return this.evaluated[genotype.EvalCounter - 1];
	}

	/**
	 * Intialize the subproblem.
	 * 
	 * @param chrom
	 */
	protected void initialize(MoChromosome chromosome1) {
		this.currentIndividual = chromosome1;
		// this.currentBestIndividual = chromosome2;
		this.currentValue = criteriaValue(chromosome1);
		// this.currentValue = v1;

		// double v2 = criteriaValue(chromosome2);
		// if (v1 > v2) {
		// this.currentValue = v1;
		// this.currentBestValue = v1;
		// this.currentIndividual.copyTo(currentBestIndividual);
		// } else {
		// this.currentValue = v2;
		// this.currentBestValue = v2;
		// this.currentBestIndividual.copyTo(currentIndividual);
		// }
	}

	/**
	 * The real objective of the subproblem. Here, the default is using
	 * weighted-sum.
	 * 
	 * @param var
	 * @return
	 */
	abstract public double subobject(MoChromosome var);

	abstract public void objProb(MoChromosome var, double[] result);

	public double gerRecentAvgEI(int counter, int back) {
		double r = 0;
		for (int i = 1; i < back + 1; i++) {
			r += criteriaHistory[i];
		}
		return r / back;
	}

	public int getRecentEvalCount(int counter, int back) {
		int r = 0;
		for (int i = 0; i < back; i++) {
			if (counter - i > 0 && evaluated[counter - i - 1])
				r++;
		}
		return r;
	}

	/**
	 * Determine if the index of the given subproblem in this subproblem's
	 * neighbour.
	 * 
	 * @param problem
	 * @return
	 */
	public int neighbourIndex(Subproblem problem) {
		for (int i = 0; i < neighbours.size(); i++) {
			if (neighbours.get(i) == problem)
				return i;
		}
		return Integer.MAX_VALUE;
	}

	/**
	 * When the given chrom is better then the current solution, update the
	 * subprolblem with the given solution and return true. otherwise, do
	 * nothing and return false.
	 * 
	 * @param chrom
	 * @return
	 */
	public boolean updateCurrentIndividual(MoChromosome chrom) {
		double d = criteriaValue(chrom);
		if (d > this.currentValue) {
			chrom.copyTo(currentIndividual);
			this.currentValue = d;
			return true;
		} else
			return false;
	}

	/**
	 * Update with the lasted evaluation information on this subproblem.
	 * 
	 * @param chrom
	 *            the latest evaluated points.
	 * @param evalcounter
	 */
	public void updateSubproblemObj(MoChromosome chrom, int evalcounter) {
		double oldbest = bestSubproblemObjective;
		double v = this.subobject(chrom);
		if (v < bestSubproblemObjective)
			bestSubproblemObjective = v;
		if (v > worstSubproblemObjective)
			worstSubproblemObjective = v;

		if (evalcounter < 0)
			return;
		else if (evalcounter < this.realImpHistory.length)
			this.realImpHistory[evalcounter - 1] = (oldbest - bestSubproblemObjective);
	}

	public void recomputeCurrentCriteria() {
		this.currentValue = this.criteriaValue(this.currentIndividual);
		// this.currentBestValue =
		// this.criteriaValue(this.currentBestIndividual);
	}

	public double criteriaValue(MoChromosome chrom) {
		switch (criteria) {
		case Criteria_EI:
			// double raw = ei(chrom);
			// double span = this.worstSubproblemObjective
			// - this.bestSubproblemObjective;
			// if (span <= 10e-6)
			// return raw;
			// else
			// return raw / span;
			return ei(chrom);
		case Criteria_WEI:
			// double raw = ei(chrom);
			// double span = this.worstSubproblemObjective
			// - this.bestSubproblemObjective;
			// if (span <= 10e-6)
			// return raw;
			// else
			// return raw / span;
			return wei(chrom);
		case Criteria_LCB:
			return lcb(chrom);
		case Criteria_M:
			return mean(chrom);
		case Criteria_PI:
			return poi(chrom);
		default:
			return mean(chrom);
		}
	}

	protected double wei(MoChromosome chrom) {
		return Double.NaN;
	}

	protected double ei(MoChromosome chrom) {
		return Double.NaN;
	};

	protected double poi(MoChromosome chrom) {
		return Double.NaN;
	};

	protected double lcb(MoChromosome chrom) {
		return Double.NaN;
	};

	protected double mean(MoChromosome chrom) {
		return Double.NaN;
	};

	public static NormalDistribution normalDist = new NormalDistributionImpl();

	public static double normalDistPdf(double x) {
		double part1 = 1d / Math.sqrt(2 * Math.PI);
		double part2 = Math.exp(-1 * x * x / 2);
		return part1 * part2;
	}

	public static double origionalEI(double[] subproblem_objective_estimation,
			double min) {
		if (subproblem_objective_estimation[1] <= 10 * Double.MIN_VALUE) {
			return 0;
		} else if (Double.isNaN(subproblem_objective_estimation[1])) {
			return -Double.MAX_VALUE;
		}

		double u = (min - subproblem_objective_estimation[0])
				/ subproblem_objective_estimation[1];
		try {
			double d1 = 0;
			if (u > 10)
				d1 = 1;
			else if (u < -10)
				d1 = 0;
			else
				d1 = normalDist.cumulativeProbability(u);
			double d2 = normalDistPdf(u);

			double d3 = 0.5 * u * d1 + (1 - 0.5) * d2;
			double result = subproblem_objective_estimation[1] * d3;

			// assert result>=0;
			assert !Double.isNaN(result);
			return result;
		} catch (MathException e) {
			e.printStackTrace();
			return 0;
		}
	}
}
