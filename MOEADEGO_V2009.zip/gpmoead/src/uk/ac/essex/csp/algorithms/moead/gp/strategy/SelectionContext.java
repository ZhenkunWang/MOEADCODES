package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.List;

import org.apache.commons.math.random.RandomData;

import uk.ac.essex.csp.algorithms.mo.ea.CMoChromosome;
import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;
import uk.ac.essex.csp.algorithms.moead.gp.GpMOEADConfigurator;

public class SelectionContext {
	public int TotalNumberofEvaluation;
	public int Popsize;
	public int EvalCounter;
	public List<CMoChromosome> EvaluatedPoints;
	public RandomData randomgenerator;
	public List<Integer> evaluationSequence;
	public List<GPSubproblem> allSubproblems;
	public int areasize;
	public int areanumber;
	public GpMOEADConfigurator config;
}
