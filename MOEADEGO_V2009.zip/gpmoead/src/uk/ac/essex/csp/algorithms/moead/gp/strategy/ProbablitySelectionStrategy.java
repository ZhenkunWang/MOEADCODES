package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.List;

import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.NormalDistribution;
import org.apache.commons.math.distribution.NormalDistributionImpl;

import uk.ac.essex.csp.algorithms.mo.ea.CMoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoeaGenotype;
import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;

public class ProbablitySelectionStrategy extends UtilSelectionStrategy {
	
	public ProbablitySelectionStrategy(int number) {
		super(number);
	}

	public String getName() {
		return "Non Domination Probability Selection";
	}

	@Override
	public void computeSelUtil(List<GPSubproblem> subs, SelectionContext context) {
		int designsize = context.config.getDesignPointSize();
		int total = context.TotalNumberofEvaluation;
		int thr = (total - designsize)/2;
		
		if (context.EvalCounter<thr) {
			for (int i=0;i<subs.size();i++) { //random at first.
				prescreenvutil[i] = context.randomgenerator.nextUniform(0, 1);
			}
		}else {
			for (int i = 0; i < subs.size(); i++)
				prescreenvutil[i] = probRank(subs.get(i), subs, context);	
		}
		
	}

	private static double[] prob = new double[2];

	// ranking the subproblem with it's probability to nondominating of the
	// current non-dominating set. the higher, the better.
	public static double probRank(GPSubproblem sub, List<GPSubproblem> subs,
			SelectionContext context) {
		double rank = 0;

		List<CMoChromosome> nondomset = MoeaGenotype.nonDominatingSelect(
				context.EvaluatedPoints, true);
		rank = nonDominatingRank((CMoChromosome) sub.getCurrentIndividual(),
				nondomset);

		return rank;
	}

	/**
	 * The probablity that chrom is non-dominating the non-dominating set list.
	 * 
	 * @param chrom
	 * @param list
	 * @return
	 */
	public static <T extends MoChromosome> double nonDominatingRank(T chrom,
			List<T> list) {
		double result = 1;
		for (T mo : list) {
			dominateProb(chrom, mo, prob);
			//double domP = 1 - prob[0] - prob[1];
			double domP = 1 - prob[1];
			//result *= domP;
			result += domP;
		}
		return result;
	}

	/**
	 * This static function compute the probability that one point dominate
	 * another.
	 * 
	 * @param chrom1
	 * @param chrom2
	 * @return
	 */
	public static void dominateProb(MoChromosome chrom1, MoChromosome chrom2,
			double[] dominateProb) {
		double result1 = 1;
		double result2 = 1;

		for (int i = 0; i < chrom1.objectDimension; i++) {
			double v1 = dominateProb(
					chrom1.evaluated ? chrom1.objectivesValue[i]
							: chrom1.estimatedObjectiveValue[i],
					chrom1.evaluated ? 0.000000001
							: chrom1.estimatedObjectiveDevitation[i],
					chrom2.evaluated ? chrom2.objectivesValue[i]
							: chrom2.estimatedObjectiveValue[i],
					chrom2.evaluated ? 0.000000001
							: chrom2.estimatedObjectiveDevitation[i]);
			double v2 = 1 - v1;
			result1 *= v1;
			result2 *= v2;
		}
		dominateProb[0] = result1; // A dominating B prob.
		dominateProb[1] = result2; // A dominated by B prob.
	}

	/**
	 * This static function compute the probablity that one point A better(in
	 * minimilization sense) than another point B with the estimated gaussian
	 * distribution. The first point has mean u1 and std s1, the second point
	 * has mean u2 and std s2. The probablity that the first point dominate the
	 * second point is returned by this method. P(A>B)
	 * 
	 * @param u1
	 *            the mean of the first point.
	 * @param u2
	 *            the mean of the second point.
	 * @param s1
	 *            the std of the first point.
	 * @param s2
	 *            the std of the second point.
	 * @return the probablity that first point dominate the second point.
	 */
	public static double dominateProb(double u1, double s1, double u2, double s2) {
		// A-B's distribution.
		double m = u1 - u2;
		double s = Math.sqrt(s1 * s1 + s2 * s2);
		NormalDistribution nd = new NormalDistributionImpl(m, s);
		try {
			return nd.cumulativeProbability(0);
		} catch (MathException e) {
			e.printStackTrace();
			return 0;
		}
	}

}
