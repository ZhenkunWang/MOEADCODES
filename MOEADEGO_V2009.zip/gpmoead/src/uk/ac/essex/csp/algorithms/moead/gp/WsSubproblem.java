package uk.ac.essex.csp.algorithms.moead.gp;

import org.apache.commons.math.MathException;

import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoeaGenotype;

/**
 * The weighted-sum decomposition subproblems.
 * 
 * @author wudong
 * 
 */
public class WsSubproblem extends GPSubproblem {

	public WsSubproblem(MoeaGenotype genotype) {
		super(genotype);
	}

	private double[] subproblem_objective_estimation = new double[2];

	@Override
	protected double ei(MoChromosome var) {
		objProb(var, subproblem_objective_estimation);

		if (subproblem_objective_estimation[1] <= 10 * Double.MIN_VALUE) {
			return 0;
		} else if (Double.isNaN(subproblem_objective_estimation[1])) {
			return -Double.MAX_VALUE;
		}

		double u = (bestSubproblemObjective - subproblem_objective_estimation[0])
				/ subproblem_objective_estimation[1];
		try {
			double d1 = 0;
			if (u > 10)
				d1 = 1;
			else if (u < -10)
				d1 = 0;
			else
				d1 = normalDist.cumulativeProbability(u);
			double d2 = normalDistPdf(u);

			double d3 = 0.5 * u * d1 + (1 - 0.5) * d2;
			double result = subproblem_objective_estimation[1] * d3;

			// assert result>=0;
			assert !Double.isNaN(result);
			return result;
		} catch (MathException e) {
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	protected double poi(MoChromosome var) {
		objProb(var, subproblem_objective_estimation);
		double target = this.bestSubproblemObjective - 0.25
				* (Math.abs(this.bestSubproblemObjective ));
		double u = (target - subproblem_objective_estimation[0])
				/ subproblem_objective_estimation[1];
		try {
			double d1 = 0;
			if (u > 10)
				d1 = 1;
			else if (u < -10)
				d1 = 0;
			else
				d1 = normalDist.cumulativeProbability(u);
			return d1;
		} catch (MathException e) {
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	protected double lcb(MoChromosome chrom) {
		objProb(chrom, subproblem_objective_estimation);
		double lambda = 2;
		return subproblem_objective_estimation[0] - lambda
				* subproblem_objective_estimation[1];
	};

	@Override
	protected double mean(MoChromosome chrom) {
		objProb(chrom, subproblem_objective_estimation);
		return subproblem_objective_estimation[0];
	};

	@Override
	public void objProb(MoChromosome var, double[] result) {
		double mean = 0;
		double dev = 0;
		for (int i = 0; i < weight.length; i++) {
			mean += weight[i] * var.estimatedObjectiveValue[i];
			dev += Math.pow(weight[i] * var.estimatedObjectiveDevitation[i], 2);
		}
		result[0] = mean;
		result[1] = Math.sqrt(dev);
	}

	@Override
	public double subobject(MoChromosome var) {
		double mean = 0;
		for (int i = 0; i < weight.length; i++) {
			mean += weight[i] * var.objectivesValue[i];
		}
		return mean;
	}
}
