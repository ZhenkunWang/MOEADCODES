package uk.ac.essex.csp.algorithms.moead.gp;

import uk.ac.essex.csp.algorithms.mo.ea.Configurator;

public class GpMOEADConfigurator extends Configurator {

	public static final String Property_Region_Size = "region_size";

	public static final String Property_Region_Scan = "region_scan";

	// The number of initial design point, used for generating the Hyper Latin.
	public static final String Property_Design_Point_Number = "design_size";

	// the probability set for the mutation.
	public static final String Property_Mutation_Probability = "mutation_probability";

	// the distribution index set for the mutation.
	public static final String Property_Mutation_Distribution_Index = "mutation_distribution_index";

	// The decomposition method used. default is WeightSum.
	public static final String Property_Decomposition_Method = "decomposition_method";

	public static final String Property_DE_Crossrate = "de_crossrate";

	public static final String Property_DE_F = "de_f";

	// weather using te_ei approximation or not. boolean value.
	public static final String Property_Tchebycheff_EI_Approximation = "te_ei_approximate";

	// the selection strategy used.
	public static final String Property_Selection_Strategy = "selection";

	// the updating criteria.
	public static final String Property_Updating_Criteria = "criteria";

	// the minimal distance allowed for selection.
	public static final String Property_Selection_Distance_Shreshold = "min_distance";

	public double getSelectionDistanceShreshold() {
		return this.getDoubleProperty(Property_Selection_Distance_Shreshold);
	}

	public void setSelectionDistanceShreshold(double value) {
		this.addProperty(Property_Selection_Distance_Shreshold, Double
				.toString(value));
	}

	public String getSelectionStrategy() {
		return this.getStringProperty(Property_Selection_Strategy);
	}

	public void setSelectionStrategy(String name) {
		this.addProperty(Property_Selection_Strategy, name);
	}

	public String getUpdatingCriteria() {
		return this.getStringProperty(Property_Updating_Criteria);
	}

	public void setUpdatingCriteria(String name) {
		this.addProperty(Property_Updating_Criteria, name);
	}

	public int getRegionSize() {
		return this.getIntegerProperty(Property_Region_Size);
	}

	public void setRegionSize(int regionsize) {
		this.addProperty(Property_Region_Size, Integer.toString(regionsize));
	}

	public int getSearchIteration() {
		return super.getTotalGeneration();
	}

	public void setSearchIteration(int si) {
		super.setTotalGeneration(si);
	}

	public double getMutationProbablity() {
		return this.getDoubleProperty(Property_Mutation_Probability);
	}

	public void setMutationProbablity(double si) {
		this.addProperty(Property_Mutation_Probability, Double.toString(si));
	}

	public int getMutationDistributionIndex() {
		return this.getIntegerProperty(Property_Mutation_Distribution_Index);
	}

	public void setMutationDistributionIndex(int si) {
		this.addProperty(Property_Mutation_Distribution_Index, Integer
				.toString(si));
	}

	public String getDecompositionMethod() {
		return this.getStringProperty(Property_Decomposition_Method);
	}

	public void setDecompositionMethod(String si) {
		this.addProperty(Property_Decomposition_Method, (si));
	}

	public int getDesignPointSize() {
		return this.getIntegerProperty(Property_Design_Point_Number);
	}

	public void setDesignPointSize(int si) {
		this.addProperty(Property_Design_Point_Number, Integer.toString(si));
	}

	public double getDEF() {
		return this.getDoubleProperty(Property_DE_F);
	}

	public void setDEF(double si) {
		this.addProperty(Property_DE_F, Double.toString(si));
	}

	public double getDECrossrate() {
		return this.getDoubleProperty(Property_DE_Crossrate);
	}

	public void setDECrossrate(double si) {
		this.addProperty(Property_DE_Crossrate, Double.toString(si));
	}

	public boolean isUsingTEEIApproximation() {
		return this.getBoolProperty(Property_Tchebycheff_EI_Approximation);
	}

	public void setUsingTEEIApproximation(boolean si) {
		this.addProperty(Property_Tchebycheff_EI_Approximation, Boolean
				.toString(si));
	}

	public boolean doRegionScan() {
		return this.getBoolProperty(Property_Region_Scan);
	}

	public void setRegionScan(boolean rs) {
		this.addProperty(Property_Region_Scan, Boolean.toString(rs));
	}
}
