package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.ArrayList;
import java.util.List;

import uk.ac.essex.csp.algorithms.cluster.Cluster;
import uk.ac.essex.csp.algorithms.cluster.DataPoint;
import uk.ac.essex.csp.algorithms.cluster.JCA;
import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;
import uk.ac.essex.csp.algorithms.moead.gp.Subproblem;

/**
 * Selection by Utility.
 * 
 * @author wliui
 * 
 */
public abstract class UtilSelectionStrategy extends AbstractSelectionStrategy {

	public UtilSelectionStrategy(int number) {
		super(number);
	}

	public List<GPSubproblem> select(List<GPSubproblem> subproblems,
			SelectionContext context) {
		// first filter by the closeness.

		init(subproblems.size());
		this.computeSelUtil(subproblems, context);
		double sds = context.config.getSelectionDistanceShreshold();
		super.closenessFilter(subproblems, context, sds);

		int objdim = subproblems.get(0).weight.length;

		ArrayList<GPSubproblem> result = new ArrayList<GPSubproblem>();

		if (objdim == 2) {
			super.regionFilter(subproblems, context);

			List<Integer> unfilterredIndex = this.getUnfilterredIndex();

			System.out.print("Select Candidate:");
			for (Integer i : unfilterredIndex)
				System.out.print(i.toString() + ", ");
			System.out.println();

			while (result.size() < this.selectNumber) {
				if (unfilterredIndex.size() == 0)
					break;

				int selectedIndex = tournamentsel(context.randomgenerator,
						this.prescreenvutil, unfilterredIndex, 3);
				GPSubproblem subproblem = subproblems.get(selectedIndex);
				// actually also need to check if the selection is close the
				// existed
				// selection.
				// double sds = context.config.getSelectionDistanceShreshold();
				if (!isClose(subproblem, result, sds)) {
					result.add(subproblem);
					this.selectSequence.add(selectedIndex);
				}
				// remove selectedIndex for the next tournament selection.
				for (int i = 0; i < unfilterredIndex.size(); i++) {
					if (unfilterredIndex.get(i) == selectedIndex) {
						unfilterredIndex.remove(i);
						break;
					}
				}
			}
			return result;
		} else {
			List<DataPoint> dps = new ArrayList<DataPoint>();
			for (int i = 0; i < filterred.length; i++) {
				if (!filterred[i]) {
					DataPoint dp = new DataPoint();
					Subproblem sub = subproblems.get(i);
					dp.reNew(sub.weight, sub);
					dps.add(dp);
				}
			}

			DataPoint[] dparray = dps.toArray(new DataPoint[dps.size()]);

			JCA jca = new JCA(selectNumber, 1000, dparray, objdim);
			jca.startAnalysis();

			for (int i = 0; i < selectNumber; i++) {
				for (int k = 0; k < 100; k++) {
					Cluster cluster = jca.getCluster(i);
					List<DataPoint> dataPoints = cluster.getDataPoints();
					int size = dataPoints.size();
					// tournament.
					int[] perm = context.randomgenerator.nextPermutation(size,
							Math.min(10, size));
					GPSubproblem sub = null;
					double util = -Double.MAX_VALUE;
					// finding the largest in the permutation.
					for (int j = 0; j < perm.length; j++) {
						GPSubproblem subject = (GPSubproblem) dataPoints.get(
								perm[j]).getSubject();
						double findUtil = findUtil(subject, subproblems);
						if (findUtil >= util) {
							sub = subject;
							util = findUtil;
						}
					}
					if (!isClose(sub, result, sds)) {
						result.add(sub);
						this.selectSequence.add(sub.mainpopIndex);
						break;
					}
				}
			}
			return result;
		}
	}

	public double findUtil(GPSubproblem sub, List<GPSubproblem> sups) {
		for (int i = 0; i < sups.size(); i++) {
			if (sub == sups.get(i))
				return this.prescreenvutil[i];
		}
		return -Double.MAX_VALUE;
	}
}
