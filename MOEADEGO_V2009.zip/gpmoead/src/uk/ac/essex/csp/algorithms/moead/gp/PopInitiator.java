package uk.ac.essex.csp.algorithms.moead.gp;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

import org.apache.commons.math.random.RandomGenerator;

import uk.ac.essex.csp.algorithms.mo.ea.CMoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoPopulation;
import uk.ac.essex.csp.algorithms.random.RanMT;
import uk.ac.essex.csp.algorithms.statictics.LHSDesign;

/**
 * Initiation the population with latin hyper design. As I didn't implement the
 * minimal correlation Latin Hyper Design, I just copy the result from Matlab.
 * 
 * The initial latin size is depends on the parameter dimension.
 * <ul>
 * <li>Dimension 2: 10 points.
 * <li>Dimension 3: 15 points.
 * <li>Dimension 4: 20 points.
 * </ul>
 * 
 * @author Wudong LIU
 * 
 */
public class PopInitiator {

	private static int seed = 1321;

	public static double lhsInitPopulation(MoPopulation pop, int size,
			int dimension, double[][] domain, RandomGenerator rg) {
		double[][] design = LHSDesign.betterDesign(size, dimension, rg);
		for (int i = 0; i < size; i++) {
			CMoChromosome chromosome = (CMoChromosome) pop.getChromosome(i);
			for (int j = 0; j < dimension; j++) {
				double max = domain[j][1];
				double min = domain[j][0];
				chromosome.realGenes[j] = (max - min) * design[i][j] + min;
			}
		}
		return LHSDesign.score(design, dimension);
	}

	public static double lhsRandomPopulation(MoPopulation pop, int size,
			int dimension, double[][] domain, int number) {
		RandomGenerator rg = new RanMT();
		rg.setSeed(seed + number);

		double[][] design = LHSDesign.betterDesign(size, dimension, rg);
		for (int i = 0; i < size; i++) {
			CMoChromosome chromosome = (CMoChromosome) pop.getChromosome(i);
			for (int j = 0; j < dimension; j++) {
				double max = domain[j][1];
				double min = domain[j][0];
				chromosome.realGenes[j] = (max - min) * design[i][j] + min;
			}
		}
		return LHSDesign.score(design, dimension);
	}

	public static double lhsFixPopulation(MoPopulation pop, int size,
			int dimension, double[][] domain, int number) {

		String filename = "design/design_8_" + (number + 1) + ".txt";
		System.out.println("loading design from file: " + filename);
		System.out.println("size: " + size + ", dimension: " + dimension);

		double[][] design = new double[size][dimension];

		try {
			FileInputStream fis = new FileInputStream(filename);
			BufferedReader bis = new BufferedReader(new InputStreamReader(fis));
			for (int i = 0; i < size; i++) {
				String line = bis.readLine().trim();
				StringTokenizer st = new StringTokenizer(line);
				
				for (int j = 0; j < dimension; j++) {
					design[i][j] = Double.parseDouble(st.nextToken());
				}
			}

		} catch (FileNotFoundException e) {
			System.out.println("Cannot find the specified design file: "
					+ filename);
			System.exit(-1);
		} catch (IOException e) {
			System.out.println("IO Exception while reading design file: "
					+ filename);
			System.exit(-1);
		}

		for (int i = 0; i < size; i++) {
			CMoChromosome chromosome = (CMoChromosome) pop.getChromosome(i);
			for (int j = 0; j < dimension; j++) {
				double max = domain[j][1];
				double min = domain[j][0];
				chromosome.realGenes[j] = (max - min) * design[i][j] + min;
			}
		}
		return LHSDesign.score(design, dimension);
	}

}
