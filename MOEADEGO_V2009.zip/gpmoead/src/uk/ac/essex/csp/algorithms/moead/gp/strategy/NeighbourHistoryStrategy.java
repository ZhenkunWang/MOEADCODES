package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.List;

import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;

/**
 * This is a Prescreen Strategy that combine both several factors into
 * consideration.
 * <ol>
 * <li>The neighbourhood's Total ei improvement.
 * <li>The history of the selection for evaluation on the given subproblem: For
 * the last given evaluation iteration, the more it get selected, the less it
 * will be selected in current iteration.
 * </ol>
 * Several parameters control the behaviour of this Strategy:
 * <ol>
 * <li>lookingback: how many iteration should be considered when the history is
 * take into account.
 * <li>lamda: how much the history should be take into account. The larger, the less history should be taken into account. 
 * </ol>
 * 
 * @author wudong
 * 
 */
public class NeighbourHistoryStrategy extends PrescreenStrategy {
	@Override
	protected void computeUtil(List<GPSubproblem> subproblems,
			SelectionContext context) {
		init(subproblems.size());
		// The length of looking back
		int lookingback = 30;
		double lamda = 0.3;
		
		if (context.EvalCounter<50)
			lamda= 10; //take almost none effect of the history.
		else if (context.EvalCounter<80)
			lamda = 1;
		else if (context.EvalCounter<100)
			lamda = 0.5;
		else
			lamda = 0.1;
		//
		// int einsize = context.Popsize /10;
		// Test for
		int einsize = 10;

		for (int i = 0; i < subproblems.size(); i++) {
			GPSubproblem sub = subproblems.get(i);
			double evalcounter = 0;
			double eisum = 0;

			for (int j = 0; j < einsize; j++) {
				GPSubproblem neighbour = (GPSubproblem) sub.neighbours.get(j);
				eisum += neighbour.criteriaValue(sub.getCurrentIndividual());
				evalcounter += neighbour.getRecentEvalCount(
						context.EvalCounter, lookingback);
			}

			prescreenvutil[i] = -1 * eisum
					* (1 - evalcounter / (lamda * lookingback));
		}				
	}

	@Override
	public String getName() {
		return "NeighbourHistory Selection";
	}
}
