package uk.ac.essex.csp.algorithms.moead.gp.strategy;

import java.util.List;

import uk.ac.essex.csp.algorithms.moead.gp.GPSubproblem;

public class ControlledRandomSelectionStrategy extends
		UtilSelectionStrategy {

	public ControlledRandomSelectionStrategy(int number) {
		super(number);
	}

	@Override
	public void computeSelUtil(List<GPSubproblem> subs, SelectionContext context) {
		//super.init(subs.size());
		for (int i = 0; i < this.prescreenvutil.length; i++) {
			this.prescreenvutil[i] = context.randomgenerator.nextUniform(0, 1);
		}
	}

	public String getName() {
		return "Controlled Random Selection";
	}

//	public List<GPSubproblem> select(List<GPSubproblem> subproblems,
//			SelectionContext context) {
//		// first filter by the closeness.
//		this.computeSelUtil(subproblems, context);
//		super.closenessFilter(subproblems, context, 10e-5);
//		// super.regionFilter(subproblems, context);
//
//		ArrayList<GPSubproblem> result = new ArrayList<GPSubproblem>();
//
//		while (result.size() < this.selectNumber) {
//			int nextInt = context.randomgenerator.nextInt(0,
//					subproblems.size() - 1);
//			if (!filterred[nextInt]) {
//				GPSubproblem subproblem = subproblems.get(nextInt);
//				if (!isClose(subproblem, result, 10e-5))
//					result.add(subproblem);
//			}
//		}
//		return result;
//	}

}
