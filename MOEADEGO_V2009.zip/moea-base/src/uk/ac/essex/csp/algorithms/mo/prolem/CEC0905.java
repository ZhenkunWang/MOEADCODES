package uk.ac.essex.csp.algorithms.mo.prolem;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;

public class CEC0905 extends AbstractCMOProblem {

	private static int N=10;
	private static double a=0.1;
	
	public void evaluate(double[] x, double[] y) {
		double oldsum = 0,  evensum = 0;
		int evencount = 0, oldcount = 0;
		for (int j = 2; j <= parDimension; j++) {
//			double yj=x[j-1]-Math.sin(6*Math.PI*x[0]);
			double yj=x[j-1]-Math.sin(6*Math.PI*x[0]+j*Math.PI/parDimension);
			double v = h(yj);
			if (j % 2 == 0) {
				evensum+=v;
				evencount++;
			} else {
				oldsum+=v;
				oldcount++;
			}
			y[0] = x[0] + (0.5/(N) +a)*Math.abs(Math.sin(2*N*Math.PI*x[0])) +2 * (oldsum) / (double) oldcount;
			y[1] = 1 - x[0] +  (0.5/(N) +a)*Math.abs(Math.sin(2*N*Math.PI*x[0]))  + 2 * (evensum) / (double) evencount;
		}
	}
	
	private double h(double x) {
		return 2*x*x-Math.cos(4*Math.PI*x)+1;
	}

	@Override
	protected void init() {
		this.domain = new double[this.parDimension][2];
		domain[0][0] = 0;
		domain[0][1] = 1;
		for (int i = 1; i < parDimension; i++) {
			domain[i][0] = -1;
			domain[i][1] = 1;
		}

		this.objDimension = 2;
		this.range = new double[objDimension][2];
		this.idealpoint = new double[] { 0, 0 };
	}

	public CEC0905(int pd) {
		this.parDimension = pd;
		init();
	}

	public static final CEC0905 getInstance(int d) {
		if (instance == null) {
			instance = new CEC0905(d);
			instance.name = "CEC0905_"+d;
		}
		return instance;
	}

	private static CEC0905 instance;
}
