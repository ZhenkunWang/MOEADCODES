package uk.ac.essex.csp.algorithms.optimization;


public class GSLMinimisation {

	static{
		System.loadLibrary("gpcpp");
	}

	public native double optmize(MinimisationFunction mf, int nvar,
			double[] startpoint, int iteration, double[] optpoint,
			double[] temparray);

//	public static void main(String args[]) {
//		MinimisationFunction mf = new MinimisationFunction() {
//			public double function(double[] param) {
//				System.out.println(Arrays.toString(param));
//				return 2 * (param[0] -1)*(param[0] -1)  + 2 * (param[1]-2) * (param[1]-2) +1;
//			}
//		};
//		
//		double startpoint[] = { 2, 5 };
//		double optpoint[] = new double[2];
//		double temparray[] =  { 2.1, 5.88 };
//
//		GSLMinimisation minimisation = new GSLMinimisation();
//		double opt = minimisation.optmize(mf, 2, startpoint, 1000, optpoint, temparray);
//		System.out.println(Arrays.toString(optpoint));
//		System.out.println(opt);
//	}
}
