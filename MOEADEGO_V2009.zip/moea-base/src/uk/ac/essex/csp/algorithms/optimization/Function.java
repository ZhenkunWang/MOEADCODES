package uk.ac.essex.csp.algorithms.optimization;

/**
 * This abstract class provides access using a one dimensional variable
 * to a function with multiple independent variables.  It can be used
 * during optimization to follow a particular direction in the independant
 * variable space.  The starting point is given by Vector, p.  One dimensional
 * search is in the direction given by Vector, xi, for a distance given
 * by x*xi.  Subclasses provide calculation of the value of the function.
 * For registration, a subclass could implement a similarity measure
 * between two images.  The minimize variable determines if the optimization
 * is a minimization or a maximization.
 * Subclasses must provide:
 *   1 A constructor
 *   2 A method to evaluate the function for independent variables, xt.
 *     abstract protected double eval(double[] xt);
 *   3 The number of independent variables, xt.length.
 *     abstract protected int length();
 * Known subclasses: Well, Polynomial, SliceFunction, StackFunction
 * Known users: Objects of this class are passed to Powell, ParabolicFit
 * and SimulatedAnnealing during optimization using those algorithms.
 * see Press WH, Teukolsky SA, Vetterling WT, Flannery: Numerical recipes
 * in C++. Cambridge University Press, Cambridge, 2002, Chapter 10.
 *
 * The value of the function at xt = p + x*xi can be obtained
 * 1 using p, xi, and x
 *   double value(double x, Vector p, Vector xi)
 * 2 by setting p and xi, and then using distance x:
 *   setP(Vector p)
 *   setXi(Vector xi)
 *   double value(double x)
 * 3 using xt = p + x*xi directly:
 *   double value(double[] xt)
 * Vectors x and p don't need to be set for 1 dimensional functions.
 *
 * showFunction == true shows F(xt) in status bar.
 * showMoves == true shows F(xt) and xt in Results window.
 * plot() makes a graph of the function from p in directions determined
 *   by the input variable xis.
 *
 * @author J. Anthony Parker, MD PhD <J.A.Parker@IEEE.org>
 * @version 19August2004
 *
 * @see	extern.nifti.alignstacks.align3tp.Vector
 */
abstract public class Function {
	private boolean minimize = true;
	private Vector p = null, xi = null;
	private int nEval = 0;	// number of evaluations
	private boolean showFunction = true;
	protected boolean showMoves = false;

	/** Value of the function starting at point p, going in direction
	 * xi for a distance, x*xi.
	 *
	 * @param x One dimensional search parameter.
	 * @param p Starting point.
	 * @param xi Search direction.
	 */
	public double value(double x, Vector p, Vector xi)
								throws IllegalArgumentException {
		this.p = p;
		this.xi = xi;
		if(xi.length()!=length() || p.length()!=length())
			throw new IllegalArgumentException("Illegal Vector length");
		return value(p.add(xi.multiply(x)));
	}

	/** Value of the function for distance, x, when point, p, and
	 * direction, xi, are already set.
	 *
	 * @param x One dimensional search parameter.
	 */
	public double value(double x) throws IllegalArgumentException {
		if(length()==1) {	// 1D functions don't require p or xi
			if(p==null)
				p = new Vector(new double[] {0.0});
			if(xi==null)
				xi = new Vector(new double[] {1.0});
		} else {
			if(p==null || xi==null)
				throw new IllegalArgumentException("Undefined parameter(s)");
			else if(p.length()!=xi.length())
				throw new IllegalArgumentException(
								"Debugging: incompatible Vector lengths");
		}
		return value(p.add(xi.multiply(x)));
	}

	/** Value of the function for independent variables xt.
	 *
	 * @param xt vector of function parameters.
	 */
	public double value(Vector xtv) throws IllegalArgumentException {
		double[] xt = xtv.value();
		if(length()!=xt.length)
			throw new IllegalArgumentException("Illegal length vector");
		nEval++;
		double v = eval(xt);
		v = minimize ? v : -v;
//		if(showFunction)
//			IJ.showStatus("Funtion = "+(-v));
//		if(showMoves)
//			IJ.write("Value = "+(-v)+", xt : "+new Vector(xt).toString(15));
		return v;
	}

	/** Value of the function for independent variables, xt. */
	abstract protected double eval(double[] xt);

	/** Number of independent variables. */
	abstract protected int length();

	/** Set to true for minimization; set to false for maximization. */
	public void setMinimize(boolean minimize) {
		this.minimize = minimize;
		return;
	}

	/** Set starting point, p. */
	public void setP(Vector p) throws IllegalArgumentException {
		if(p.length()!=length())
			throw new IllegalArgumentException("Illegal Vector length");
		this.p = p;
		return;
	}

	/** Set search direction xi. */
	public void setXi(Vector xi) throws IllegalArgumentException {
		if(xi.length()!=length())
			throw new IllegalArgumentException("Illegal Vector length");
		this.xi = xi;
		return;
	}

	/** Number of times the function has been evaluated. */
	public int getNEval() {return nEval;}
	public void setNEval(int nEval) {this.nEval = nEval; return;}

	/** showFunction displays function value in status bar.*/
	public void setShowFunction(boolean showFunction) {
		this.showFunction = showFunction;
		return;
	}

	/** showMoves is used during debugging to follow the changes
	 *  in xt.*/
	public void setShowMoves(boolean showMoves) {
		this.showMoves = showMoves;
		return;
	}

	/** Plot Function values with respect to p.
	 *
	 * @param xis set of directions, along which to plot function
	 * @param start offset from p in direction xis[j], e.g. -5.0
	 * @param end offset from p in direction xis[j], e.g. 5.0
	 * @param points number of points in graph
	 */
//	public PlotWindow plot(double[][] xis, float start,
//											float end, int points) {
//		int n = length();	// number of dimensions
//		int m = xis.length;	// number of directions
//		if(p==null) {
//			int len = length();
//			double[] pVal = new double[len];
//			for(int i=0; i<len; i++) pVal[i] = 0.0;
//			p = new Vector(pVal);
//		}
//		if(points<2)
//			throw new IllegalArgumentException("2 points minimum");
//		for(int j=0; j<m; j++)
//			if(xis[j].length!=n)
//				throw new IllegalArgumentException("Illegal xis[j] length");
//		float[] xValues = new float[points];
//		float[][] yValues = new float[m][points];
//		for(int i=0; i<points; i++)
//			xValues[i] = start+(end-start)*i/(points-1);
//		float xMin= xValues[0], xMax = xValues[points-1],
//				yMin = Float.MAX_VALUE, yMax = Float.MIN_VALUE;
//		for(int j=0; j<m; j++) {
//			setXi(new Vector(xis[j]).unit());
//			for(int i=0; i<points; i++) {
//				yValues[j][i] = (float)value(xValues[i]);
//				if(!minimize) yValues[j][i] = -yValues[j][i];
//				if(yValues[j][i]<yMin) yMin = yValues[j][i];
//				if(yValues[j][i]>yMax) yMax = yValues[j][i];
//			}
//		}
//		PlotWindow pw = new PlotWindow("Function values", "x[i]", "f(x[i])",
//										xValues, yValues[0]);
//		pw.setLimits((double)xMin, (double)xMax, (double)yMin, (double)yMax);
//		for(int j=1; j<m; j++)
//			pw.addPoints(xValues, yValues[j], PlotWindow.LINE);
//		pw.draw();
//		return pw;
//	}

}	// end of abstract class Function

