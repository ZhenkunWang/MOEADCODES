package uk.ac.essex.csp.algorithms.appro.gp;

public class KmGpApproximatorJNI extends DpGpApproximatorJNI {

	static {
		System.loadLibrary("gpcpp");
	}
	
	protected native long nativeInitialize(int dimension, int number);

	protected native void nativeFinalize(long pointer);

	protected native void nativeTrain(double[][] datas, double[] values,
			long pointer);

	/**
	 * this method estimate the unknown point with the cloest cluster.
	 */
	protected native void nativeEstimate(double[] variable, double[] result,
			long pointer);

	
	public KmGpApproximatorJNI(int d) {
		super(d);
	}

	public void estimate2(double[] x, double[] ys) {
		// not support
		throw new UnsupportedOperationException(
				"Can only be invoked in GpApproximatorJNI");
	}

}
