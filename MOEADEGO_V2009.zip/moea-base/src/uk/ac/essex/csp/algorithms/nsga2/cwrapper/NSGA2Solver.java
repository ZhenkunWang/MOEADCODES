package uk.ac.essex.csp.algorithms.nsga2.cwrapper;

import java.io.PrintStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Arrays;
import java.util.List;

import uk.ac.essex.csp.algorithms.mo.MultiObjectiveProblem;
import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoPopulation;
import uk.ac.essex.csp.algorithms.mo.ea.MoeaGenotype;
import uk.ac.essex.csp.algorithms.mo.prolem.OKA1;

public class NSGA2Solver extends MoeaGenotype {

	public PrintStream out;
	public int runstep;

	// The parameters.
	private double seed;

	private int popsize; // must be a multiple of 4;

	private int ngen; // number of generation;

	final private int ncon = 0; // number of constrains;

	private int nobj; // number of objectives;

	private int nreal; // number of real variables;

	private double[] min_realvar; // min value of the corresponding indexed

	// real variables;
	private double[] max_realvar; // max value of the corresponding indexed

	// real variable.
	private double pcross_real; // probability of crossover of real variable

	// (0.6-1.0)
	private double pmut_real; // probablity of mutation of real variables

	// (1/nreal).
	private double eta_c; // the value of distribution index for crossover

	// (5-20).
	private double eta_m; // the value of distribution index for mutation

	// (5-50).

	// the native methods.
	public native void initlizePop(MoPopulation initpop);

	public native void evolve();

	public native void cfinalize();

	public native MoChromosome[] getfinalresult();

	public native MoChromosome[] reportMainPopulation();

	public native void init(double seed, int popsize, int ngen, int nobj,
			int ncon, int nreal, double[] min_realvar, double[] max_realvar,
			double pcross_real, double pmut_real, double eta_c, double eta_m);

	private MoChromosome[] result;

	public void doSolve(MultiObjectiveProblem problem) {

	}

	/**
	 * Evaluate the xreal values against the problem definition. This will be
	 * invoked by the C code for the evaluation.
	 * 
	 * @param xreal
	 * @return
	 */
	public double[] evaluate(double[] xreal) {
		MultiObjectiveProblem multiObjectiveProblem = this
				.getMultiObjectiveProblem();
		// ObjectiveFunction[] objectiveFunctions = multiObjectiveProblem
		// .getObjectiveFunctions();

		double[] result = new double[multiObjectiveProblem
				.getObjectiveSpaceDimension()];
		multiObjectiveProblem.evaluate(xreal, result);
		// for (int i = 0; i < result.length; i++) {
		// result[i] = objectiveFunctions[i].computeObjective(xreal);
		// }
		return result;
	}

	static {
		System.loadLibrary("nsga2c");
	}

	public static void main(String[] args) {

		ClassLoader sysClassLoader = ClassLoader.getSystemClassLoader();

		// Get the URLs
		URL[] urls = ((URLClassLoader) sysClassLoader).getURLs();

		System.out.println("The Class Path: ");
		for (int i = 0; i < urls.length; i++) {
			String string = urls[i].getFile().toString();
			String subString = string.substring(1);
			System.out.print(subString + ";");
		}
		System.out.println();

		System.out.println("The native library path = "
				+ System.getProperty("java.library.path"));

		NSGA2Solver solver = new NSGA2Solver();
		// MultiObjectiveProblem sch = SCH.getInstance();
		MultiObjectiveProblem sch = OKA1.getInstance();

		// try {
		// System.in.read();
		// } catch (IOException e) {
		// e.printStackTrace();
		// }

		solver.solve(sch);
		List<MoChromosome> name = Arrays.asList(solver.result);
		MoPopulation.writeToFile(name, "d:\\nsga2result.txt");
	}

	@Override
	protected void doSolve() {
		MultiObjectiveProblem problem = this.getMultiObjectiveProblem();
		this.nreal = problem.getParameterSpaceDimension();
		this.seed = Math.random();
		this.popsize = this.getConfiguration().getPopSize();
		// getConfiguration().getIntegerParameter(
		// MoeaConfiguration.POPULATION_SIZE, 1000);
		this.ngen = getConfiguration().getTotalGeneration();
		this.nobj = problem.getObjectiveSpaceDimension();
		this.min_realvar = new double[nreal];
		this.max_realvar = new double[nreal];

		double[][] domain = problem.getDomain();

		for (int i = 0; i < this.nreal; i++) {
			this.min_realvar[i] = domain[i][0];
			this.max_realvar[i] = domain[i][1];
		}

		this.pcross_real = 0.7;
		// getConfiguration().getDoubleParameter(
		// MoeaConfiguration.CROSSOVER_PROBABLITY, 0.7);
		this.pmut_real = 0.2;
		// getConfiguration().getDoubleParameter(
		// MoeaConfiguration.MUTATION_PROBABLITY, 0.2);
		this.eta_c = 20;
		// getConfiguration().getIntegerParameter(
		// MoeaConfiguration.CROSSOVER_DISTRIBUTION_INDEX, 20);
		this.eta_m = 40;
		// getConfiguration().getIntegerParameter(
		// MoeaConfiguration.MUTATION_DISTRIBUTION_INDEX, 40);

		System.out.println("Start Parameter Initialization...");

		init(seed, popsize, ngen, nobj, ncon, nreal, min_realvar, max_realvar,
				pcross_real, pmut_real, eta_c, eta_m);
		System.out.println("Finished Parameter Initialization.");

		System.out.println("Start Genetic Envloving...");

		if (this.out != null) {
			out.println("The " + this.runstep
					+ "th run of the moea algorithms start");
			out.println();
		}

		for (int i = 0; i < ngen; i++) {
			if (this.out != null) {
				out.println(this.runstep + "th run, " + i + "th generation");
				MoChromosome[] chromosomes = this.reportMainPopulation();
				for (int k = 0; k < chromosomes.length; k++) {
					out.println(chromosomes[k]);
				}
				out.println();
			}
			evolve();
		}

		if (this.out != null) {
			out.println("The " + this.runstep + "th run, " + ngen
					+ "th generation");
			MoChromosome[] chromosomes = this.reportMainPopulation();
			for (int k = 0; k < chromosomes.length; k++) {
				out.println(chromosomes[k]);
			}
			out.println();
		}
		if (this.out != null) {
			out.println("The " + this.runstep
					+ "th run of the moea algorithms finished");
			out.println();
		}

		System.out.println("Genetic Envloving Stopped.");

		System.out.println("Get Sovling Result...");
		result = getfinalresult();
		System.out.println("Sovling Result is retreived.");

		cfinalize();
	}

	@Override
	public String getName() {
		return "NSGA2";
	}

	@Override
	public String reportResult() {
		// TODO Auto-generated method stub
		return null;
	}
}
