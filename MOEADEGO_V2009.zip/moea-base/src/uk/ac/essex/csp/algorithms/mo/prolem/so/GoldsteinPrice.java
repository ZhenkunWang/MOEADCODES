package uk.ac.essex.csp.algorithms.mo.prolem.so;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;

/**
 * The Goldstein & Price Function with global optima and several local optimas.
 * <p>
 * the optimal value: 3
 * <p>
 * the optimal point: x = (0,1)
 * <p>
 * see <A href="http://www-optima.amp.i.kyoto-u.ac.jp/member/student/hedar/Hedar_files/TestGO_files/Page1760.htm"
 * > this <A> for more detail.
 */
public class GoldsteinPrice extends AbstractCMOProblem {

	@Override
	protected void init() {
		this.domain = new double[this.parDimension][2];

		domain[0][0] = -2;
		domain[0][1] = 2;

		domain[1][0] = -2;
		domain[1][1] = 2;

		this.objDimension = 1;
		this.range = new double[objDimension][2];
		// this.idealpoint = new double[] { 0, 0 };
	}

	public void evaluate(double[] sp, double[] obj) {
		double x1 = sp[0], x2 = sp[1], a = 0, b = 0;
		a = 1
				+ (x1 + x2 + 1)
				* (x1 + x2 + 1)
				* (19 - 14 * x1 + 3 * x1 * x1 - 14 * x2 + 6 * x1 * x2 + 3 * x2
						* x2);
		b = 30
				+ (2 * x1 - 3 * x2)
				* (2 * x1 - 3 * x2)
				* (18 - 32 * x1 + 12 * x1 * x1 + 48 * x2 - 36 * x1 * x2 + 27
						* x2 * x2);
		obj[0] = a * b;
	}

	public GoldsteinPrice() {
		this.parDimension = 2;
		init();
	}

	public static final GoldsteinPrice getInstance() {
		if (instance == null) {
			instance = new GoldsteinPrice();
			instance.name = "GoldsteinPrice";
		}
		return instance;
	}

	private static GoldsteinPrice instance;
}
