package uk.ac.essex.csp.algorithms.gpcross;

import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.NormalDistribution;
import org.apache.commons.math.distribution.NormalDistributionImpl;

import uk.ac.essex.csp.algorithms.appro.gp.DpGpApproximatorJNI;

public class GPCrossover {
	static {
		System.loadLibrary("gpegolib");
	}

	private int number;
	private DpGpApproximatorJNI model;

	private double lowEnd;
	private double highEnd;
	private double searchsize = 10e3;
	private double searchstep;

	private double[][] x;
	private double[] y;
	private double[] ey = new double[2];
	private double[] ex = new double[1];

	public GPCrossover(int num, double low, double high) {
		this.number = num;
		this.lowEnd = low;
		this.highEnd = high;
		model = new DpGpApproximatorJNI(1);
		x = new double[number][1];
		y = new double[number];
		searchstep = (highEnd - lowEnd) / searchsize;
	}

	public double cross(double[] xx, double[] yy, double best) {
		model.reset();
		for (int i = 0; i < number; i++) {
			this.x[i][0] = xx[i];
			this.y[i] = yy[i];
		}
		model.setData(this.x, this.y);
		model.solve();

		// search for the best ei;
		ex[0] = lowEnd;
		double result = ex[0];
		double bestei = -Double.MAX_VALUE;

		while (ex[0] <= highEnd) {
			model.estimate(ex, ey);
			// compute the ei value.
			double ei = EI(ey, best);
			if (ei > bestei) {
				bestei = ei;
				result = ex[0];
			}
			ex[0] += searchstep;
		}
		return result;
	}

	private double EI(double[] objective_estimate, double best) {
		if (objective_estimate[1] <= 10 * Double.MIN_VALUE) {
			return 0;
		} else if (Double.isNaN(objective_estimate[1])) {
			return -Double.MAX_VALUE;
		}

		double u = (best - objective_estimate[0]) / objective_estimate[1];
		try {
			double d1 = 0;
			if (u > 10)
				d1 = 1;
			else if (u < -10)
				d1 = 0;
			else
				d1 = normalDist.cumulativeProbability(u);
			double d2 = normalDistPdf(u);

			double d3 = 0.5 * u * d1 + (1 - 0.5) * d2;
			double result = objective_estimate[1] * d3;

			// assert result>=0;
			assert !Double.isNaN(result);
			return result;
		} catch (MathException e) {
			e.printStackTrace();
			return 0;
		}
	}

	public NormalDistribution normalDist = new NormalDistributionImpl();

	public static double normalDistPdf(double x) {
		double part1 = 1d / Math.sqrt(2 * Math.PI);
		double part2 = Math.exp(-1 * x * x / 2);
		return part1 * part2;
	}

}
