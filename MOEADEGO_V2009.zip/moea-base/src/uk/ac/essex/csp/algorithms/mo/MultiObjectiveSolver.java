package uk.ac.essex.csp.algorithms.mo;

public interface MultiObjectiveSolver {

	public void solve(MultiObjectiveProblem problem);
	
}
