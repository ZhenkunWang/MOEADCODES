package uk.ac.essex.csp.algorithms.cluster;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import uk.ac.essex.csp.algorithms.Sorting;

/**
 * This class represents a Cluster in a Cluster Analysis Instance. A Cluster is
 * associated with one and only one JCA Instance. A Cluster is related to more
 * than one DataPoints and one centroid.
 * 
 * @author Shyam Sivaraman
 * @version 1.1
 * @see DataPoint
 * @see Centroid
 */

public class Cluster {
	private String mName;

	private Centroid mCentroid;

	private double mSumSqr;

	private List<DataPoint> mDataPoints;

	public Cluster(String name) {
		this.mName = name;
		this.mCentroid = null; // will be set by calling setCentroid()
		mDataPoints = new ArrayList<DataPoint>();
	}

	public void setCentroid(Centroid c) {
		mCentroid = c;
	}

	public Centroid getCentroid() {
		return mCentroid;
	}

	public void addDataPoint(DataPoint dp) { // called from CAInstance
		dp.setCluster(this); // initiates a inner call to
								// calcEuclideanDistance() in DP.
		this.mDataPoints.add(dp);
		calcSumOfSquares();
	}

	public void removeDataPoint(DataPoint dp) {
		this.mDataPoints.remove(dp);
		calcSumOfSquares();
	}

	public int getNumDataPoints() {
		return this.mDataPoints.size();
	}

	public DataPoint getDataPoint(int pos) {
		return this.mDataPoints.get(pos);
	}

	public void calcSumOfSquares() { // called from Centroid
		int size = this.mDataPoints.size();
		double temp = 0;
		for (int i = 0; i < size; i++) {
			temp = temp + (this.mDataPoints.get(i)).getCurrentEuDt();
		}
		this.mSumSqr = temp;
	}

	public double getSumSqr() {
		return this.mSumSqr;
	}

	public String getName() {
		return this.mName;
	}

	public List<DataPoint> getDataPoints() {
		return this.mDataPoints;
	}

	public int[] sortingIndexOfDistance() {
		DataPoint[] points = mDataPoints.toArray(new DataPoint[mDataPoints
				.size()]);
		int[] is = Sorting.sorting(points, dc);
		return is;
	}

	private DistanceComparator dc = new DistanceComparator();

	public class DistanceComparator implements Comparator<DataPoint> {
		public int compare(DataPoint o1, DataPoint o2) {
			double d1 = o1.testEuclideanDistance(mCentroid);
			double d2 = o2.testEuclideanDistance(mCentroid);
			if (d1 < d2)
				return -1;
			else if (d1 > d2)
				return 1;
			else
				return 0;
		}
	}
}
