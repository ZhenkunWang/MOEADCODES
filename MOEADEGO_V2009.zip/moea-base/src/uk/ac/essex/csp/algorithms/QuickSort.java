package uk.ac.essex.csp.algorithms;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/*************************************************************************
 * Compilation: javac QuickSort.java Execution: java QuickSort N
 * 
 * Generate N random real numbers between 0 and 1 and quicksort them.
 * 
 * On average, this quicksort algorithm runs in time proportional to N log N,
 * independent of the input distribution. The algorithm guards against the
 * worst-case by randomly shuffling the elements before sorting. In addition, it
 * uses Sedgewick's partitioning method which stops on equal keys. This protects
 * against cases that make many textbook implementations, even randomized ones,
 * go quadratic (e.g., all keys are the same).
 * 
 *************************************************************************/

public class QuickSort {

	public static <T> void quicksort(List<T> a, Comparator<T> comp, int[] index) {
		for (int i = 0; i < a.size(); i++)
			index[i] = i;
		shuffle(index); // to guard against worst-case
		quicksort(a, comp, 0, a.size() - 1, index);
	}

	public static <T> void quicksort(List<T> a, Comparator<T> comp, int left,
			int right, int[] index) {
		if (right <= left)
			return;
		int i = partition(a, comp, left, right, index);
		quicksort(a, comp, left, i - 1, index);
		quicksort(a, comp, i + 1, right, index);
	}

	private static <T> int partition(List<T> a, Comparator<T> comp, int left,
			int right, int[] index) {
		int i = left - 1;
		int j = right;
		while (true) {
			while (less(a.get(index[++i]), a.get(index[right]), comp))
				// find item on left to swap
				; // a[right] acts as sentinel
			while (less(a.get(index[right]), a.get(index[--j]), comp))
				// find item on right to swap
				if (j == left)
					break; // don't go out-of-bounds
			if (i >= j)
				break; // check if pointers cross
			exch(i, j, index); // swap two elements into place
		}
		exch(i, right, index); // swap with partition element
		return i;
	}

	// is x < y ?
	private static <T> boolean less(T x, T y, Comparator<T> comp) {
		return comp.compare(x, y) < 0;
	}

	public static void quicksort(double[] a, int[] index) {
		for (int i = 0; i < a.length; i++)
			index[i] = i;
		shuffle(index); // to guard against worst-case
		quicksort(a, 0, a.length - 1, index);
	}

	// quicksort a[left] to a[right]
	public static void quicksort(double[] a, int left, int right, int[] index) {
		if (right <= left)
			return;
		int i = partition(a, left, right, index);
		quicksort(a, left, i - 1, index);
		quicksort(a, i + 1, right, index);
	}

	// partition a[left] to a[right], assumes left < right
	private static int partition(double[] a, int left, int right, int[] index) {
		int i = left - 1;
		int j = right;
		while (true) {
			while (less(a[index[++i]], a[index[right]]))
				// find item on left to swap
				; // a[right] acts as sentinel
			while (less(a[index[right]], a[index[--j]]))
				// find item on right to swap
				if (j == left)
					break; // don't go out-of-bounds
			if (i >= j)
				break; // check if pointers cross
			exch(i, j, index); // swap two elements into place
		}
		exch(i, right, index); // swap with partition element
		return i;
	}

	// is x < y ?
	private static boolean less(double x, double y) {
		return (x < y);
	}

	// exchange a[i] and a[j]
	private static void exch(int i, int j, int[] index) {
		int swap = index[i];
		index[i] = index[j];
		index[j] = swap;
	}

	private static void shuffle(int[] index) {
		int N = index.length;
		for (int i = 0; i < N; i++) {
			int r = i + (int) (Math.random() * (N - i)); // between i and N-1
			exch(i, r, index);
		}
	}

	// test client
	public static void main(String[] args) {
		int N = Integer.parseInt(args[0]);

		List<Double> a = new ArrayList<Double>();
		for (int i = 0; i < N; i++)
			a.add(Math.random());

		int[] index = new int[N];
		for (int i = 0; i < N; i++)
			index[i] = i;

		// sort them
		Comparator<Double> d = new Comparator<Double>() {
			public int compare(Double o1, Double o2) {
				if (o1 == o2)
					return 0;
				else
					return o1 < o2 ? -1 : 1;
			}
		};

		quicksort(a, d, index);
		for (int i = 0; i < N; i++) {
			System.out.println(i + ": " + a.get(i));
		}

		for (int i = 0; i < N; i++) {
			System.out.println(i + ": " + index[i] + " : " + a.get(index[i]));
		}

	}
}
