package uk.ac.essex.csp.algorithms.mo.ea;

import java.util.ArrayList;
import java.util.List;

import uk.ac.essex.csp.algorithms.mo.Scalarization;



public class GenotypeEventManager {
	public List<IGenotypeListener> listeners = new ArrayList<IGenotypeListener>();

	public <T extends Scalarization> void fireGenerationBegin(List<T> pop,
			List<T> focus, int generation) {
		for (IGenotypeListener listener : listeners) {
			listener.generationBegin(pop, focus, generation);
		}
	};

	public <T extends Scalarization> void fireGenerationEnd(List<T> pop,
			int generation) {
		for (IGenotypeListener listener : listeners) {
			listener.generationEnd(pop, generation);
		}
	}

	public <T extends Scalarization> void fireInitFinished(List<T> subproblems) {
		for (IGenotypeListener listener : listeners) {
			listener.initFinish(subproblems);
		}
	};

	public void fireSolveStart() {
		for (IGenotypeListener listener : listeners) {
			listener.solveStart();
		}
	}

	public void fireSolveEnd() {
		for (IGenotypeListener listener : listeners) {
			listener.solveEnd();
		}
	}

	public <T extends Scalarization> void fireEvaluationStart(
			MoChromosome chromosome, List<T> subproblems, int evalnumber) {
		for (IGenotypeListener listener : listeners) {
			listener.evaluationStart(chromosome, subproblems, evalnumber);
		}
	}

	public <T extends Scalarization> void fireEvaluationEnd(
			MoChromosome chromosome, List<T> subproblems, int evalnumber) {
		for (IGenotypeListener listener : listeners) {
			listener.evaluationEnd(chromosome, subproblems, evalnumber);
		}
	}

	public <T extends Scalarization> void firePopulationAdjust(List<T> adjustpops,
			boolean add, int generation) {
		for (IGenotypeListener listener : listeners) {
			listener.populationAdjust(adjustpops, add, generation);
		}
	}
}
