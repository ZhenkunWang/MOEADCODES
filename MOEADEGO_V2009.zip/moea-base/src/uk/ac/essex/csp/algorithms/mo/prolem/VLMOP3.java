package uk.ac.essex.csp.algorithms.mo.prolem;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;

/**
 * Adpoted from the parGEO's paper on TEC.
 * 
 * @author wudong
 * 
 */
public class VLMOP3 extends AbstractCMOProblem {

	public VLMOP3() {
		init();
	}

	@Override
	protected void init() {
		this.parDimension = 2;
		this.domain = new double[this.parDimension][2];
		for (int i = 0; i < parDimension; i++) {
			domain[i][0] = -3;
			domain[i][1] = 3;
		}
		this.objDimension = 3;
		this.range = new double[objDimension][2];
		this.idealpoint = new double[] { 0, 0, 0 };
	}

	public void evaluate(double[] x, double[] y) {
		y[0] = 0.5 * (x[0] * x[0] + x[1] * x[1])
				+ Math.sin(x[0] * x[0] + x[1] * x[1]);
		y[1] = (3 * x[0] - 2 * x[1] + 4) * (3 * x[0] - 2 * x[1] + 4) / 8
				+ (x[0] - x[1] + 1) * (x[0] - x[1] + 1) / 27 + 15;
		y[2] = 1d / (x[0] * x[0] + x[1] * x[1] + 1) - 1.1
				* Math.exp(-x[0] * x[0] - x[1] * x[1]);
	}

	public static final VLMOP3 getInstance() {
		if (instance == null) {
			instance = new VLMOP3();
			instance.name = "VLMOP3";
		}
		return instance;
	}

	private static VLMOP3 instance;
}
