package uk.ac.essex.csp.algorithms.mo.indicator;

public class HyperVolumnJNI {
	
	static {
		System.loadLibrary("gpcpp");
	}
	
	public static native double nativeHyperVolumn
		(double[][] front, double[]ref);
}
