package uk.ac.essex.csp.algorithms.mo.prolem;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;

/**
 * Adpoted from the parGEO's paper on TEC.
 * 
 * @author wudong
 * 
 */
public class DTLZ1 extends AbstractCMOProblem {

	public DTLZ1(int d) {
		parDimension = d;
		init();
	}

	@Override
	protected void init() {
		this.domain = new double[this.parDimension][2];
		for (int i = 0; i < parDimension; i++) {
			domain[i][0] = 0;
			domain[i][1] = 1;
		}
		this.objDimension = 3;
		this.range = new double[objDimension][2];
		this.idealpoint = new double[] { 0, 0 , 0};
	}

	// @Override
	// protected SquareDimentionalSpace createProblemDomain() {
	// double[][] domain = { { 0, 1 }, { 0, 1 } ,{ 0, 1 }, { 0, 1 },{ 0, 1 }, {
	// 0, 1 }};
	// return new SquareDimentionalSpace(domain);
	// }

	public void evaluate(double[] x, double[] y) {
		int k = parDimension - 3 + 1;

		double g = 0.0;
		for (int i = 2; i < parDimension; i++)
			g += ((x[i] - 0.5) * (x[i] - 0.5) - Math.cos(20.0 * Math.PI
					* (x[i] - 0.5)));

		g = 100 * (k + g);

		y[0] = (1 + g) * x[0] * x[1];
		y[1] = (1 + g) * x[0] * (1 - x[1]);
		y[2] = (1 + g) * (1 - x[0]);
	}

	public static final DTLZ1 getInstance(int d) {
		if (instance == null) {
			instance = new DTLZ1(d);
			instance.name = "DTLZ1_"+d;
		}
		return instance;
	}

	private static DTLZ1 instance;

}
