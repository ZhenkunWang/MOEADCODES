package uk.ac.essex.csp.algorithms.appro;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractFunctionApproximator implements
		FunctionApproximator {

	protected List<double[]> datas = new ArrayList<double[]>();
	protected List<Double> values = new ArrayList<Double>();
	
	public void addData(double[] x, double y) {
		double[] copy = new double[x.length];
		System.arraycopy(x, 0, copy, 0, x.length);
		datas.add(copy);
		values.add(y);
	}
	
	public void reset() {
		datas.clear();
		values.clear();
	}

	public void setData(double[][] xs, double[] y) {
		reset();
		for (int i = 0; i < xs.length; i++) {
			addData(xs[i], y[i]);
		}
	}
	
	public int getTrainingSetSize(){
		return this.values.size();
	}
	
}
