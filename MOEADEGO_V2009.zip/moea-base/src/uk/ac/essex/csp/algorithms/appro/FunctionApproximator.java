package uk.ac.essex.csp.algorithms.appro;

public interface FunctionApproximator {
	public void addData(double[] x, double y);
	public void setData(double[][] xs, double[] y);
	public void solve();
	public double estimate(double[] x);
	public void estimate(double[]x, double[]ys);
	public void reset();
}
