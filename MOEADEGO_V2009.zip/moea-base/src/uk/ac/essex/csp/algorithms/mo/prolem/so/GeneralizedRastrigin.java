package uk.ac.essex.csp.algorithms.mo.prolem.so;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;

//http://www.it.lut.fi/ip/evo/functions/node5.html
public class GeneralizedRastrigin extends AbstractCMOProblem {

	@Override
	protected void init() {
		this.domain = new double[this.parDimension][2];

		for (int i = 0; i < parDimension; i++) {
			domain[i][0] = -10;
			domain[i][1] = 10;
		}

		this.objDimension = 1;
		this.range = new double[objDimension][2];
		// this.idealpoint = new double[] { 0, 0 };
	}

	public void evaluate(double[] sp, double[] obj) {
		double sum = 0;
		for (int i = 0; i < sp.length; i++) {
			double d = sp[i] * sp[i] - 10 * Math.cos(2 * Math.PI * sp[i]);
			sum += d;
		}
		obj[0] = 10 * this.parDimension + sum;
	}

	public GeneralizedRastrigin(int pd) {
		this.parDimension = pd;
		init();
	}

	public static final GeneralizedRastrigin getInstance(int d) {
		if (instance == null) {
			instance = new GeneralizedRastrigin(d);
			instance.name = "GeneralizedRastrigin_" + d;
		}
		return instance;
	}

	private static GeneralizedRastrigin instance;

}
