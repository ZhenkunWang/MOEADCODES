package uk.ac.essex.csp.algorithms.mo.prolem;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;

public class CEC0903 extends AbstractCMOProblem {

	public void evaluate(double[] x, double[] y) {
		double oldsum = 0, oldprod=1, evensum = 0, evenprod =1;
		int evencount = 0, oldcount = 0;
		for (int j = 2; j <= parDimension; j++) {
			double yj=x[j-1]-Math.pow(x[0],0.5*(1.0 + 3.0*(j-2)/(double)(parDimension-2)));
			double prod = Math.cos(20*yj*Math.PI/Math.sqrt(j));
			if (j % 2 == 0) {
				evensum+=yj*yj;
				evenprod*=prod;
				evencount++;
			} else {
				oldsum+=yj*yj;
				oldprod*=prod;
				oldcount++;
			}
			y[0] = x[0] + 2 * (4*oldsum - 2*oldprod +2) / (double) oldcount;
			y[1] = 1 - Math.sqrt(x[0]) + 2 * (4*evensum - 2*evenprod + 2) / (double) evencount;
		}
	}

	@Override
	protected void init() {
		this.domain = new double[this.parDimension][2];
		for (int i = 0; i < parDimension; i++) {
			domain[i][0] = 0;
			domain[i][1] = 1;
		}

		this.objDimension = 2;
		this.range = new double[objDimension][2];
		this.idealpoint = new double[] { 0, 0 };
	}

	public CEC0903(int pd) {
		this.parDimension = pd;
		init();
	}

	public static final CEC0903 getInstance(int d) {
		if (instance == null) {
			instance = new CEC0903(d);
			instance.name = "CEC0903_"+d;
		}
		return instance;
	}

	private static CEC0903 instance;
}
