package uk.ac.essex.csp.algorithms.mo.ea.moead;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

import uk.ac.essex.csp.algorithms.mo.MultiObjectiveProblem;
import uk.ac.essex.csp.algorithms.mo.ea.AbstractMOP;
import uk.ac.essex.csp.algorithms.mo.ea.CMoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;

public class EIProblemTest {
	public static void main(String[] args) {
		String probname = args[0];
		MultiObjectiveProblem problem = AbstractMOP.getProblem(probname, 8);
		String directoryName = problem.getName() + "_jei1";
		File file = new File(directoryName);
		file.mkdir();
		
		int pd = problem.getParameterSpaceDimension();
		int design = 0 ;
		if (pd==2)design=10;
		else if (pd==4) design=30;
		else if (pd ==6) design=40;
		else design=60;

		for (int run = 0; run < 10; run++) {
			System.out.println("Solve Starting at Run "+run);
			ArrayList<MoChromosome> result = new ArrayList<MoChromosome>();

			for (int i = 0; i < 120-design; i++) {
				System.out.println("Evaluation iteration Started: "+i);
				
				MOEAD impl = new MOEAD();
				EIProblem eip = new EIProblem(problem, result, impl, design);
				
				impl.popsize = 300;
				impl.neighboursize = 20;
				impl.TotalItrNum = 300;

				impl.solve(eip);
				int nextInt = impl.getRandomData().nextInt(0, 300);

				MoChromosome chromosome = impl.mainpop.getChromosome(nextInt);
				eip.mop.evaluate(chromosome);
				eip.updateModel((CMoChromosome) chromosome);
				
				MoChromosome createChromosome = impl.createChromosome();
				chromosome.copyTo(createChromosome);
				result.add(createChromosome);

				System.out.println("Evaluation iteration End: "+i);
			}
			// output the runs.
			String filename = directoryName + "/" + problem.getName() + "_run_"
					+ run + ".txt";

			try {
				FileOutputStream stream = new FileOutputStream(filename);
				PrintStream printer = new PrintStream(stream);
				for (MoChromosome ind : result) {
					printer.println(ind.vectorString());
				}
				printer.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

			System.out.println("Test Solving End");
		}
	}
}
