package uk.ac.essex.csp.algorithms.mo.prolem;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;

/**
 * Adpoted from the parGEO's paper on TEC.
 * 
 * @author wudong
 * 
 */
public class DTLZ5 extends AbstractCMOProblem {

	public DTLZ5(int d) {
		parDimension = d;
		init();
	}

	@Override
	protected void init() {
		this.domain = new double[this.parDimension][2];

		for (int i = 0; i < parDimension; i++) {
			domain[i][0] = 0;
			domain[i][1] = 1;
		}

		this.objDimension = 3;
		this.range = new double[objDimension][2];
		this.idealpoint = new double[] { 0, 0, 0 };
	}

	// @Override
	// protected SquareDimentionalSpace createProblemDomain() {
	// double[][] domain = { { 0, 1 }, { 0, 1 } ,{ 0, 1 }, { 0, 1 },{ 0, 1 }, {
	// 0, 1 }};
	// return new SquareDimentionalSpace(domain);
	// }

	public void evaluate(double[] x, double[] y) {
		int n = parDimension;
		int dimension = objDimension;
		int k = n - dimension + 1;
		double[] theta = new double[dimension];
		double t = 0;
		double g = 0;

		for (int i = n - k + 1; i <= n; i++) {
			g += Math.pow(x[i - 1] - 0.5, 2);
		}

		t = Math.PI / (4 * (1 + g));
		theta[0] = x[0] * Math.PI / 2;
		for (int i = 2; i <= dimension - 1; i++) {
			theta[i - 1] = t * (1 + 2 * g * x[i - 1]);
		}

		for (int i = 1; i <= dimension; i++) {
			double f = (1 + g);
			for (int j = dimension - i; j >= 1; j--) {
				f *= Math.cos(theta[j - 1]);
			}
			if (i > 1) {
				f *= Math.sin(theta[(dimension - i + 1) - 1]);
			}
			y[i - 1] = f;
		}
	}

	public static final DTLZ5 getInstance(int d) {
		if (instance == null) {
			instance = new DTLZ5(d);
			instance.name = "DTLZ5_" + d;
		}
		return instance;
	}

	private static DTLZ5 instance;
}
