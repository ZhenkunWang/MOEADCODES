package uk.ac.essex.csp.algorithms.cluster;

/**
 * This class represents a candidate for Cluster analysis. A candidate must have
 * a name and two independent variables on the basis of which it is to be
 * clustered. A Data Point must have two variables and a name. A Vector of Data
 * Point object is fed into the constructor of the JCA class. JCA and DataPoint
 * are the only classes which may be available from other packages.
 * 
 * @author Shyam Sivaraman
 * @version 1.0
 * @see JCA
 * @see Cluster
 */

public class DataPoint {
	public double[] point;

	private Cluster mCluster;

	private double mEuDt;

	private Object subject;
	
	public void reNew(double[]p, Object o) {
		this.point =p;
		this.subject = o;
		this.mCluster = null;
		this.mEuDt=0;
	}
	
	public void setCluster(Cluster cluster) {
		this.mCluster = cluster;
		calcEuclideanDistance();
	}
	
	public void calcEuclideanDistance() {
		mEuDt = 0;
		for (int i = 0; i < point.length; i++) {
			mEuDt += Math.pow((point[i] - mCluster.getCentroid().point[i]), 2);
		}
		mEuDt = Math.sqrt(mEuDt);
	}

	public double testEuclideanDistance(Centroid c) {
		double d = 0;
		for (int i = 0; i < point.length; i++) {
			d += Math.pow((point[i] - c.point[i]), 2);
		}
		d = Math.sqrt(d);
		return d;
	}

	public Cluster getCluster() {
		return mCluster;
	}

	public double getCurrentEuDt() {
		return mEuDt;
	}
	
	public Object getSubject() {
		return this.subject;
	}
}