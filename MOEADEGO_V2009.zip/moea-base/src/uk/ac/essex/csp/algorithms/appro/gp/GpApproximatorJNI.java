package uk.ac.essex.csp.algorithms.appro.gp;

import uk.ac.essex.csp.algorithms.appro.AbstractFunctionApproximator;

public class GpApproximatorJNI extends AbstractFunctionApproximator {

	static {
		System.loadLibrary("gpcpp");
	}

	protected int dimension;
	// the point to the native objective.
	protected long pointer = -1;

	protected native long nativeInitialize(int dimension, int number);

	protected native void nativeFinalize(long pointer);

	protected native void nativeTrain(double[][] datas, double[] values,
			long pointer);
	
	protected native void nativeOnlineTrain(double[] var, double val, long pointer);

	protected native void nativeEstimate(double[] variable, double[] result,
			long pointer);

	public GpApproximatorJNI(int d) {
		this.dimension = d;
	}

	public double estimate(double[] x) {
		double[] result = { 0, 0 };
		this.estimate(x, result);
		return result[0];
	}

	public void estimate(double[] x, double[] ys) {
		if (this.pointer == -1)
			throw new IllegalStateException(
					"the model has not been trained yet");
		
		nativeEstimate(x, ys, this.pointer);
	}

	public void solve() {
		cfinalize();// remove the old c++objective. if it existed.
		this.pointer = nativeInitialize(dimension, this.getTrainingSetSize());
		double[][] datas = this.prepareDataForTrain();
		double[] value = this.prepareValueForTrain();
		this.nativeTrain(datas, value, pointer);
	}
	
	public void onlineSolve(double[] var, double v){
		//continue the solve by online adding new points.
		this.addData(var, v);
		this.nativeOnlineTrain(var, v, pointer);
	}

	private double[][] prepareDataForTrain() {
		double[][] datas = new double[this.getTrainingSetSize()][];
		for (int i = 0; i < datas.length; i++) {
			datas[i] = this.datas.get(i);
		}
		return datas;
	}

	private double[] prepareValueForTrain() {
		double[] value = new double[this.getTrainingSetSize()];
		for (int i = 0; i < value.length; i++) {
			value[i] = this.values.get(i).doubleValue();
		}
		return value;
	}

	@Override
	public void reset() {
		super.reset();
		cfinalize();
	}

	private void cfinalize() {
		if (this.pointer != -1) {
			nativeFinalize(this.pointer);
			this.pointer = -1;
		}
	}

	public void finalize() {
		this.cfinalize();
	}

}
