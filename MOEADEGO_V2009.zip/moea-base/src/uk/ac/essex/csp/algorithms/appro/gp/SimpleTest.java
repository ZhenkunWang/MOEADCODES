package uk.ac.essex.csp.algorithms.appro.gp;

import java.util.Random;

import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.DistributionFactory;
import org.apache.commons.math.distribution.NormalDistribution;


public class SimpleTest {

	public static void main(String[] args) {
		System.loadLibrary("gpcpp");
		EgoApproximator_o ea = new EgoApproximator_o(1);
		Random random = new Random();
		double currentBestValue = Double.MAX_VALUE;
		double[] range = new double[] { -2, 5 };
		for (int i = 0; i < 5; i++) {
			double d = random.nextDouble() * (5 + 2) - 2;
			double y = y(d);
			if (y < currentBestValue)
				currentBestValue = y;
			ea.addData(new double[] { d }, y);
		}
		ea.solve();

		// find the maximim of current ea.
		for (int i = 0; i < 100; i++) {
			double d = findmin(random, ea, currentBestValue);
			System.out.println(d + ", "+currentBestValue);
			double y = y(d);
			if (y < currentBestValue)
				currentBestValue = y;
			ea.addData(new double[] { d }, y);
			ea.solve();
		}

	}

	private static double findmin(Random random, EgoApproximator_o ea,
			double currentBestValue) {
		double max = -1 * Double.MAX_VALUE;
		double x = 0;
		for (int i = 0; i < 100000; i++) {
			double d = random.nextDouble() * (5 + 2) - 2;
			if (ei(d, ea, currentBestValue) > max)
				x = d;
		}
		return x;
	}

	private static double y(double x) {
		return x * x;
	}

	private static NormalDistribution normalDist = DistributionFactory
			.newInstance().createNormalDistribution();;

	private static double ei(double x, EgoApproximator_o ea,
			double currentBestValue) {
		double[] espectingImprovement_ds = ea.estimateWithError(new double[] {x});

		if (espectingImprovement_ds[1] <= 10 * Double.MIN_VALUE) {
			return 0;
		} else if (Double.isNaN(espectingImprovement_ds[1])) {
			return -Double.MAX_VALUE;
		}

		double u = (currentBestValue - espectingImprovement_ds[0])
				/ espectingImprovement_ds[1];
		try {
			double d1 = 0;
			if (u > 16)
				d1 = 1;
			else if (u < -16)
				d1 = 0;
			else
				d1 = normalDist.cumulativeProbability(u);
			double d2 = normalDistPdf(u);

			double d3 = u * d1 + d2;
			double result = espectingImprovement_ds[1] * d3;

			// assert result>=0;
			assert !Double.isNaN(result);
			return result;
		} catch (MathException e) {
			e.printStackTrace();
			return 0;
		}
	}

	public static double normalDistPdf(double x) {
		double part1 = 1d / Math.sqrt(2 * Math.PI);
		double part2 = Math.exp(-1 * x * x / 2);
		return part1 * part2;
	}

}
