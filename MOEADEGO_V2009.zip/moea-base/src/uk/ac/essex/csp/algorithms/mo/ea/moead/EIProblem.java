package uk.ac.essex.csp.algorithms.mo.ea.moead;

import java.util.List;

import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.NormalDistribution;
import org.apache.commons.math.distribution.NormalDistributionImpl;
import org.apache.commons.math.random.JDKRandomGenerator;

import uk.ac.essex.csp.algorithms.appro.gp.DpGpApproximatorJNI;
import uk.ac.essex.csp.algorithms.mo.MultiObjectiveProblem;
import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;
import uk.ac.essex.csp.algorithms.mo.ea.CMoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoChromosome;
import uk.ac.essex.csp.algorithms.mo.ea.MoeaGenotype;
import uk.ac.essex.csp.algorithms.statictics.LHSDesign;

public class EIProblem extends AbstractCMOProblem {
	public MultiObjectiveProblem mop;
	private DpGpApproximatorJNI[] models;
	private double[] bestObj;
	private MoeaGenotype genotype;
	List<MoChromosome> resultset;

	public EIProblem(MultiObjectiveProblem mop, List<MoChromosome> resultset,
			MoeaGenotype genotype, int deisgn) {
		this.mop = mop;
		this.models = new DpGpApproximatorJNI[mop.getObjectiveSpaceDimension()];
		this.bestObj = new double[mop.getObjectiveSpaceDimension()];
		this.resultset = resultset;
		this.genotype = genotype;
		this.genotype.setMultiObjectiveProblem(this);
		init();
		this.buildInitModel(deisgn);
	}

	@Override
	protected void init() {
		this.parDimension = mop.getParameterSpaceDimension();
		this.domain = new double[this.parDimension][2];
		for (int i = 0; i < parDimension; i++) {
			domain[i][0] = mop.getDomain()[i][0];
			domain[i][1] = mop.getDomain()[i][1];
		}

		this.objDimension = mop.getObjectiveSpaceDimension();
		this.range = new double[objDimension][2];
		this.idealpoint = new double[] { 0, 0 };
		for (int i = 0; i < bestObj.length; i++)
			bestObj[i] = Double.MAX_VALUE;
	}

	private double[] estimateresult = new double[2];

	public void evaluate(double[] sp, double[] obj) {
		for (int i = 0; i < objDimension; i++) {
			this.models[i].estimate(sp, estimateresult);
			obj[i] = -EI(estimateresult, i);
		}
	}

	private void buildInitModel(int number) {
		int pd = mop.getParameterSpaceDimension();
		for (int i = 0; i < this.models.length; i++) {
			this.models[i] = new DpGpApproximatorJNI(pd);
		}

		double[][] design = LHSDesign.betterDesign(number, pd,
				new JDKRandomGenerator());

		for (int i = 0; i < number; i++) {
			for (int j = 0; j < pd; j++) {
				double max = domain[j][1];
				double min = domain[j][0];
				design[i][j] = (max - min) * design[i][j] + min;
			}
		}

		// double[] o = new double[this.objDimension];
		for (int i = 0; i < number; i++) {

			CMoChromosome chrom = (CMoChromosome) genotype.createChromosome();
			chrom.copyFrom(design[i]);
			mop.evaluate(chrom);
			this.resultset.add(chrom);

			for (int j = 0; j < models.length; j++) {
				models[j].addData(chrom.realGenes, chrom.objectivesValue[j]);
				if (chrom.objectivesValue[j] < bestObj[j])
					bestObj[j] = chrom.objectivesValue[j];
			}
		}

		for (int j = 0; j < models.length; j++)
			models[j].solve();

		System.out
				.println("Init Model Build with " + number + " design points");
	}

	public void updateModel(CMoChromosome c) {
		double[] o = new double[this.objDimension];
		mop.evaluate(c.realGenes, o);
		for (int i = 0; i < models.length; i++) {
			// this.models[i].onlineSolve(c.realGenes, o[i]);
			if (o[i] < bestObj[i])
				bestObj[i] = o[i];

			this.models[i].addData(c.realGenes, o[i]);
			this.models[i].solve();
		}
	}

	private double EI(double[] objective_estimate, int i) {
		if (objective_estimate[1] <= 10 * Double.MIN_VALUE) {
			return 0;
		} else if (Double.isNaN(objective_estimate[1])) {
			return -Double.MAX_VALUE;
		}

		double u = (bestObj[i] - objective_estimate[0]) / objective_estimate[1];
		try {
			double d1 = 0;
			if (u > 10)
				d1 = 1;
			else if (u < -10)
				d1 = 0;
			else
				d1 = normalDist.cumulativeProbability(u);
			double d2 = normalDistPdf(u);

			double d3 = 0.5 * u * d1 + (1 - 0.5) * d2;
			double result = objective_estimate[1] * d3;

			// assert result>=0;
			assert !Double.isNaN(result);
			return result;
		} catch (MathException e) {
			e.printStackTrace();
			return 0;
		}
	}

	public NormalDistribution normalDist = new NormalDistributionImpl();

	public static double normalDistPdf(double x) {
		double part1 = 1d / Math.sqrt(2 * Math.PI);
		double part2 = Math.exp(-1 * x * x / 2);
		return part1 * part2;
	}
}
