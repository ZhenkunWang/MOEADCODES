package uk.ac.essex.csp.algorithms.cluster;


/**
 * 
 * This class is the entry point for constructing Cluster Analysis objects. Each
 * instance of JCA object is associated with one or more clusters, and a Vector
 * of DataPoint objects. The JCA and DataPoint classes are the only classes
 * available from other packages.
 * 
 * @see DataPoint
 * 
 */

public class JCA {
	private Cluster[] clusters;

	private int miter;

	private DataPoint[] mDataPoints;

	private double mSWCSS;

	private int dimension;

	public JCA(int k, int iter, DataPoint[] dataPoints, int dimension) {
		clusters = new Cluster[k];
		for (int i = 0; i < k; i++) {
			clusters[i] = new Cluster("Cluster" + i);
		}
		this.miter = iter;
		this.mDataPoints = dataPoints;
		this.dimension = dimension;
	}

	private void calcSWCSS() {
		double temp = 0;
		for (int i = 0; i < clusters.length; i++) {
			temp = temp + clusters[i].getSumSqr();
		}
		mSWCSS = temp;
	}

	public void startAnalysis() {
		// set Starting centroid positions - Start of Step 1
		setInitialCentroids();
		int n = 0;
		// assign DataPoint to clusters
		loop1: while (true) {
			for (int l = 0; l < clusters.length; l++) {
				clusters[l].addDataPoint(mDataPoints[n]);
				n++;
				if (n >= mDataPoints.length)
					break loop1;
			}
		}

		// calculate E for all the clusters
		calcSWCSS();

		// recalculate Cluster centroids - Start of Step 2
		for (int i = 0; i < clusters.length; i++) {
			clusters[i].getCentroid().calcCentroid();
		}

		// recalculate E for all the clusters
		calcSWCSS();

		for (int i = 0; i < miter; i++) {
			// enter the loop for cluster 1
			for (int j = 0; j < clusters.length; j++) {
				for (int k = 0; k < clusters[j].getNumDataPoints(); k++) {

					// pick the first element of the first cluster
					// get the current Euclidean distance
					double tempEuDt = clusters[j].getDataPoint(k)
							.getCurrentEuDt();
					Cluster tempCluster = null;
					boolean matchFoundFlag = false;

					// call testEuclidean distance for all clusters
					for (int l = 0; l < clusters.length; l++) {

						// if testEuclidean < currentEuclidean then
						if (tempEuDt > clusters[j].getDataPoint(k)
								.testEuclideanDistance(
										clusters[l].getCentroid())) {
							tempEuDt = clusters[j].getDataPoint(k)
									.testEuclideanDistance(
											clusters[l].getCentroid());
							tempCluster = clusters[l];
							matchFoundFlag = true;
						}
					}

					if (matchFoundFlag) {
						tempCluster.addDataPoint(clusters[j].getDataPoint(k));
						clusters[j]
								.removeDataPoint(clusters[j].getDataPoint(k));
						for (int m = 0; m < clusters.length; m++) {
							clusters[m].getCentroid().calcCentroid();
						}

						// for variable 'm' - Recalculating centroids for all
						// Clusters

						calcSWCSS();
					}
				}
			}// for variable 'j' - Looping through all the Clusters.
		}// for variable 'i' - Number of iterations.
	}

	private void setInitialCentroids() {
		// kn = (round((max-min)/k)*n)+min where n is from 0 to (k-1).
		double[] c = new double[dimension];
		double[] min = new double[dimension];
		double[] max = new double[dimension];
		for (int i=0;i<dimension;i++) {
			min[i]=Double.MAX_VALUE;
			max[i]=-Double.MAX_VALUE;
		}
			
		for (int i=0;i<mDataPoints.length;i++) {
			DataPoint point = mDataPoints[i];
			for (int j=0;j<dimension;j++) {
				if (point.point[j]<min[j])
					min[j]=point.point[j];
				if (point.point[j]>max[j])
					max[j]=point.point[j];
			}
		}
		
		for (int n = 1; n <= clusters.length; n++) {
			for (int i = 0; i < dimension; i++)
				c[i] = (((max[i] - min[i]) / (clusters.length + 1)) * n)
						+ max[i];
			Centroid c1 = new Centroid(c);
			clusters[n - 1].setCentroid(c1);
			c1.setCluster(clusters[n - 1]);
		};
	}

	public int getKValue() {
		return clusters.length;
	}

	public int getIterations() {
		return miter;
	}

	public int getTotalDataPoints() {
		return mDataPoints.length;
	}

	public double getSWCSS() {
		return mSWCSS;
	}

	public Cluster getCluster(int pos) {
		return clusters[pos];
	}
}