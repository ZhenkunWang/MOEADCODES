package uk.ac.essex.csp.algorithms.appro.gp;

public class DpGpApproximatorJNI extends GpApproximatorJNI {

	static {
		System.loadLibrary("gpcpp");
	}

	protected native long nativeInitialize(int dimension, int number);

	protected native void nativeFinalize(long pointer);

	protected native void nativeTrain(double[][] datas, double[] values,
			long pointer);

	/**
	 * this method estimate the unknown point with the cloest cluster.
	 */
	protected native void nativeEstimate(double[] variable, double[] result,
			long pointer);

	/**
	 * this method estimate the unknown point with the fuzzy weight to every
	 * center.
	 */
	private native void nativeEstimate2(double[] variable, double[] result,
			long pointer);

	public DpGpApproximatorJNI(int d) {
		super(d);
		this.pointer = nativeInitialize(dimension, 0);
	}

	public double estimate(double[] x) {
		double[] result = { 0, 0 };
		this.estimate(x, result);
		return result[0];
	}

	public void estimate2(double[] x, double[] ys) {
		if (this.pointer == -1)
			throw new IllegalStateException(
					"the model has not been trained yet");

		nativeEstimate2(x, ys, this.pointer);
	}

	public void estimate(double[] x, double[] ys) {
		if (this.pointer == -1)
			throw new IllegalStateException(
					"the model has not been trained yet");

		nativeEstimate(x, ys, this.pointer);
	}

	public void solve() {
		// cfinalize();// remove the old c++objective. if it existed.
		// this.pointer = nativeInitialize(dimension,
		// this.getTrainingSetSize());
		double[][] datas = this.prepareDataForTrain();
		double[] value = this.prepareValueForTrain();
		this.nativeTrain(datas, value, pointer);
	}

	public void onlineSolve(double[] var, double v) {
		// continue the solve by online adding new points.
		throw new UnsupportedOperationException(
				"online solve Method not Supported in DPGP");
	}

	private double[][] prepareDataForTrain() {
		double[][] datas = new double[this.getTrainingSetSize()][];
		for (int i = 0; i < datas.length; i++) {
			datas[i] = this.datas.get(i);
		}
		return datas;
	}

	private double[] prepareValueForTrain() {
		double[] value = new double[this.getTrainingSetSize()];
		for (int i = 0; i < value.length; i++) {
			value[i] = this.values.get(i).doubleValue();
		}
		return value;
	}

	@Override
	public void reset() {
		this.datas.clear();
		this.values.clear();
	}

	private void cfinalize() {
		if (this.pointer != -1) {
			nativeFinalize(this.pointer);
			this.pointer = -1;
		}
	}

	public void finalize() {
		this.cfinalize();
	}

}
