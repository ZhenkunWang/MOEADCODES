package uk.ac.essex.csp.algorithms.mo.prolem;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;

/**
 * Adpoted from the parGEO's paper on TEC.
 * 
 * @author wudong
 * 
 */
public class DTLZ2 extends AbstractCMOProblem {

	public DTLZ2(int d) {
		parDimension = d;
		init();
	}

	@Override
	protected void init() {
		this.domain = new double[this.parDimension][2];

		for (int i = 0; i < parDimension; i++) {
			domain[i][0] = 0;
			domain[i][1] = 1;
		}

		this.objDimension = 3;
		this.range = new double[objDimension][2];
		this.idealpoint = new double[] { 0, 0, 0 };
	}

	// @Override
	// protected SquareDimentionalSpace createProblemDomain() {
	// double[][] domain = { { 0, 1 }, { 0, 1 } ,{ 0, 1 }, { 0, 1 },{ 0, 1 }, {
	// 0, 1 }};
	// return new SquareDimentionalSpace(domain);
	// }

	public void evaluate(double[] x, double[] y) {
		double g = 0.0;
		for (int i = 2; i < parDimension; i++)
			g += (x[i] - 0.5) * (x[i] - 0.5);

		y[0] = (1 + g) * Math.cos(x[0] * Math.PI / 2)
				* Math.cos(x[1] * Math.PI / 2);
		y[1] = (1 + g) * Math.cos(x[0] * Math.PI / 2)
				* Math.sin(x[1] * Math.PI / 2);
		y[2] = (1 + g) * Math.sin(x[0] * Math.PI / 2);
	}

	public static final DTLZ2 getInstance(int d) {
		if (instance == null) {
			instance = new DTLZ2(d);
			instance.name = "DTLZ2_" + d;
		}
		return instance;
	}

	private static DTLZ2 instance;
}
