package uk.ac.essex.csp.algorithms.mo.prolem;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;

public class CEC0906 extends AbstractCMOProblem {

	private static int N = 2;
	private static double a = 0.1;

	public void evaluate(double[] x, double[] y) {
		double oldsum = 0, evensum = 0;
		double oldprod = 1, evenprod = 1;
		int evencount = 0, oldcount = 0;
		for (int j = 2; j <= parDimension; j++) {
			double yj = x[j - 1]
					- Math.sin(6 * Math.PI * x[0] + j * Math.PI / parDimension);
			double v = h(yj);
			double prod = Math.cos(20*yj*Math.PI/Math.sqrt(j));
			if (j % 2 == 0) {
				evensum += v;
				evenprod *= prod;
				evencount++;
			} else {
				oldsum += v;
				oldprod *= prod;
				oldcount++;
			}
			y[0] = x[0]
					+ Math.max(0, 2 * (0.5 / (N) + a)
							* Math.sin(2 * N * Math.PI * x[0])) + 2
					* (4*oldsum - 2*oldprod +2) / (double) oldcount;
			y[1] = 1
					- x[0]
					+ Math.max(0, 2 * (0.5 / (N) + a)
							* Math.sin(2 * N * Math.PI * x[0])) + 2
					* (4*evensum - 2*evenprod +2) / (double) evencount;
		}
	}

	private double h(double x) {
		return x * x;
	}

	@Override
	protected void init() {
		this.domain = new double[this.parDimension][2];
		domain[0][0] = 0;
		domain[0][1] = 1;
		for (int i = 1; i < parDimension; i++) {
			domain[i][0] = -1;
			domain[i][1] = 1;
		}

		this.objDimension = 2;
		this.range = new double[objDimension][2];
		this.idealpoint = new double[] { 0, 0 };
	}

	public CEC0906(int pd) {
		this.parDimension = pd;
		init();
	}

	public static final CEC0906 getInstance(int d) {
		if (instance == null) {
			instance = new CEC0906(d);
			instance.name = "CEC0906_"+d;
		}
		return instance;
	}

	private static CEC0906 instance;
}
