package uk.ac.essex.csp.algorithms.mo.prolem.so;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;


/**
 * The Brainin Function with three global optima and no local optima.
 * <p>the optimal value: 0.397887346
 * <p>the optimal point: 
 *  <ol>
 *  	<li>x1 = -3.141592, x2 = 12.274999
 *  	<li>x1 = 3.141592, x2 = 2.275
 *  	<li>x1 = 9.424777, x2 = 2.474999
 *  </ol>
 *  This is a multimodal, and non-separable.
 *  see <A href="http://www.it.lut.fi/ip/evo/functions/node27.html">
 *  this <A> for more detail.
 */
public class Branin extends AbstractCMOProblem {

	@Override
	protected void init() {
		this.domain = new double[this.parDimension][2];

		domain[0][0] = -5;
		domain[0][1] = 10;

		domain[1][0] = 0;
		domain[1][1] = 15;

		this.objDimension = 1;
		this.range = new double[objDimension][2];
		// this.idealpoint = new double[] { 0, 0 };
	}

	public void evaluate(double[] sp, double[] obj) {
		double x1 = sp[0], x2 = sp[1], y = 0;
		y = x2 - 5.1 * x1 * x1 / (4 * Math.PI * Math.PI) + 5 * x1 / Math.PI - 6;
		y = y * y;
		y += 10 * (1 - 1 / (8 * Math.PI)) * Math.cos(x1) + 10;
		obj[0] = y;
	}

	public Branin() {
		this.parDimension = 2;
		init();
	}

	public static final Branin getInstance() {
		if (instance == null) {
			instance = new Branin();
			instance.name = "Branin";
		}
		return instance;
	}

	private static Branin instance;
}
