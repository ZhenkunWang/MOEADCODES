package uk.ac.essex.csp.algorithms.mo.prolem.so;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;

//http://www.it.lut.fi/ip/evo/functions/node5.html
public class NormalizedSchwefel extends AbstractCMOProblem {

	@Override
	protected void init() {
		this.domain = new double[this.parDimension][2];

		for (int i = 0; i < parDimension; i++) {
			domain[i][0] = -512;
			domain[i][1] = 512;
		}

		this.objDimension = 1;
		this.range = new double[objDimension][2];
		// this.idealpoint = new double[] { 0, 0 };
	}

	public void evaluate(double[] sp, double[] obj) {
		double sum = 0;
		for (int i = 0; i < sp.length; i++) {
			double d = -sp[i] * Math.sin(Math.sqrt(Math.abs(sp[i])));
			sum += d;
		}
		obj[0] = sum / this.parDimension;
	}

	public NormalizedSchwefel(int pd) {
		this.parDimension = pd;
		init();
	}

	public static final NormalizedSchwefel getInstance(int d) {
		if (instance == null) {
			instance = new NormalizedSchwefel(d);
			instance.name = "NormalizedSchwefel_" + d;
		}
		return instance;
	}

	private static NormalizedSchwefel instance;

}
