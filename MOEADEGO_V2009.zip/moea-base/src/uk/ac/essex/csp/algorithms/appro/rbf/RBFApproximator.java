package uk.ac.essex.csp.algorithms.appro.rbf;

import uk.ac.essex.csp.algorithms.appro.AbstractFunctionApproximator;

public class RBFApproximator extends AbstractFunctionApproximator {

	private int number;
	private int dimension;
	private double[] betas;
	private double[] alphas;
	private int degree;
	private int selection; 
	private double beta, c;

	private double[][] datas;
	private double[] values;
	
	private native void nativeSolve(double[][]datas, double[] values,
			double[] betas, double[] alphas,int degree,int selection, double beta, double c);
	
	private native double nativeEstimate(double[][]datas, double[] values, double[] variable, 
			double[] betas, double[] alphas, int degree,int selection, double beta, double c);
	
	public double estimate(double[] x) {
		if (datas==null)
			throw new IllegalStateException("The approximation hasn't been trained.");
		return nativeEstimate(datas, values, x, betas, alphas, degree, selection, beta, c);
	}

	public void solve() {
		nativeSolve(datas, values, betas, alphas, degree, selection, beta, c);
	}

	@Override
	public void setData(double[][] xs, double[] y) {
		assert (xs.length != y.length);
		//super.setData(xs, y);
		this.datas = xs;
		this.values = y;
		
		this.number = y.length;
		this.dimension = xs[0].length;
		
		this.betas = new double[this.number];
		this.alphas = new double[this.dimension+1];
		
		this.selection = 1;
		this.degree = 1;
	}

	@Override
	public void addData(double[] x, double y) {
		throw new UnsupportedOperationException(
				"Add Data is not allowed in RBF approximation method, please use Set Data instead.");
	}

	public void estimate(double[] x, double[] ys) {
		// TODO Auto-generated method stub
		
	}
}
