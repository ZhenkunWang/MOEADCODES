package uk.ac.essex.csp.algorithms.mo.prolem;

import uk.ac.essex.csp.algorithms.mo.ea.AbstractCMOProblem;

public class CEC0908 extends AbstractCMOProblem {

	public void evaluate(double[] x, double[] y) {
		double sum1 = 0, sum2 = 0, sum3=0;
		int count1 = 0, count2 = 0, count3 = 0;
		for (int j = 3; j <= parDimension; j++) {
			double yj = x[j - 1]
					- 2*x[1]*Math.sin(2 * Math.PI * x[0] + j * Math.PI / parDimension);
			double v = h(yj);
			if (j % 3 == 1) {
				sum1 += v;
				count1++;
			} else if(j % 3 == 2) {
				sum2 += v;
				count2++;
			} else {
				sum3 += v;
				count3++;
			}
			y[0] = Math.cos(0.5*x[0]*Math.PI)*Math.cos(0.5*x[1]*Math.PI) + 2 * (sum1) / (double) count1;
			y[1] = Math.cos(0.5*x[0]*Math.PI)*Math.sin(0.5*x[1]*Math.PI) + 2 * (sum2) / (double) count2;
			y[2] = Math.sin(0.5*x[0]*Math.PI) + 2 * (sum3) / (double) count3;
		}
	}

	private double h(double x) {
		// return Math.abs(x) / (1 + Math.exp(2 * Math.abs(x)));
		return x * x;
	}

	@Override
	protected void init() {
		this.domain = new double[this.parDimension][2];

		domain[0][0] = 0;
		domain[0][1] = 1;

		domain[1][0] = 0;
		domain[1][1] = 1;

		for (int i = 2; i < parDimension; i++) {
			domain[i][0] = -2;
			domain[i][1] = 2;
		}

		this.objDimension = 3;
		this.range = new double[objDimension][2];
		this.idealpoint = new double[] { 0, 0, 0 };
	}

	public CEC0908(int pd) {
		this.parDimension = pd;
		init();
	}

	public static final CEC0908 getInstance(int d) {
		if (instance == null) {
			instance = new CEC0908(d);
			instance.name = "CEC0908_"+d;
		}
		return instance;
	}

	private static CEC0908 instance;
}
