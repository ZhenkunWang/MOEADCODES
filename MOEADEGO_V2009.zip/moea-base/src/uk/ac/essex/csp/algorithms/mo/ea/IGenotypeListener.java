package uk.ac.essex.csp.algorithms.mo.ea;

import java.util.List;

import uk.ac.essex.csp.algorithms.mo.Scalarization;

public interface IGenotypeListener {
	public <T extends Scalarization> void generationBegin(List<T> pop,
			List<T> focus, int generation);

	public <T extends Scalarization> void generationEnd(List<T> pop, int generation);

	public <T extends Scalarization> void initFinish(List<T> subproblems);

	public void solveStart();

	public void solveEnd();

	public <T extends Scalarization> void evaluationStart(MoChromosome chromosome,
			List<T> subproblems, int evalnumber);

	public <T extends Scalarization> void evaluationEnd(MoChromosome chromosome,
			List<T> subproblems, int evalnumber);

	public <T extends Scalarization> void populationAdjust(List<T> pops,
			boolean add, int generation);
}
