package uk.ac.essex.csp.algorithms.mo.ea;

import uk.ac.essex.csp.algorithms.mo.MultiObjectiveProblem;
import uk.ac.essex.csp.algorithms.mo.prolem.CEC0901;
import uk.ac.essex.csp.algorithms.mo.prolem.CEC0902;
import uk.ac.essex.csp.algorithms.mo.prolem.CEC0903;
import uk.ac.essex.csp.algorithms.mo.prolem.CEC0904;
import uk.ac.essex.csp.algorithms.mo.prolem.CEC0905;
import uk.ac.essex.csp.algorithms.mo.prolem.CEC0906;
import uk.ac.essex.csp.algorithms.mo.prolem.CEC0907;
import uk.ac.essex.csp.algorithms.mo.prolem.CEC0908;
import uk.ac.essex.csp.algorithms.mo.prolem.CEC0909;
import uk.ac.essex.csp.algorithms.mo.prolem.CEC0910;
import uk.ac.essex.csp.algorithms.mo.prolem.DTLZ1;
import uk.ac.essex.csp.algorithms.mo.prolem.DTLZ2;
import uk.ac.essex.csp.algorithms.mo.prolem.DTLZ5;
import uk.ac.essex.csp.algorithms.mo.prolem.KNO1;
import uk.ac.essex.csp.algorithms.mo.prolem.LZF1;
import uk.ac.essex.csp.algorithms.mo.prolem.LZF2;
import uk.ac.essex.csp.algorithms.mo.prolem.LZF3;
import uk.ac.essex.csp.algorithms.mo.prolem.LZF4;
import uk.ac.essex.csp.algorithms.mo.prolem.LZF5;
import uk.ac.essex.csp.algorithms.mo.prolem.OKA1;
import uk.ac.essex.csp.algorithms.mo.prolem.OKA1O;
import uk.ac.essex.csp.algorithms.mo.prolem.VLMOP2;
import uk.ac.essex.csp.algorithms.mo.prolem.VLMOP3;
import uk.ac.essex.csp.algorithms.mo.prolem.ZDT1;
import uk.ac.essex.csp.algorithms.mo.prolem.ZDT2;
import uk.ac.essex.csp.algorithms.mo.prolem.ZDT3;
import uk.ac.essex.csp.algorithms.mo.prolem.ZDT4;
import uk.ac.essex.csp.algorithms.mo.prolem.ZDT6;
import uk.ac.essex.csp.algorithms.mo.prolem.so.GeneralizedRastrigin;
import uk.ac.essex.csp.algorithms.mo.prolem.so.GeneralizedRosenbrock;
import uk.ac.essex.csp.algorithms.mo.prolem.so.NormalizedSchwefel;
import uk.ac.essex.csp.algorithms.mo.prolem.so.RotatedEllipsoidal;

public abstract class AbstractMOP implements MultiObjectiveProblem {
	protected String name;
	protected double[][] domain;
	protected double[][] range;
	protected double[] idealpoint;
	protected int objDimension;
	protected int parDimension;

	public String getName() {
		return name;
	}

	public double[] getIdealPoint() {
		return idealpoint;
	}

	public int getObjectiveSpaceDimension() {
		return objDimension;
	}

	public int getParameterSpaceDimension() {
		return parDimension;
	}

	public double[][] getRange() {
		return range;
	}

	public double[][] getDomain() {
		return domain;
	}

	protected abstract void init();

	protected abstract MoChromosome createMoChromosomeInstance();

	/**
	 * 
	 * @param problemName
	 * @param dimension
	 * @return
	 */
	public static MultiObjectiveProblem getProblem(String problemName,
			int dimension) {
		if (problemName.equalsIgnoreCase("zdt1")) {
			if (dimension != 0)
				return ZDT1.getInstance(dimension);
			else
				return ZDT1.getInstance(4);
		} else if (problemName.equalsIgnoreCase("zdt2")) {
			if (dimension != 0)
				return ZDT2.getInstance(dimension);
			else
				return ZDT2.getInstance(4);
		} else if (problemName.equalsIgnoreCase("zdt3")) {
			if (dimension != 0)
				return ZDT3.getInstance(dimension);
			else
				return ZDT3.getInstance(4);
		} else if (problemName.equalsIgnoreCase("zdt4")) {
			if (dimension != 0)
				return ZDT4.getInstance(dimension);
			else
				return ZDT3.getInstance(4);
		} else if (problemName.equalsIgnoreCase("zdt6")) {
			if (dimension != 0)
				return ZDT6.getInstance(dimension);
			else
				return ZDT3.getInstance(4);
		}

		else if (problemName.equalsIgnoreCase("cec01")) {
			if (dimension != 0)
				return CEC0901.getInstance(dimension);
			else
				return CEC0901.getInstance(10);
		}

		else if (problemName.equalsIgnoreCase("cec02")) {
			if (dimension != 0)
				return CEC0902.getInstance(dimension);
			else
				return CEC0902.getInstance(10);
		}

		else if (problemName.equalsIgnoreCase("cec03")) {
			if (dimension != 0)
				return CEC0903.getInstance(dimension);
			else
				return CEC0903.getInstance(10);
		}

		else if (problemName.equalsIgnoreCase("cec04")) {
			if (dimension != 0)
				return CEC0904.getInstance(dimension);
			else
				return CEC0904.getInstance(10);
		}

		else if (problemName.equalsIgnoreCase("cec05")) {
			if (dimension != 0)
				return CEC0905.getInstance(dimension);
			else
				return CEC0905.getInstance(10);
		}

		else if (problemName.equalsIgnoreCase("cec06")) {
			if (dimension != 0)
				return CEC0906.getInstance(dimension);
			else
				return CEC0906.getInstance(10);
		}

		else if (problemName.equalsIgnoreCase("cec07")) {
			if (dimension != 0)
				return CEC0907.getInstance(dimension);
			else
				return CEC0907.getInstance(10);
		}

		else if (problemName.equalsIgnoreCase("cec08")) {
			if (dimension != 0)
				return CEC0908.getInstance(dimension);
			else
				return CEC0908.getInstance(10);
		}

		else if (problemName.equalsIgnoreCase("cec09")) {
			if (dimension != 0)
				return CEC0909.getInstance(dimension);
			else
				return CEC0909.getInstance(10);
		}

		else if (problemName.equalsIgnoreCase("cec10")) {
			if (dimension != 0)
				return CEC0910.getInstance(dimension);
			else
				return CEC0910.getInstance(10);
		}

		else if (problemName.equalsIgnoreCase("lzf1")) {
			if (dimension != 0)
				return LZF1.getInstance(dimension);
			else
				return LZF1.getInstance(4);
		} else if (problemName.equalsIgnoreCase("lzf2")) {
			if (dimension != 0)
				return LZF2.getInstance(dimension);
			else
				return LZF2.getInstance(4);
		} else if (problemName.equalsIgnoreCase("lzf3")) {
			if (dimension != 0)
				return LZF3.getInstance(dimension);
			else
				return LZF3.getInstance(4);
		} else if (problemName.equalsIgnoreCase("lzf4")) {
			if (dimension != 0)
				return LZF4.getInstance(dimension);
			else
				return LZF4.getInstance(4);
		} else if (problemName.equalsIgnoreCase("lzf5")) {
			if (dimension != 0)
				return LZF5.getInstance(dimension);
			else
				return LZF5.getInstance(4);
		} else if (problemName.equalsIgnoreCase("kno1")) {
			return KNO1.getInstance();
			// ====================oka1=====================
		} else if (problemName.equalsIgnoreCase("oka1")) {
			return OKA1.getInstance();
		} else if (problemName.equalsIgnoreCase("oka1o")) {
			return OKA1O.getInstance();
		} else if (problemName.equalsIgnoreCase("vlmop2")) {
			return VLMOP2.getInstance();
		} else if (problemName.equalsIgnoreCase("vlmop3")) {
			return VLMOP3.getInstance();
		}

		else if (problemName.equalsIgnoreCase("dtlz1")) {
			if (dimension != 0)
				return DTLZ1.getInstance(dimension);
			else
				return DTLZ1.getInstance(4);
		} else if (problemName.equalsIgnoreCase("dtlz2")) {
			if (dimension != 0)
				return DTLZ2.getInstance(dimension);
			else
				return DTLZ2.getInstance(4);
		} else if (problemName.equalsIgnoreCase("dtlz5")) {
			if (dimension != 0)
				return DTLZ5.getInstance(dimension);
			else
				return DTLZ5.getInstance(4);
		} else if (problemName.equalsIgnoreCase("so1")) {
			if (dimension != 0)
				return RotatedEllipsoidal.getInstance(dimension);
			else
				return RotatedEllipsoidal.getInstance(4);
		} else if (problemName.equalsIgnoreCase("so2")) {
			if (dimension != 0)
				return GeneralizedRosenbrock.getInstance(dimension);
			else
				return GeneralizedRosenbrock.getInstance(4);
		} else if (problemName.equalsIgnoreCase("so3")) {
			if (dimension != 0)
				return GeneralizedRastrigin.getInstance(dimension);
			else
				return GeneralizedRastrigin.getInstance(4);
		} else if (problemName.equalsIgnoreCase("so4")) {
			if (dimension != 0)
				return NormalizedSchwefel.getInstance(dimension);
			else
				return NormalizedSchwefel.getInstance(4);
		}

		else
			return null;
	}
}
