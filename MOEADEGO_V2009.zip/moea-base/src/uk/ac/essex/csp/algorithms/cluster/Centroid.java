package uk.ac.essex.csp.algorithms.cluster;

/**
 * This class represents the Centroid for a Cluster. The initial centroid is calculated
 * using a equation which divides the sample space for each dimension into equal parts
 * depending upon the value of k.
 * @author Shyam Sivaraman
 * @version 1.0
 * @see Cluster
 */

public class Centroid {
//    private double mCx, mCy;
    public double[] point;
    private Cluster mCluster;

    public Centroid(double[] p) {
    	this.point = new double[p.length];
    	System.arraycopy(p, 0, point, 0, point.length);
    }

    public void calcCentroid() { //only called by CAInstance
        int numDP = mCluster.getNumDataPoints();
        double[] tempC = new double[point.length];
        for (int d =0;d<point.length;d++) {
        //caluclating the new Centroid
        	for (int i = 0; i < numDP; i++) {
        		tempC[d] = tempC[d] + mCluster.getDataPoint(i).point[d]; 
        		//total for x
        	}
        	this.point[d] = tempC[d] / numDP;
        }
        //calculating the new Euclidean Distance for each Data Point
        for (int i = 0; i < numDP; i++) {
            mCluster.getDataPoint(i).calcEuclideanDistance();
        }
        //calculate the new Sum of Squares for the Cluster
        mCluster.calcSumOfSquares();
    }

    public void setCluster(Cluster c) {
        this.mCluster = c;
    }

    public Cluster getCluster() {
        return mCluster;
    }

}