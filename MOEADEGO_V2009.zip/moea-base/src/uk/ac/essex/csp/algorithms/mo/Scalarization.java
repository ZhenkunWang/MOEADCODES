package uk.ac.essex.csp.algorithms.mo;

public abstract class Scalarization {
	protected MultiObjectiveProblem mop;

	public MultiObjectiveProblem getMOP() {
		return mop;
	}

	/**
	 * The scalarization value of the multiobjective problem with the given
	 * objective value from the multiobjective.
	 * 
	 * @param obj
	 * @return
	 */
	public abstract double scalarObjective(double[] obj);

}
