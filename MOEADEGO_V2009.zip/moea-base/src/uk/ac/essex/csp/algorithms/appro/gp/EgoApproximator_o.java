package uk.ac.essex.csp.algorithms.appro.gp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Arrays;

import uk.ac.essex.csp.algorithms.appro.AbstractFunctionApproximator;


public class EgoApproximator_o extends AbstractFunctionApproximator {
	private double[] theta;

	private double[] p;

	private double[][] corMatrix;
	private int[] permutation;

	private double[] otherp = new double[3];// 0: detr, 1: mu, 2: sqaure;

	private int dimension;

	private PrintStream ps;

	private native double[] nativeSolve(double[][] daa, double[] vues, int d,
			int size, double[][] corMatrix, int[] permutation, double[] otherp);

	private native double[] nativeEstimate(double[][] daa, double[] vues,
			double[] theta, double[] p, int d, int size, double[] var,
			double[][] corMatrix, int[] permutation, double[] otherp);

	private native void cfinalize();

	public EgoApproximator_o(int d) {
		this.dimension = d;
		try {
			ps = new PrintStream(new File("egoerror.txt"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public double estimate(double[] x) {
		return estimateWithError(x)[0];
	}

	public double[] estimateWithError(double[] x) {
		if (theta == null || p == null)
			throw new IllegalStateException(
					"The Metamodel has not been solved yet.");

		int size = datas.size();
		double[][] dd = datas.toArray(new double[size][]);
		Double[] ysD = values.toArray(new Double[size]);
		double[] ys = new double[size];

		for (int i = 0; i < size; i++) {
			ys[i] = ysD[i];
		}
		// return nativeEstimate(dd, ys, theta, p, dimension, size, x);
		double d[] = nativeEstimate(dd, ys, theta, p, dimension, size, x,
				corMatrix, permutation, otherp);
		if (Double.isNaN(d[1])) {
			// Check current CorMatrix.
			// Output the evaluated point.
			System.out.println("********Ego Error*******");
			ps.println("@@@@@@@@@@@--Cor Matrix--@@@@@@@@@@@@@@@");
			for (int i = 0; i < corMatrix.length; i++) {
				String string = Arrays.toString(corMatrix[i]);
				ps.println(string.substring(1, string.length() - 1));
			}

			ps.println("@@@@@@@@@@@@@@--Cor Matrix--@@@@@@@@@@@");
			ps.println();
			ps.println("@@@@@@@@@@@--InvCor Matrix--@@@@@@@@@@@@@@@");
			// for (int i = 0; i < invCorMatrix.length; i++) {
			// String string = Arrays.toString(invCorMatrix[i]);
			// ps.println(string.substring(1, string.length() - 1));
			// }
			ps.println("@@@@@@@@@@--InvCor Matrix--@@@@@@@@@@@@@");
			ps.println();
			ps.println("Decision Parameter: " + Arrays.toString(x));
			ps.println("Parameters Theta: " + Arrays.toString(theta));
			ps.println("Parameters P: " + Arrays.toString(p));
			ps.println("Parameters Dtr, Mu and Sigma, : "
					+ Arrays.toString(otherp));
			ps.println();
			ps.println("@@@@@@@@@@@@@@@--Evaluated Points--@@@@@@@@@@@@@@@@@");
			for (int i = 0; i < this.datas.size(); i++) {
				double[] es = this.datas.get(i);
				String string = Arrays.toString(es);
				ps.println(string.substring(1, string.length() - 1));
			}
			ps.println("@@@@@@@@@@@@@@@--Evaluated Values--@@@@@@@@@@@@@@@@@");
			String string = Arrays.toString(ys);
			ps.println(string.substring(1, string.length() - 1));
			ps.println();
			ps.println();
		}
		return d;
	}

	static {
		System.loadLibrary("gpcpp");
	}

	@Override
	protected void finalize() throws Throwable {
		this.cfinalize();
	}

	public void solve() {
		if (theta == null) {
			theta = new double[dimension];
		}
		if (p == null) {
			p = new double[dimension];
		}

		int size = datas.size();
		double[][] dd = datas.toArray(new double[size][]);
		Double[] ysD = values.toArray(new Double[size]);
		double[] ys = new double[size];

		for (int i = 0; i < size; i++) {
			ys[i] = ysD[i];
		}

		corMatrix = new double[size][size];
		// invCorMatrix = new double[size][size];
		permutation = new int[size];
		// double[] estimateParameter = nativeSolve(dd, ys, dimension, size);
		double[] estimateParameter = nativeSolve(dd, ys, dimension, size,
				corMatrix, permutation, otherp);

		System.arraycopy(estimateParameter, 0, theta, 0, dimension);
		System.arraycopy(estimateParameter, dimension, p, 0, dimension);
	}

	public void estimate(double[] x, double[] ys) {
		// TODO Auto-generated method stub
		
	}
}
