#javah -classpath ./bin -o ./ccode/hvjni.h -verbose uk.ac.essex.csp.algorithms.mo.indicator.HyperVolumnJNI
#/usr/lib/jvm/java-6-sun/bin/javah_g -o ./ccode/hvjni_g.h -classpath ./bin -verbose uk.ac.essex.csp.algorithms.appro.gp.GpApproximatorJNI

#javah -classpath ./bin -o ./ccode/kmdpgpapprojni.h -verbose uk.ac.essex.csp.algorithms.appro.gp.KmGpApproximatorJNI

javah -classpath ./bin -o ../gpcpp/include/gslminimisationjni.h -verbose uk.ac.essex.csp.algorithms.optimization.GSLMinimisation
 
