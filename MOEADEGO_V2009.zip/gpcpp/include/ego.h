#ifndef EGO_H_SPEC
#define EGO_H_SPEC

# include <cstdlib>
# include <cmath>
# include <cstdio>
# include <ctime>
# include <string>
# include <gsl/gsl_linalg.h>
# include <gsl/gsl_blas.h>
# include <gsl/gsl_multimin.h>
# include <gsl/gsl_rng.h>
# include <gsl/gsl_errno.h>

double weighteddistance(gsl_vector* var1, gsl_vector* var2, double* theta, double* p, int dimension);
double corr(gsl_vector* var1, gsl_vector* var2, double* theta1, double* p1, int dimension1);
void corvector(gsl_matrix* datas, gsl_vector*var, int number, double* theta, double* p, int dimension, gsl_vector* corvect);
void construct_cormatrix(gsl_matrix* datas, int number, int dimension, double* theta, double* p, gsl_matrix* corMatrixLU);
void decomposite_cormatrix(gsl_matrix* Rm, gsl_permutation* permutation, double* det);
double mu_hat(gsl_matrix* cmLU, gsl_permutation* perm, gsl_vector* ys, int number);
double sigma_squared_hat(gsl_matrix* cmLU, gsl_permutation* perm, gsl_vector* ys, double mu_hat, int number);
double likelihood(gsl_matrix* datas, gsl_vector* values, double* theta,	double* p, int number, int dimension);

void compute_parameters_de(gsl_matrix* datas, gsl_vector* values, int size,
		int dimension, double* theta, double* p);
void compute_parameters2(gsl_matrix* datas, gsl_vector* values, int size, int dimension, double* theta, double* p);
void estimate2(gsl_matrix* datas, gsl_vector* y, int size, int dimension, double* theta, double* p, double* variable, double * result, double* serror,
			gsl_matrix* cmLU, gsl_permutation* perm, double Rdert, double mu, double sigma);



#endif /*EGO_H_*/
