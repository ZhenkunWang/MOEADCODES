/*
 * CFunction.h
 *
 *  Created on: 16-Nov-2008
 *      Author: wliui
 */

#ifndef CFUNCTION_H_
#define CFUNCTION_H_

#include <gsl/gsl_matrix.h>

//the initial h value for numerically computation of derivation.
const double initial_h = 0.01;

// abstract base class for user-defined functions for CSimplex2
class CFunction {

 public:
    // Function to be defined by user
    virtual double func(const gsl_vector&){};

    // the func's number of variable.
    virtual int getNvar(){};

    // Derivative of function numerically calculated
    void deriv(const gsl_vector& x, gsl_vector& d, double initialh);

    //void deriv(gsl_vector& x, gsl_vector& d, double y, double initialh);

    // Hessian matrix of function
    //void hessian(const gsl_vector& p,gsl_matrix* hessi, double d);
};


#endif /* CFUNCTION_H_ */
