/*
 * Optimizer.h
 *
 *  Created on: 16-Nov-2008
 *      Author: wliui
 */

#ifndef OPTIMIZER_H_
#define OPTIMIZER_H_

#include "CFunction.h"

class Optimizer {
public:

	Optimizer();
	virtual ~Optimizer();

	//optimize the given function
	void optmize(CFunction &, const gsl_vector& startpoint, gsl_vector& optpoint, double& optvalue);

private:
	int iteration;
};


#endif /* OPTIMIZER_H_ */
