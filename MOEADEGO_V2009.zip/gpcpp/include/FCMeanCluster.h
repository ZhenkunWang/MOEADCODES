/*
 * FCMeanCluster.h
 *
 *  Created on: 28-Jun-2008
 *      Author: wliui
 */

#ifndef FCMEAN_H_SPEC
#define FCMEAN_H_SPEC

#include <gsl/gsl_matrix.h>

void fcm(gsl_matrix* data, int cluster_n,int data_n, int var_n,
		int exponent, int maxitr, double minfimp,
		gsl_matrix* center, gsl_matrix* U);

void initfcm(int clunster_n, int data_n, gsl_matrix* U);

double stepfcm(gsl_matrix* data, gsl_matrix* center,
		gsl_matrix* U,int data_n, int cluster_n, int var_n, int expo);

void distfcm(gsl_matrix* center, gsl_matrix* data, gsl_matrix* out,
		int cluster_n, int data_n, int var_n);

void kcm(gsl_matrix* data, int cluster_n,int data_n, int var_n,
		int maxitr, double minfimp,	gsl_matrix* center, int* U);

#endif
