#ifndef DPGPMODEL_H_
#define DPGPMODEL_H_


#include <gsl/gsl_matrix.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_permutation.h>
#include <vector>

class DPGpModel{

public:
	DPGpModel(int parDimension);
	~DPGpModel();

	void train(double** datas, double* values, int number);
	void estimate(double* var, double* result);
	void estimate2(double *var, double *result);

	int getSize();
	int getDimension();

private:
	//the value matrix, every row is a value in objective space.
	int var_n;
	int data_n;
	int center_n;
	int model_size;


	std::vector<GpModel*> gpmodels;
	gsl_matrix* centers ;
	gsl_matrix* U ;

	int getModelNumber(int numberofDate);
	void reinit(int number);
};

#endif /*COGPMODEL_H_*/
