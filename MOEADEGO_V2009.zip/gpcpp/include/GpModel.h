#ifndef GPMODEL_H_
#define GPMODEL_H_

#include <gsl/gsl_matrix.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_permutation.h>

class GpModel{

public:
	GpModel();
	GpModel(int dimension);
	~GpModel();

	void init(int d);
	void reinit(int n);
	void train(double** datas, double* values, int n);
	void train(gsl_matrix* datas, gsl_vector* values, int n);
	void estimate(double* var, double* result);
	int getDimension();
	int getSize();
private:

	gsl_matrix* datas;
	gsl_matrix* corMatrixLU;
	gsl_vector* values;
	gsl_permutation* perm;
	int dimension;
	int number;
	double* theta;
	double* p;
	double det;
	double mu_h;
	double sigma_sqrt_h;
	bool trained;
};

#endif /*GPMODEL_H_*/
