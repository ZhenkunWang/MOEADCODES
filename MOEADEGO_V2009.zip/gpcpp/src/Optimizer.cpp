/*
 * Optimizer.cpp
 *
 *  Created on: 16-Nov-2008
 *      Author: wliui
 */

#include "Optimizer.h"
#include <limits>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_blas.h>
#include <iostream>

Optimizer::Optimizer() {

}

Optimizer::~Optimizer() {

}

double cfunc_f(const gsl_vector *v, void *params) {
	CFunction* cf = static_cast<CFunction*> (params);
	return cf->func(*v);
}

void cfunc_df(const gsl_vector *v, void *params, gsl_vector *df) {
	CFunction* cf = static_cast<CFunction*> (params);
	cf->deriv(*v, *df, initial_h);
}

void cfunc_fdf(const gsl_vector *v, void *params, double* f, gsl_vector *df) {
	CFunction* cf = static_cast<CFunction*> (params);
	*f = cf->func(*v);
	cf->deriv(*v, *df, initial_h);
}

void Optimizer::optmize(CFunction &cFunction, const gsl_vector& startpoint, gsl_vector& optpoint, double& optvalue){
	const gsl_multimin_fminimizer_type* T =
		gsl_multimin_fminimizer_nmsimplex;

	gsl_multimin_function f;
	f.n = cFunction.getNvar();
	f.f = &cfunc_f;
	f.params = (void *) &cFunction;

	int status;
	size_t iter = 0;
	double size;

	gsl_vector* ss = gsl_vector_alloc(cFunction.getNvar());
	gsl_vector_set_all (ss, 1e-4);

	//set initial point
	gsl_vector *x = gsl_vector_alloc(f.n);
	gsl_vector_memcpy(x, &startpoint);
	//double d = f.f(x, f.params);

	gsl_multimin_fminimizer *s;

	s = gsl_multimin_fminimizer_alloc(T, f.n);

	gsl_multimin_fminimizer_set(s, &f, x, ss);

	do {
		iter++;
		status = gsl_multimin_fminimizer_iterate(s);

		if (status)
		             break;

        size = gsl_multimin_fminimizer_size (s);
        status = gsl_multimin_test_size (size, 1e-4);

	} while (iter < 300 && status == GSL_CONTINUE);

//	gsl_test(status, "%s, on %s: %i iters (fn+g=%d+%d), f(x)=%g",
//			gsl_multimin_fdfminimizer_name(s), desc, iter, fcount, gcount, s->f);

	gsl_vector_memcpy(&optpoint, s->x);
	optvalue = s->fval;

//	if (optvalue < d)
//		std::cout << "improved by " << (d - optvalue);
//	else
//		std::cout << "waste!";

	gsl_multimin_fminimizer_free(s);
	gsl_vector_free(x);
	gsl_vector_free(ss);
	//return status;
}

/*
void Optimizer::optmize(CFunction &cFunction, const gsl_vector& startpoint, gsl_vector& optpoint, double& optvalue){
	const gsl_multimin_fdfminimizer_type* T =
			gsl_multimin_fdfminimizer_conjugate_pr;

	gsl_multimin_function_fdf f;
	f.n = cFunction.getNvar();
	f.f = &cfunc_f;
	f.df = &cfunc_df;
	f.fdf = &cfunc_fdf;
	f.params = (void *) &cFunction;

	int status;
	size_t iter = 0;
	double step_size;

	//set initial point
	gsl_vector *x = gsl_vector_alloc(f.n);
	gsl_vector_memcpy(x, &startpoint);

	gsl_multimin_fdfminimizer *s;

	step_size = 0.1 * gsl_blas_dnrm2(x);

	s = gsl_multimin_fdfminimizer_alloc(T, f.n);

	gsl_multimin_fdfminimizer_set(s, &f, x, step_size, 0.1);

#ifdef DEBUG
	printf("x "); gsl_vector_fprintf (stdout, s->x, "%g");
	printf("g "); gsl_vector_fprintf (stdout, s->gradient, "%g");
#endif

	do {
		iter++;
		status = gsl_multimin_fdfminimizer_iterate(s);

#ifdef DEBUG
		printf("%i: \n",iter);
		printf("x "); gsl_vector_fprintf (stdout, s->x, "%g");
		printf("g "); gsl_vector_fprintf (stdout, s->gradient, "%g");
		printf("f(x) %g\n",s->f);
		printf("dx %g\n",gsl_blas_dnrm2(s->dx));
		printf("\n");
#endif

		status = gsl_multimin_test_gradient(s->gradient, 1e-3);
	} while (iter < 100 && status == GSL_CONTINUE);

	status |= (fabs(s->f) > 1e-5);

//	gsl_test(status, "%s, on %s: %i iters (fn+g=%d+%d), f(x)=%g",
//			gsl_multimin_fdfminimizer_name(s), desc, iter, fcount, gcount, s->f);

	gsl_vector_memcpy(&optpoint, s->x);
	optvalue = s->f;

	gsl_multimin_fdfminimizer_free(s);
	gsl_vector_free(x);

	//return status;
}
*/
