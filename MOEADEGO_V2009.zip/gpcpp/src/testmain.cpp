#include "GpModel.h"
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include "FCMeanCluster.h"
#include "DPGpModel.h"

double testinitfcm() {
	int cluster_n = 10;
	int data_n = 100;
	gsl_matrix* gsl = gsl_matrix_alloc(cluster_n, data_n);
	initfcm(cluster_n, data_n, gsl);

	for (int i = 0; i < data_n; i++) {
		double sum = 0;
		for (int j = 0; j < cluster_n; j++) {
			double val = gsl_matrix_get(gsl, j, i);
			sum += val;
			if (val > 1 || val < 0)
				printf("error===================\n");
		}
		printf("column: %d: sum: %f\n", i, sum);
	}

	gsl_matrix_free(gsl);
};

double testdist() {
	int center_n = 4;
	int data_n = 6;
	int var_n=3;

	double center[12] = {1, 2, 3, 4, 5, 6 , 7 ,8, 9, 3, 2, 1};
	double data[18] = {3, 4, 5, 2, 1, 6, 3, 2, 9, 5, 2, 3, 4, 7 ,55, 22, 4, 0};

	gsl_matrix* out = gsl_matrix_alloc(center_n, data_n);

	gsl_matrix_view cv = gsl_matrix_view_array(center, center_n, var_n);
	gsl_matrix_view dv = gsl_matrix_view_array(data, data_n, var_n);
	distfcm(&cv.matrix, &dv.matrix, out ,center_n, data_n, var_n);

	for (int i=0;i<center_n;i++)
		for (int j=0;j<data_n;j++){
			printf("%d, %d: %f\n", i, j, gsl_matrix_get(out, i, j));
		}

	gsl_matrix_free(out);
};

double testfcmstep(){
	int center_n = 4;
	int data_n = 6;
	int var_n=3;

	double center[12] = {1, 2, 3, 4, 5, 6 , 7 ,8, 9, 3, 2, 1};
	double data[18] = {3, 4, 5, 2, 1, 6, 3, 2, 9, 5, 2, 3, 4, 7 ,55, 22, 4, 0};

	gsl_matrix_view cv = gsl_matrix_view_array(center, center_n, var_n);
	gsl_matrix_view dv = gsl_matrix_view_array(data, data_n, var_n);

	gsl_matrix* U = gsl_matrix_alloc(center_n, data_n);

	gsl_matrix_set_all(U, 0.25);

	stepfcm(&dv.matrix, &cv.matrix, U, data_n, center_n, var_n, 2);
}

double testfcm(){

	int center_n = 2;
	int data_n = 6;
	int var_n=3;

	double data[18] = {3, 4, 5, 2, 1, 6, 3, 2, 9, 5, 2, 3, 4, 7 ,55, 22, 4, 0};

	gsl_matrix_view dv = gsl_matrix_view_array(data, data_n, var_n);

	gsl_matrix* U = gsl_matrix_alloc(center_n, data_n);
	gsl_matrix* center = gsl_matrix_alloc(center_n, var_n);

	fcm(&dv.matrix, center_n, data_n, var_n, 2, 1000, 10e-5, center, U);

	for (int i=0;i<center_n;i++)
		for (int j=0;j<var_n;j++){
			printf("%d, %d: %f\n", i, j, gsl_matrix_get(center, i, j));
	}

	for (int i=0;i<center_n;i++)
			for (int j=0;j<data_n;j++){
				printf("%d, %d: %f\n", i, j, gsl_matrix_get(U, i, j));
		}
}

double testfunc1(double* var) {
	return sin(var[0]) + cos(var[0]);
}

//basic training.
bool testcase1() {
	int number = 10, dimension = 1;
	GpModel model(dimension);
	double** datas = (double**) malloc(number * sizeof(double*));
	double* values = (double*) malloc(number * sizeof(double));

	for (int i = 0; i < 10; i++) {
		datas[i] = (double*) malloc(1 * sizeof(double));
		double v = i;
		datas[i][0] = v;
		values[i] = testfunc1(datas[i]);
	}

	double result[2];
	double test[1];
	test[0] = 10.2;
	model.train(datas, values, number);
	model.estimate(test, result);

	double realvalue = testfunc1(test);
	printf("estimated value: %f , %f, real value: %f\n", result[0], result[1],
			realvalue);

	//double v=1.1222;
	//printf("v: %f ,abs(v): %f, fabs(v): %f", v, abs(v), fabs(v));

};

////test for the incremental online training.
//bool testcase2() {
//	int number = 10, dimension = 1;
//	GpModel model(dimension, number);
//
//	double** datas = (double**) malloc(number * sizeof(double*));
//	double* values = (double*) malloc(number * sizeof(double));
//
//	for (int i = 0; i < 10; i++) {
//		datas[i] = (double*) malloc(1 * sizeof(double));
//		double v = i;
//		datas[i][0] = v;
//		values[i] = testfunc1(datas[i]);
//	}
//
//	double result[2];
//	double test[1];
//	test[0] = 10.2;
//	model.train(datas, values);
//	model.estimate(test, result);
//
//	double realvalue = testfunc1(test);
//	printf("estimated value: %f , %f, real value: %f\n", result[0], result[1],
//			realvalue);
//
//	double var[1];
//	for (int i = 10; i < 100; i++) {
//		var[0] = i;
//		double val = testfunc1(var);
//		model.onlineTrain(var, val);
//		var[0] = var[0] - 0.3;
//		model.estimate(var, result);
//
//		realvalue = testfunc1(var);
//		printf("estimated value: %f , %f, real value: %f\n\n\n", result[0],
//				result[1], realvalue);
//	}
//
//};

void testDPGPModel(){
	int number = 500, dimension = 1;
	// GpModel model(dimension, number);
	DPGpModel dpgpmodel(dimension);

	double** datas = (double**) malloc(number * sizeof(double*));
	double* values = (double*) malloc(number * sizeof(double));

	for (int i = 0; i < number; i++) {
		datas[i] = (double*) malloc(1 * sizeof(double));
		double v = i;
		datas[i][0] = v;
		values[i] = testfunc1(datas[i]);
	}

	double result[2];
	double test[1];
	test[0] = 10.2;

	//model.train(datas, values);
	//model.estimate(test, result);

	//double realvalue = testfunc1(test);
	//printf("estimated value with GP: %f , %f, real value: %f\n", result[0], result[1],
			//realvalue);

	dpgpmodel.train(datas, values, number);
	dpgpmodel.estimate(test, result);

	double realvalue = testfunc1(test);
	printf("estimated value with DPGP: %f , %f, real value: %f\n", result[0], result[1],
			realvalue);
}

int main() {
	//testinitfcm();
	//testdist();
	//testfcmstep();
	//testfcm();
	testDPGPModel();
	//testcase2();

};

