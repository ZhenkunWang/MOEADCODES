# include "ego.h"
# include "DESolver.h"

#define P_MIN  1
#define P_MAX  2
#define THETA_MIN  0
#define THETA_MAX  100
#define P_SEARCH_STEP 0.001
#define THETA_SEARCH_STEP 0.01
#define DE_POPULATION 30
#define DE_ITERATION 100
#define SIMPLEX_SEARCH_ITERATION 1000
#define SIMPLEX_CONVERGE_TOLLERANCE 0.001

// # define LOG
/*
 void multimin_route(double** datas, double* values, int dimension,int size, double* startpoint, double* xmin, double* fmin);
 double mu_hat(gsl_matrix* cmLU, gsl_permutation* perm, gsl_vector* ys, int number);
 double sigma_squared_hat(gsl_matrix* cmLU, gsl_permutation* perm, gsl_vector* ys, double mu_hat, int number);
 gsl_vector* corvector(double** datas, double*var, int number, double* theta, double* p, int dimension);
 */

//compute the distance between two points based on theta and p, which is estimated before.
/*
 double weighteddistance(double* var1, double* var2, double* theta, double* p, int dimension){
 int i;
 double result = 0;
 for (i=0; i<dimension; i++){
 result+= theta[i]*pow(abs((var1[i]-var2[i])), p[i]);
 }
 return result;
 }
 */

class GPLikelihoodSolver: public DESolver {
public:
	GPLikelihoodSolver(int dim, int pop, double* initpoints, int initnumber) :
		DESolver(dim, pop, initpoints, initnumber) {
		;
	}
	double EnergyFunction(double trial[], bool &bAtSolution);
	void SetParameters(gsl_matrix* ds, gsl_vector* vs, int n, int d) {
		this->datas = ds;
		this->values = vs;
		this->number = n;
		this->dimension = d;
	}

private:
	gsl_matrix* datas;
	gsl_vector* values;
	int number;
	int dimension;
};

double GPLikelihoodSolver::EnergyFunction(double *trial, bool &bAtSolution) {
	double* theta = trial;
	double* p = trial + this->dimension;
	double result = likelihood(this->datas, this->values, theta, p,
			this->number, this->dimension);
	return (result);
}

double weighteddistance(gsl_vector* var1, gsl_vector* var2, double* theta,
		double* p, int dimension) {
	int i;
	double result = 0;
	for (i = 0; i < dimension; i++) {
		double v = gsl_vector_get(var1, i) - gsl_vector_get(var2, i);
		v = fabs(v);
		result += theta[i] * pow(v, p[i]);
	}
	return result;
}

//correlation function of the two points.
/*
 double corr(double* var1, double* var2, double* theta1, double* p1, int dimension1){
 double distance = weighteddistance(var1, var2, theta1, p1, dimension1);
 return exp(-1*distance);
 }*/

double corr(gsl_vector* var1, gsl_vector* var2, double* theta1, double* p1,
		int dimension1) {
	double distance = weighteddistance(var1, var2, theta1, p1, dimension1);
	return exp(-1 * distance);
}

//compute the corvector between the input variable and the data variables.
/*
 gsl_vector* corvector(double** datas, double*var, int number, double* theta, double* p, int dimension){
 int i;
 gsl_vector* result = gsl_vector_alloc(number);
 for (i=0; i<number; i++){
 gsl_vector_set(result, i, corr(var, datas[i], theta, p, dimension) );
 }
 return result;
 }*/

void corvector(gsl_matrix* datas, gsl_vector*var, int number, double* theta,
		double* p, int dimension, gsl_vector* corvect) {
	int i;
	for (i = 0; i < number; i++) {
		gsl_vector_view rowi = gsl_matrix_row(datas, i);
		gsl_vector_set(corvect, i, corr(var, &rowi.vector, theta, p, dimension));
	}
}

//return the correlation matrix of the data.
/*
 gsl_matrix*  construct_cormatrix(double ** datas, int number, int dimension,double* theta, double*p){
 int i, j;
 //construct the correlation matrix.
 gsl_matrix* Rm = gsl_matrix_alloc(number, number);
 for (i=0; i<number; i++){
 gsl_matrix_set(Rm, i, i, 1);
 for (j=i+1; j<number; j++){
 double cor = corr(datas[i], datas[j], theta, p, dimension);
 gsl_matrix_set(Rm, i, j, cor);
 gsl_matrix_set(Rm, j, i, cor);
 }
 }
 return Rm;
 }
 */

void construct_cormatrix(gsl_matrix* datas, int number, int dimension,
		double* theta, double* p, gsl_matrix* corMatrixLU) {
	int i, j;
	for (i = 0; i < number; i++) {
		gsl_matrix_set(corMatrixLU, i, i, 1);
		for (j = i + 1; j < number; j++) {
			gsl_vector_view di, dj;
			di = gsl_matrix_row(datas, i);
			dj = gsl_matrix_row(datas, j);
			double cor = corr(&di.vector, &dj.vector, theta, p, dimension);
			gsl_matrix_set(corMatrixLU, i, j, cor);
			gsl_matrix_set(corMatrixLU, j, i, cor);
		}
	}
}

//construct the decomposition matrix from the data. with the given input.
//the RM is the computed cormatrix from function construct_cormatrix.
//permuation is needed for the LU_decomp.
//det is the result of determint.
void decomposite_cormatrix(gsl_matrix* Rm, gsl_permutation* permutation,
		double* lndet) {
	int s;
	//compute the matrix inverse, but, it's may not necessary to compute the inverse,
	//according to the Gaussian Process Maching Learning book.
	gsl_linalg_LU_decomp(Rm, permutation, &s);

	//compute the determinant.
	//(*det) = gsl_linalg_LU_det(Rm, s);

	(*lndet) = gsl_linalg_LU_lndet(Rm);
	//save the permutation.
}

//estimate the mu_hat.
double mu_hat(gsl_matrix* cmLU, gsl_permutation* perm, gsl_vector* ys,
		int number) {
	double numerator, denominator;

	gsl_vector* one = gsl_vector_alloc(number);
	gsl_vector_set_all(one, 1);

	gsl_vector* temp = gsl_vector_alloc(number);

	gsl_linalg_LU_solve(cmLU, perm, ys, temp);
	gsl_blas_ddot(one, temp, &numerator);

	gsl_linalg_LU_solve(cmLU, perm, one, temp);
	gsl_blas_ddot(one, temp, &denominator);

	gsl_vector_free(one);
	gsl_vector_free(temp);
	return (numerator / denominator);
}

//estimate the sigma_square_hat.
double sigma_squared_hat(gsl_matrix* cmLU, gsl_permutation* perm,
		gsl_vector* ys, double mu_hat, int number) {
	double numerator, denominator;

	int i;
	gsl_vector* diff = gsl_vector_alloc(number);
	denominator = number;

	for (i = 0; i < number; i++) {
		gsl_vector_set(diff, i, gsl_vector_get(ys, i) - mu_hat);
	}

	gsl_vector* temp = gsl_vector_alloc(number);
	gsl_linalg_LU_solve(cmLU, perm, diff, temp);
	gsl_blas_ddot(diff, temp, &numerator);

	gsl_vector_free(diff);
	gsl_vector_free(temp);
	return sqrt(numerator / denominator);
}

//the likelihood function.
//theta and p are the parameters needed to be search by maximize the function.
/*
 double likelihood(gsl_matrix* cmLU, gsl_permutation* perm, double determinent, gsl_vector* ys,
 double* theta, double* p, int number){
 double sum1 = 0;
 bool outofrange = false;
 int i;

 //test the range setting for the theta and p.
 for (i=0;i<dimension;i++){
 if(theta[i]<0.0){
 sum1=sum1+theta[i];
 break;}
 if (p[i]>2.0||p[i]<1.0){
 outofrange = true;
 break;
 }
 }
 if (sum1<0||outofrange==true)
 return 0;


 //compute the sigma and mu.
 double sigma, mu;
 //gsl_vector_view ys = gsl_vector_view_array(values, number);
 mu = mu_hat(cmLU, perm, ys, number);
 sigma = sigma_squared_hat(cmLU, perm,ys, mu, number);

 gsl_vector* diff=gsl_vector_alloc(number);
 gsl_vector* comptemp = gsl_vector_alloc(number);

 for (i=0;i<number; i++){
 gsl_vector_set(diff, i, gsl_vector_get(ys, i)-mu);
 }

 double lik, coefficient, exponent;
 coefficient = 1/(pow(2*PI*pow(sigma,2), number/2.0)*sqrt(determinent));

 gsl_linalg_LU_solve(cmLU, perm, diff, comptemp);
 gsl_blas_ddot(diff, comptemp, &exponent);
 exponent = exponent/(2*pow(sigma,2));
 lik = coefficient*exp(-1*exponent);

 gsl_vector_free(diff);
 gsl_vector_free(comptemp);

 return lik;
 }
 */

//a simplified likelihood function is used here.
//as suggested by EMMERICH's TEC paper.
//to minimize it!!!
double likelihood(gsl_matrix* datas, gsl_vector* values, double* theta,
		double* p, int number, int dimension) {
	double sum1 = 0;
	bool outofrange = false;
	int i;

	//test the range setting for the theta and p.
	for (i = 0; i < dimension; i++) {
		if (theta[i] < THETA_MIN) {
			outofrange = true;
			break;
		}
		if (p[i] > P_MAX || p[i] < P_MIN) {
			outofrange = true;
			break;
		}
	}
	if (sum1 < 0 || outofrange == true)
		return 100000;

	gsl_matrix* corMatrix = gsl_matrix_alloc(number, number);
	construct_cormatrix(datas, number, dimension, theta, p, corMatrix);
	gsl_permutation* perm = gsl_permutation_alloc(number);
	double lndet;
	decomposite_cormatrix(corMatrix, perm, &lndet);
	//gsl_vector_view ys = gsl_vector_view_array(values, number);

	double muhat = mu_hat(corMatrix, perm, values, number);
	double sigmahat = sigma_squared_hat(corMatrix, perm, values, muhat, number);
	sigmahat = sigmahat * sigmahat;

	//double lik = number * log(sigmahat) + log(det);
	double lik = number * log(sigmahat) + lndet;
#ifdef LOG
	if (isinf(lik))
	printf("Inf likelihood, sigmahat: %f, lndet: %f\n", sigmahat, lndet);
	//	for (int i=0;i<number;i++){
	//		for (int j=0;j<dimension;j++)
	//			printf("%f, ", gsl_matrix_get(corMatrix, i, j));
	//		printf("\n");
	//	}
#endif

	gsl_matrix_free(corMatrix);
	gsl_permutation_free(perm);

	/*
	 #ifdef LOG
	 printf("linkelihood found: %f\n", lik);
	 #endif
	 */

	return lik;
}

//to be minimized by the gsl_multimin function.
double likelihook_function(const gsl_vector* x, void* param) {
	//prepare the parameters.
	//double likelihood(double** datas, double* values, double* theta, double* p, int number, int dimension)
	void** params = (void**) param;
	gsl_matrix* datas = (gsl_matrix*) params[0];
	gsl_vector* values = (gsl_vector*) params[1];
	int* number = (int*) params[2];
	int* dimension = (int*) params[3];

	double* theta = x->block->data;
	double* p = x->block->data + (*dimension);

	double lik = likelihood(datas, values, theta, p, *number, *dimension);

	if (isnan(lik)) {
		return 123456;
	} else
		return lik;
}

//compute the multimin of likelihood_function using simplex.
//to remember the start point is the size of 2*dimension.
bool multimin_route(gsl_matrix* datas, gsl_vector* values, int dimension,
		int number, double* startpoint, double* xmin, double* fmin) {

	//set off the error handler for simplex. and to check itself.
	gsl_error_handler_t* ehandler = gsl_set_error_handler_off();

	int i;
	int np = dimension * 2;

	int iter = 0;
	int status;
	double size;

	const gsl_multimin_fminimizer_type *T = gsl_multimin_fminimizer_nmsimplex;
	gsl_multimin_fminimizer *s = NULL;
	gsl_vector *ss, *x;
	gsl_multimin_function minex_func;

	//initialize the step size;
	ss = gsl_vector_alloc(np);
	for (i = 0; i < dimension; i++) {
		gsl_vector_set(ss, i, THETA_SEARCH_STEP);
		gsl_vector_set(ss, i + dimension, P_SEARCH_STEP);
	}

	//initialize the start pooint;
	x = gsl_vector_alloc(np);
	for (i = 0; i < np; i++) {
		gsl_vector_set(x, i, startpoint[i]);
	}

#ifdef LOG
	printf("startpoint:\t");
	for (i=0;i<np;i++)
	printf("%f \t", gsl_vector_get(x,i));
	printf("\n");
#endif

	minex_func.f = &likelihook_function;
	minex_func.n = np;

	void* par[4];
	par[0] = datas;
	par[1] = values;
	par[2] = &number;
	par[3] = &dimension;
	minex_func.params = (void*) par;

	s = gsl_multimin_fminimizer_alloc(T, np);
	gsl_multimin_fminimizer_set(s, &minex_func, x, ss);

	do {
		iter++;
		status = gsl_multimin_fminimizer_iterate(s);

		/*
		 if (status) //success.
		 break;
		 else if(status!=GSL_SUCCESS){
		 printf("error happen in simplex iteraton. \n");
		 printf("error: %s\n", gsl_strerror(status));
		 }
		 */
		if (status == GSL_EFAILED) {
			//set a random pint and restart.
			break;
		}

		size = gsl_multimin_fminimizer_size(s);
		status = gsl_multimin_test_size(size, SIMPLEX_CONVERGE_TOLLERANCE);
		if (status == GSL_SUCCESS)
			break;

	} while (status == GSL_CONTINUE && iter < SIMPLEX_SEARCH_ITERATION);

	//log the information.
#ifdef LOG
	if (status==GSL_SUCCESS) { //success to converge.
		printf("converge at iteration %i at point:", iter);
		for (i=0;i<np;i++)
		printf("%f,", gsl_vector_get(s->x,i));
		printf(" with function value %f.\n",s->fval);
	} else if (status==GSL_CONTINUE) {//need to search.
		printf("quit the sarch by reaching the iteraton.");
		for (i=0;i<np;i++)
		printf("%f,", gsl_vector_get(s->x,i));
		printf(" with function value %f.\n",s->fval);
	} else {
		printf("error: %s\n", gsl_strerror(status));
	};
#endif

	//copy the result.
	for (i = 0; i < np; i++) {
		xmin[i] = gsl_vector_get(s->x, i);
	}
	(*fmin) = s->fval;

	gsl_vector_free(x);
	gsl_vector_free(ss);
	gsl_multimin_fminimizer_free(s);

	gsl_set_error_handler(ehandler);

	if (status == GSL_SUCCESS) {
		return true;//indicate converged.
	} else {
		return false;
	}
}

//compute the parameters based on the current datas and values.
//it also construct the col-relation matrix and it inverse.
/*
 void compute_parameters2(double** datas, double* values, int size, int dimension, double* theta, double* p){

 double* minx = (double*)malloc(dimension*2*sizeof(double));
 double* min = (double*)malloc(dimension*2*sizeof(double));

 double fval, fminval = 1000;
 int i;

 //first point.//initial value for theta and p. /how to set it?
 //shouldn't i set and try different vaules here?
 //this seems very critical. what's the range of the value here?
 //
 for (i=0;i<10;i++){
 //random restart in the domain [0-100], [1,2];
 for (i=0;i<dimension;i++){
 minx[i]=5;
 minx[i+dimension]=1.5;
 }
 //first iteration.
 multimin_route(datas, values, dimension, size, minx, minx, &fval);

 //update the minvalue.
 if (fval<fminval){
 fminval = fval;
 memcpy(min, minx, dimension*2*sizeof(double));
 }
 }

 for (i=0; i<dimension; i++){
 theta[i]=min[i];
 p[i]=min[i+dimension];
 }

 free(minx);
 free(min);
 }
 */

/*
 void estimate2(double** datas, double* values, int size, int dimension, double* theta, double* p, double* vairable, double * result, double* serror, gsl_matrix* cmLU, gsl_permutation* perm, double Rdert, double mu, double sigma){
 int i;

 //set up y and compute (y-u)
 gsl_vector_view yview = gsl_vector_view_array(values, size);
 gsl_vector* y = &yview.vector;

 gsl_vector* tempy = gsl_vector_alloc(size);
 gsl_vector* tempy2 = gsl_vector_alloc(size);
 for (i=0; i<size; i++){
 double d = gsl_vector_get(y, i);
 gsl_vector_set(tempy, i, (d-mu));
 }

 //compute invR(y-u)
 gsl_linalg_LU_solve(cmLU, perm, tempy, tempy2);

 //compute r'*invR(y-u)
 gsl_vector* r = corvector(datas, vairable, size, theta, p, dimension);
 gsl_blas_ddot(r, tempy2, result);

 *result = (*result) + (mu);

 double part, part1, part2;

 gsl_vector* one = gsl_vector_alloc(size);
 gsl_vector_set_all(one, 1);

 //gsl_blas_dgemv(CblasNoTrans, 1, invR, r, 0, tempy);//tempy = invR*r;
 gsl_linalg_LU_solve(cmLU, perm, r, tempy);
 gsl_blas_ddot(r, tempy, &part1);

 double dominator,nominator;
 gsl_blas_ddot(one, tempy, &nominator);//nominator = 1*invR*r;
 nominator = pow((1-nominator),2);

 //gsl_blas_dgemv(CblasNoTrans, 1, invR, one, 0, tempy);//tempy = invR*1;
 gsl_linalg_LU_solve(cmLU, perm, one, tempy);
 gsl_blas_ddot(one, tempy, &dominator);//dominator = 1*invR*1;

 part2 = nominator/dominator;

 part = (1-part1+part2);
 if (part<0)part=0;

 (*serror) =sqrt(part)*sigma;

 gsl_vector_free(r);
 gsl_vector_free(tempy);
 gsl_vector_free(tempy2);
 gsl_vector_free(one);
 }
 */

void compute_parameters2(gsl_matrix* datas, gsl_vector* values, int size,
		int dimension, double* theta, double* p) {

	double* minx = (double*) malloc(dimension * 2 * sizeof(double));
	double* min = (double*) malloc(dimension * 2 * sizeof(double));

	double fval, fminval = 1000;
	int i, j;

	//set up the random generator.
	const gsl_rng_type * RandomType;
	time_t seconds;
	seconds = time(NULL);

	gsl_rng * randomGen;
	gsl_rng_env_setup();
	RandomType = gsl_rng_default;
	randomGen = gsl_rng_alloc(RandomType);
	gsl_rng_set(randomGen, (long) seconds);

	//trying to use the last result as the start searching point for simplex.
	for (j = 0; j < dimension; j++) {
		//random.
		double th, ph;
		th = gsl_rng_uniform(randomGen) * (THETA_MAX - THETA_MIN) + THETA_MIN;
		ph = gsl_rng_uniform(randomGen) * (P_MAX - P_MIN) + P_MIN;

		//try to use the old theta from last trainings iterations.
		if (theta[j] != -1)
			th = theta[j];
		if (p[j] != -1)
			ph = p[j];

		minx[j] = th;
		minx[j + dimension] = ph;
	}

	//first point.//initial value for theta and p. /how to set it?
	//shouldn't i set and try different vaules here?
	//this seems very critical. what's the range of the value here?
	//

	//if not converted, saerch at most 10;
	//if converged. then saerch at most 3;
	bool converged;
	for (i = 0; i < 20; i++) {
#ifdef LOG
		printf("Search Iteration of training: %i \t", i);
#endif
		//random restart in the domain [0-100], [1,2];
		//first iteration.
		bool converg = multimin_route(datas, values, dimension, size, minx,
				minx, &fval);

		if (converg) {
			converged = true;
			if (i > 0)
				i = 100; //break from the loop.
		}

		bool better;
		//update the minvalue.
		if (fval < fminval) {
			better = true;
			fminval = fval;
			//memcpy(min, minx, dimension*2*sizeof(double));
			for (int index = 0; index < 2 * dimension; index++) {
				min[index] = minx[index];
			}
		}
		//set the staring pint for the next searching.
		//if (!converg && better && converged) {
		//need to continue the search from the current place.
		//} else {
		for (j = 0; j < dimension; j++) {
			//random.
			minx[j] = gsl_rng_uniform(randomGen) * (THETA_MAX - THETA_MIN)
					+ THETA_MIN;
			minx[j + dimension] = gsl_rng_uniform(randomGen) * (P_MAX - P_MIN)
					+ P_MIN;
		}
		//}
	}

	gsl_rng_free(randomGen);

	for (i = 0; i < dimension; i++) {
		theta[i] = min[i];
		p[i] = min[i + dimension];
	}

#ifdef LOG
	printf("Search Result: min value: %f \ttheta:", fminval);
	for (i=0;i<dimension;i++) {
		printf("%f, ", theta[i]);
	}
	printf("\tp: ");
	for (i=0;i<dimension;i++) {
		printf("%f, ", p[i]);
	}
	printf("\n\n");
#endif

	free(minx);
	free(min);
}

void compute_parameters_de(gsl_matrix* datas, gsl_vector* values, int size,
		int dimension, double* theta, double* p) {

	double* min = new double[2 * dimension];
	double* max = new double[2 * dimension];
	double* initx = new double[2 * dimension];

	//set up the random generator.
	const gsl_rng_type * RandomType;
	time_t seconds;
	seconds = time(NULL);

	gsl_rng * randomGen;
	gsl_rng_env_setup();
	RandomType = gsl_rng_default;
	randomGen = gsl_rng_alloc(RandomType);
	gsl_rng_set(randomGen, (long) seconds);

	for (int i = 0; i < dimension; i++) {
		min[i] = THETA_MIN;
		max[i] = THETA_MAX;
		min[i + dimension] = P_MIN;
		max[i + dimension] = P_MAX;
		initx[i] = gsl_rng_uniform(randomGen) * (THETA_MAX - THETA_MIN)
				+ THETA_MIN;;
		initx[i + dimension] = gsl_rng_uniform(randomGen) * (P_MAX - P_MIN)
				+ P_MIN;;

		if (theta[i] != -1)
			initx[i] = theta[i];
		if (p[i] != -1)
			initx[i + dimension] = p[i];
	}

	gsl_rng_free(randomGen);

	GPLikelihoodSolver solver(2 * dimension, DE_POPULATION, initx, 1);
	solver.Setup(min, max, stRand1Bin, 0.5, 0.10);
	solver.SetParameters(datas, values, size, dimension);
	solver.Solve(DE_ITERATION);

	double* solution = solver.Solution();
	//copy back the solution to theta and p;
	for (int i = 0; i < dimension; i++) {
		theta[i] = solution[i];
		p[i] = solution[i + dimension];
	}

#ifdef DEBUG_BUILD
	double fminval = solver.Energy();
	printf("Model Search Result: min value: %f \t theta:", fminval);
	for (int i=0;i<dimension;i++) {
		printf("%f, ", theta[i]);
	}
	printf("\tp: ");
	for (int i=0;i<dimension;i++) {
		printf("%f, ", p[i]);
	}
	printf("\n\n");
#endif

	delete min;
	delete max;
	delete initx;
}

void estimate2(gsl_matrix* datas, gsl_vector* y, int size, int dimension,
		double* theta, double* p, double* variable, double * result,
		double* serror, gsl_matrix* cmLU, gsl_permutation* perm, double Rdert,
		double mu, double sigma) {
	int i;

	//set up y and compute (y-u)
	gsl_vector_view varview = gsl_vector_view_array(variable, dimension);

	gsl_vector* tempy = gsl_vector_alloc(size);
	gsl_vector* tempy2 = gsl_vector_alloc(size);
	for (i = 0; i < size; i++) {
		double d = gsl_vector_get(y, i);
		gsl_vector_set(tempy, i, (d - mu));
	}

	//compute invR(y-u)
	gsl_linalg_LU_solve(cmLU, perm, tempy, tempy2);

	//compute r'*invR(y-u)
	gsl_vector* r = gsl_vector_alloc(size);
	corvector(datas, &varview.vector, size, theta, p, dimension, r);
	gsl_blas_ddot(r, tempy2, result);

	*result = (*result) + (mu);

	double part, part1, part2;

	gsl_vector* one = gsl_vector_alloc(size);
	gsl_vector_set_all(one, 1);

	//gsl_blas_dgemv(CblasNoTrans, 1, invR, r, 0, tempy);//tempy = invR*r;
	gsl_linalg_LU_solve(cmLU, perm, r, tempy);
	gsl_blas_ddot(r, tempy, &part1);

	double dominator, nominator;
	gsl_blas_ddot(one, tempy, &nominator);//nominator = 1*invR*r;
	nominator = pow((1 - nominator), 2);

	//gsl_blas_dgemv(CblasNoTrans, 1, invR, one, 0, tempy);//tempy = invR*1;
	gsl_linalg_LU_solve(cmLU, perm, one, tempy);
	gsl_blas_ddot(one, tempy, &dominator);//dominator = 1*invR*1;

	part2 = nominator / dominator;

	part = (1 - part1 + part2);
	if (part < 0)
		part = 0;

	(*serror) = sqrt(part) * sigma;

	gsl_vector_free(r);
	gsl_vector_free(tempy);
	gsl_vector_free(tempy2);
	gsl_vector_free(one);
}

