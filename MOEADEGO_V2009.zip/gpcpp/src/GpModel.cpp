#ifndef CLASS_GPMODEL_IMP
#define CLASS_GPMODEL_IMP

#include "GpModel.h"
#include "ego.h"

GpModel::GpModel() {
}

GpModel::GpModel(int d) {
	init(d);
	this->corMatrixLU=NULL;
	this->datas=NULL;
	this->values=NULL;
	this->perm=NULL;
}

GpModel::~GpModel() {
	free(p);
	free(theta);

	if (this->corMatrixLU!=NULL)
		gsl_matrix_free(corMatrixLU);
	if (this->datas!=NULL)
		gsl_matrix_free(datas);
	if (this->values!=NULL)
		gsl_vector_free(values);
	if (this->perm!=NULL)
		gsl_permutation_free(perm);
}

void GpModel::init(int d) {
	dimension = d;

	theta = (double*) malloc(dimension * sizeof(double));
	p = (double*) malloc(dimension * sizeof(double));
	int i;
	for (i = 0; i < dimension; i++) {
		theta[i] = -1;//-1 indicate never be trained before.
		p[i] = -1;
	}
}

void GpModel::reinit(int n) {
	number = n;

	if (corMatrixLU!=NULL)
		gsl_matrix_free(corMatrixLU);
	if (datas!=NULL)
		gsl_matrix_free(datas);
	if (values!=NULL)
		gsl_vector_free(values);
	if (perm!=NULL)
		gsl_permutation_free(perm);

	corMatrixLU = gsl_matrix_alloc(number, number);
	datas = gsl_matrix_alloc(number, dimension);
	values = gsl_vector_alloc(number);
	perm = gsl_permutation_alloc(number);
}

void GpModel::train(double** ds, double* vs, int n) {
	//copy the datas into the matrix.
	reinit(n);
	int i, j;
	for (i = 0; i < number; i++) {
		for (j = 0; j < dimension; j++) {
			gsl_matrix_set(datas, i, j, ds[i][j]);
		}
		gsl_vector_set(values, i, vs[i]);
	}

#ifdef SIMPLEX
	compute_parameters2(datas, values, number, dimension, theta, p);
#else
	compute_parameters_de(datas, values, number, dimension, theta, p);
#endif

	//save the model information.
	construct_cormatrix(datas, number, dimension, theta, p, corMatrixLU);
	decomposite_cormatrix(corMatrixLU, perm, &det);

	mu_h = mu_hat(corMatrixLU, perm, values, number);
	sigma_sqrt_h = sigma_squared_hat(corMatrixLU, perm, values, mu_h, number);
	this->trained = true;
}

void GpModel::train(gsl_matrix *ds, gsl_vector *vs, int n) {
	reinit(n);
	int i, j;
	for (i = 0; i < number; i++) {
		for (j = 0; j < dimension; j++) {
			gsl_matrix_set(this->datas, i, j, gsl_matrix_get(ds, i, j));
		}
		gsl_vector_set(this->values, i, gsl_vector_get(vs, i));
	}

	//build the model
#ifdef SIMPLEX
	compute_parameters2(datas, values, number, dimension, theta, p);
#else
	compute_parameters_de(datas, values, number, dimension, theta, p);
#endif

	//save the model information.
	construct_cormatrix(datas, number, dimension, theta, p, corMatrixLU);
	decomposite_cormatrix(corMatrixLU, perm, &det);

	mu_h = mu_hat(corMatrixLU, perm, values, number);
	sigma_sqrt_h = sigma_squared_hat(corMatrixLU, perm, values, mu_h, number);
	this->trained = true;
}

void GpModel::estimate(double* var, double* result) {
	estimate2(datas, values, number, dimension, theta, p, var, result, result
			+ 1, corMatrixLU, perm, det, mu_h, sigma_sqrt_h);

}

int GpModel::getDimension() {
	return dimension;
}

int GpModel::getSize() {
	return number;
}

#endif
