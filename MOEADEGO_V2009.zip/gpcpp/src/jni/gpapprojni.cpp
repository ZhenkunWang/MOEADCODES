#include "gpapprojni.h"
#include "GpModel.h"
#include <cstdlib>
#include "DPGpModel.h"

/*
 * Class:     uk_ac_essex_csp_algorithms_appro_gp_GpApproximatorJNI
 * Method:    nativeInitialize
 * Signature: (II)J
 */
JNIEXPORT jlong JNICALL Java_uk_ac_essex_csp_algorithms_appro_gp_GpApproximatorJNI_nativeInitialize(
		JNIEnv *env, jobject objthis, jint dim, jint number) {
	GpModel* model = new GpModel((int) dim);

	jlong result = reinterpret_cast<jlong> (model);
	return result;
}

/*
 * Class:     uk_ac_essex_csp_algorithms_appro_gp_GpApproximatorJNI
 * Method:    nativeFinalize
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_uk_ac_essex_csp_algorithms_appro_gp_GpApproximatorJNI_nativeFinalize(
		JNIEnv *env, jobject objthis, jlong pointer) {
	GpModel* result = reinterpret_cast<GpModel*> (pointer);

	if (result != NULL)
		delete result;
}

/*
 * Class:     uk_ac_essex_csp_algorithms_appro_gp_GpApproximatorJNI
 * Method:    nativeTrain
 * Signature: ([[D[DJ)V
 */
JNIEXPORT void JNICALL Java_uk_ac_essex_csp_algorithms_appro_gp_GpApproximatorJNI_nativeTrain(
		JNIEnv *env, jobject objthis, jobjectArray datas, jdoubleArray values,
		jlong pointer) {
	GpModel* model = reinterpret_cast<GpModel*> (pointer);

	//translate the data in.
	int i, size, dimension;
	size = env->GetArrayLength(values);
	dimension = model->getDimension();

	//init(dimension);
	//convert the datas.
	double** nativedatas;
	double* nativevalues;
	nativedatas = (double**) malloc(size * sizeof(double*));
	nativevalues = (double*) malloc(size * sizeof(double));

	env->GetDoubleArrayRegion(values, 0, size, nativevalues);

	for (i = 0; i < size; i++) {
		jdoubleArray dba = (jdoubleArray) env->GetObjectArrayElement(datas, i);
		double* d = (double*) malloc(dimension * sizeof(double));
		env->GetDoubleArrayRegion(dba, 0, dimension, d);
		nativedatas[i] = d;
	}

	model->train(nativedatas, nativevalues, size);

	free(nativevalues);
	for (i = 0; i < size; i++)
		free(nativedatas[i]);
	free(nativedatas);
}

/*
 * Class:     uk_ac_essex_csp_algorithms_appro_gp_GpApproximatorJNI
 * Method:    nativeEstimate
 * Signature: ([D[DJ)V
 */
JNIEXPORT void JNICALL Java_uk_ac_essex_csp_algorithms_appro_gp_GpApproximatorJNI_nativeEstimate(
		JNIEnv *env, jobject objthis, jdoubleArray variable,
		jdoubleArray result, jlong pointer) {
	GpModel* model = reinterpret_cast<GpModel*> (pointer);

	int dimension;
	double nativeresult[2];
	dimension = model->getDimension();

	double* nativevariable;
	nativevariable = (double*) malloc(dimension * sizeof(double));

	env->GetDoubleArrayRegion(variable, 0, dimension, nativevariable);

	model->estimate(nativevariable, nativeresult);

	//copy back the data in result.
	env->SetDoubleArrayRegion(result, 0, 2, nativeresult);

	free(nativevariable);
}

