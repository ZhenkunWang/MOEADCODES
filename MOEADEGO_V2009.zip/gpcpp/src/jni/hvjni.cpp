/*
 * hvjni.cpp
 *
 *  Created on: 09-Jul-2008
 *      Author: wliui
 */


#include "hvjni.h"
#include "hv.h"
#include <cstdlib>

JNIEXPORT jdouble JNICALL Java_uk_ac_essex_csp_algorithms_mo_indicator_HyperVolumnJNI_nativeHyperVolumn
  (JNIEnv *env, jclass objthis, jobjectArray datas, jdoubleArray ref){

	int d = env->GetArrayLength(ref);
	int n = env->GetArrayLength(datas);
	double* nativedata= (double*)malloc(d*n*sizeof(double));
	double* nativeref=(double*)malloc(n*sizeof(double));

	env->GetDoubleArrayRegion(ref, 0, d, nativeref);

	double * head = nativedata;
	for (int i=0;i<n;i++){
		jdoubleArray dba = (jdoubleArray)env->GetObjectArrayElement(datas, i);
		env->GetDoubleArrayRegion(dba, 0, d, head);
		head+=d;
	}

	double v= hv(nativedata, d, n, nativeref);
	free(nativedata);
	free(nativeref);
	return v;
}

