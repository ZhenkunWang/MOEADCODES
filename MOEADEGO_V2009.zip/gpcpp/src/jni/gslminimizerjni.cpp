/*
 * gslminimizerjni.cpp
 *
 *  Created on: 19-Nov-2008
 *      Author: wliui
 */
#include "gslminimisationjni.h"
#include "CFunction.h"
#include "Optimizer.h"
#include <cmath>
#include <iostream>

class JavaMinFunction: public CFunction {

public:
	JavaMinFunction(jobject f, jint n, JNIEnv* env, jdoubleArray temparray) {
		this->fun = f;
		this->nvar = n;
		this->env = env;
		jclass cls = env->GetObjectClass(f);
		this->mid = env->GetMethodID(cls, "function", "([D)D");
		this->tempArray = temparray;
	}
	;

	double func(const gsl_vector& x) {
		//create a double array.
		// std::cout << "step 2.0" << std::endl;
		jdouble* darray = env->GetDoubleArrayElements(tempArray, NULL);

		for (unsigned int i = 0; i < x.size; i++) {
			darray[i] = gsl_vector_get(&x, i);
		}

		env->ReleaseDoubleArrayElements(tempArray, darray, NULL);
		//invoke the MinimisationFunction in java.

		jdouble result;
		if (mid != 0) {
			result = env->CallDoubleMethod(fun, mid, tempArray);
		};

		return result;
	}
	;

	int getNvar() {
		return nvar;
	}
	;

private:
	jobject fun;
	jint nvar;
	jmethodID mid;
	JNIEnv* env;
	jdoubleArray tempArray;
};


JNIEXPORT jdouble JNICALL Java_uk_ac_essex_csp_algorithms_optimization_GSLMinimisation_optmize(
		JNIEnv *env, jobject thisobj, jobject func, jint nvar,
		jdoubleArray startpoint, jint iteration, jdoubleArray optpoint,
		jdoubleArray temparray) {

	JavaMinFunction minf(func, nvar, env, temparray);

	jdouble* startnative = env->GetDoubleArrayElements(startpoint, NULL);
	gsl_vector_view sv = gsl_vector_view_array(startnative, nvar);
	jdouble* optnative = env->GetDoubleArrayElements(optpoint, NULL);
	gsl_vector_view optview = gsl_vector_view_array(optnative, nvar);

	double optvalue;
	Optimizer opter;
	opter.optmize(minf, sv.vector, optview.vector, optvalue);

	//std::cout << optnative[0] <<", " <<optnative[1] <<std::endl;
	//copyback the optpoint.
	env->ReleaseDoubleArrayElements(optpoint, optnative, NULL);
	env->ReleaseDoubleArrayElements(startpoint, startnative, NULL);
	return optvalue;
}
;

