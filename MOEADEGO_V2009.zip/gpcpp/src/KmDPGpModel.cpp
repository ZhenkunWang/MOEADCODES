/*
 * DPGpModel.cpp
 *
 *  Created on: 29-Jun-2008
 *      Author: wliui
 */

#ifndef CLASS_KMGPMODEL_IMP
#define CLASS_KMGPMODEL_IMP

#define DPGP_MODEL_LIMIT 60
#define DPGP_MODEL_CENTER_ADD_ITR 30
#define DPGP_CLUSTER_MAXITR 10000
#define DPGP_CLUSTER_MINFUNC 10e-6

#include <gsl/gsl_sort_vector.h>
#include <cmath>
#include <limits>
#include "GpModel.h"
#include "ego.h"
#include "KmDPGpModel.h"
#include "FCMeanCluster.h"

KmDPGpModel::KmDPGpModel(int parDimension) {
	//first need to determine how many number of GP Model is needed
	this->var_n = parDimension;
	this->centers = NULL;
	this->U = NULL;
	int s = this->gpmodels.size();
	for (int i = 0; i < s; i++) {
		GpModel* gp = this->gpmodels[i];
		delete gp;
	}
}

KmDPGpModel::~KmDPGpModel() {
	if (this->U != NULL) {
		delete[] this->U;
		this->U = NULL;
	}
	if (this->centers != NULL) {
		gsl_matrix_free(this->centers);
		this->centers = NULL;
	}
}

void KmDPGpModel::reinit(int number) {
	this->data_n = number;
	this->center_n = this->getModelNumber(number);

	if (number <= DPGP_MODEL_LIMIT)
		this->model_size = number;
	else
		this->model_size = DPGP_MODEL_LIMIT;

	if (this->U != NULL) {
		delete[] this->U;
		this->U = NULL;
	}
	if (this->centers != NULL) {
		gsl_matrix_free(this->centers);
		this->centers = NULL;
	}

	//init the center. and U.
	this->U = new int[this->data_n];
	this->centers = gsl_matrix_alloc(center_n, var_n);

	//update the models.
	int cur_model_n = this->gpmodels.size();
	if (cur_model_n < this->center_n) {
		for (int i = cur_model_n; i < this->center_n; i++) {
			GpModel* p = new GpModel(this->var_n);
			this->gpmodels.push_back(p);
		}
	}
}

void KmDPGpModel::train(double **datas, double *values, int number) {
	reinit(number);

	gsl_matrix* data = gsl_matrix_alloc(this->data_n, this->var_n);
	gsl_vector* value = gsl_vector_alloc(this->data_n);

	for (int i = 0; i < data_n; i++) {
		for (int j = 0; j < var_n; j++) {
			gsl_matrix_set(data, i, j, datas[i][j]);
		}
		gsl_vector_set(value, i, values[i]);
	}

	//build the centers.
	kcm(data, center_n, data_n, var_n, DPGP_CLUSTER_MAXITR,
	DPGP_CLUSTER_MINFUNC, this->centers, this->U);

	if (data_n <= DPGP_MODEL_LIMIT) {
		this->gpmodels[0]->train(datas, values, data_n);
	} else {
		for (int i = 0; i < center_n; i++) {
			int count = 0;
			for (int j = 0; j < data_n; j++) {
				if (this->U[j] == i)
					count++;
			}

			gsl_matrix* traindata = gsl_matrix_alloc(count, var_n);
			gsl_vector* trainvalue = gsl_vector_alloc(count);
			//gather the datas.

			int k = 0; //the index for traindata.
			for (int j = 0; j < data_n; j++) {
				if (this->U[j] == i) {
					for (int v = 0; v < var_n; v++) {
						gsl_matrix_set(traindata, k, v, gsl_matrix_get(data, j,
								v));
					}
					gsl_vector_set(trainvalue, k, gsl_vector_get(value, j));
					k++;
				}
			}

			//train the model.
			this->gpmodels[i]->train(traindata, trainvalue, count);
			gsl_matrix_free(traindata);
			gsl_vector_free(trainvalue);
		}
	}

	gsl_matrix_free(data);
	gsl_vector_free(value);
}

void KmDPGpModel::estimate(double *var, double *result) {
	//find the closest center. and estimate the value with that model.
	if (this->center_n == 1) {
		this->gpmodels[0]->estimate(var, result);
	} else {
		int modelindex = -1;
		double mindist = std::numeric_limits<double>::max();

		for (int i = 0; i < this->center_n; i++) {
			//compute the distance
			double distance = 0;
			for (int j = 0; j < this->var_n; j++) {
				double d = gsl_matrix_get(this->centers, i, j) - var[j];
				distance += d * d;
			}
			//distance = sqrt(distance);

			if (distance < mindist) {
				mindist = distance;
				modelindex = i;
			}
		}
		this->gpmodels[modelindex]->estimate(var, result);
	}
}

int KmDPGpModel::getDimension() {
	return this->var_n;
}

int KmDPGpModel::getSize() {
	return this->data_n;
}

int KmDPGpModel::getModelNumber(int numberofDate) {
	if (numberofDate <= DPGP_MODEL_LIMIT)
		return 1;
	else {
		int moredata = numberofDate - DPGP_MODEL_LIMIT;
		int additional = (moredata / DPGP_MODEL_CENTER_ADD_ITR) + 1;
		return additional + 1;
	};
}

#endif
