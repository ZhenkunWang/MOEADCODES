/*
 * FCMeanCluster.cpp
 *
 *  Created on: 28-Jun-2008
 *      Author: wliui
 */

#include "FCMeanCluster.h"
# include <gsl/gsl_blas.h>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <limits>

const double dMax = std::numeric_limits<double>::max();

void fcm(gsl_matrix* data, int cluster_n, int data_n, int var_n, int exponent,
		int maxitr, double minfimp, gsl_matrix* center, gsl_matrix* U) {

	initfcm(cluster_n, data_n, U);
	double oldfunc = 0;
	for (int i = 0; i < maxitr; i++) {
		double func = stepfcm(data, center, U, data_n, cluster_n, var_n,
				exponent);

		//determine if it converge.
		if (i > 0 && fabs(func - oldfunc) < minfimp)
			break;

		oldfunc = func;
	}
}
;

void initfcm(int cluster_n, int data_n, gsl_matrix* U) {
	//U matrix with cluster_n row and ata_n column.
	srand(time(0));
	for (int i = 0; i < cluster_n; i++) {
		for (int j = 0; j < data_n; j++) {
			double rnumber = (double) rand();
			gsl_matrix_set(U, i, j, rnumber);
		}
	}

	for (int j = 0; j < data_n; j++) {
		double sum = 0;
		for (int i = 0; i < cluster_n; i++)
			sum += gsl_matrix_get(U, i, j);

		for (int i = 0; i < cluster_n; i++)
			gsl_matrix_set(U, i, j, gsl_matrix_get(U, i, j) / sum);
	}
}
;

double stepfcm(gsl_matrix* data, gsl_matrix* center, gsl_matrix* U, int data_n,
		int cluster_n, int var_n, int expo) {
	//mf = U.^2. -> U.
	for (int i = 0; i < cluster_n; i++) {
		for (int j = 0; j < data_n; j++)
			gsl_matrix_set(U, i, j, gsl_matrix_get(U, i, j) * gsl_matrix_get(U,
					i, j));
	}

	//mf*data -> center.
	gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, 1.0, U, data, 0.0, center);

	//gsl_vector* center_tmp = gsl_vector_alloc(cluster_n);

	for (int i = 0; i < cluster_n; i++) {
		double sum = 0;
		for (int j = 0; j < data_n; j++)
			sum += gsl_matrix_get(U, i, j);

		//gsl_vector_set(center_tmp, i, sum);
		for (int j = 0; j < var_n; j++)
			gsl_matrix_set(center, i, j, gsl_matrix_get(center, i, j) / sum);
	}

	gsl_matrix* dist = gsl_matrix_alloc(cluster_n, data_n);
	//gsl_matrix* dist_tmp = gsl_matrix_alloc(center_n, data_n);
	distfcm(center, data, dist, cluster_n, data_n, var_n);

	//sum up dist.^2.*mf.
	//dist->dist.^(-2/(expo-1))
	double resultsum = 0;
	for (int i = 0; i < cluster_n; i++) {
		for (int j = 0; j < data_n; j++) {
			double ind = gsl_matrix_get(dist, i, j)
					* gsl_matrix_get(dist, i, j) * gsl_matrix_get(U, i, j);
			gsl_matrix_set(dist, i, j, pow(gsl_matrix_get(dist, i, j), -2
					/ (expo - 1)));
			resultsum += ind;
		}
	}

	for (int j = 0; j < data_n; j++) {
		double sum = 0;
		for (int i = 0; i < cluster_n; i++) {
			sum += gsl_matrix_get(dist, i, j);
		}
		for (int i = 0; i < cluster_n; i++) {
			gsl_matrix_set(U, i, j, gsl_matrix_get(dist, i, j) / sum);
		}
	}

	gsl_matrix_free(dist);
	return resultsum;
}
;

void distfcm(gsl_matrix* center, gsl_matrix* data, gsl_matrix* out,
		int cluster_n, int data_n, int var_n) {
	for (int i = 0; i < cluster_n; i++) {
		for (int j = 0; j < data_n; j++) {
			double distance = 0;
			for (int k = 0; k < var_n; k++) {
				distance += pow((gsl_matrix_get(center, i, k) - gsl_matrix_get(
						data, j, k)), 2);
			}
			gsl_matrix_set(out, i, j, sqrt(distance));
		}
	}
}
;

void kcm(gsl_matrix* data, int cluster_n, int data_n, int var_n, int maxitr,
		double minfimp, gsl_matrix* center, int* labers) {

	int* counts = new int[cluster_n];
	double old_error, error = dMax;
	gsl_matrix* ctemp = gsl_matrix_alloc(cluster_n, var_n);

	//randomly pick k point from data as the center.
	for (int i = 0; i < cluster_n; i++) {
		int index = rand() % data_n;
		for (int j = 0; j < var_n; j++) {
			gsl_matrix_set(center, i, j, gsl_matrix_get(data, index, j));
		}
	}

	int itr = 0;
	do {
		old_error = error;
		error = 0;

		/*clear old counts and temp centroids */
		for (int i = 0; i < cluster_n; i++) {
			counts[i] = 0;
			for (int j = 0; j < var_n; j++)
				gsl_matrix_set(ctemp, i, j, 0);
		}

		//assign the labers
		//identify the cloest cluster and laber the data.
		for (int i = 0; i < data_n; i++) {
			double min_distance = dMax;
			for (int j = 0; j < cluster_n; j++) {
				double distance = 0;
				for (int k = 0; k < var_n; k++) {
					distance += pow((gsl_matrix_get(center, j, k)
							- gsl_matrix_get(data, i, k)), 2);
				}
				if (distance < min_distance) {
					labers[i] = j;
					min_distance = distance;
				}
			}

			for (int k = 0; k < var_n; k++) {
				double tv = gsl_matrix_get(ctemp, labers[i], k)
						+ gsl_matrix_get(data, i, k);
				gsl_matrix_set(ctemp, labers[i], k, tv);
			}
			counts[labers[i]]++;
			error += min_distance;
		}

		//update the centroids.
		for (int i = 0; i < cluster_n; i++) {
			for (int j = 0; j < var_n; j++) {
				//c[i][j] = counts[i] ? c1[i][j] / counts[i] : c1[i][j];
				double v = gsl_matrix_get(ctemp, i, j);
				if (counts[i] > 0)
					v = v / counts[i];

				gsl_matrix_set(center, i, j, v);
			}
		}

		itr++;
	} while (fabs(error - old_error) > minfimp && itr < maxitr);

	delete[] counts;
	gsl_matrix_free(ctemp);
}
;
