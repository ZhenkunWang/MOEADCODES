%% MOEA/D-PaS code for TEVC paper by 
% Wang et al. 2016 
% Title
% Decomposition Based Algorithms Using Pareto Adaptive Scalarizing method
% Abstract: 
% Decomposition based algorithms have become increasingly
% popular for evolutionary multi-objective optimization.
% However, the effect of scalarizing methods used in these algorithms
% is still far from being well understood. This paper
% analyzes a family of frequently used scalarizing methods��
% the Lp methods, and shows that the p value is crucial to
% balances the selective pressure towards the Pareto optimal and
% the algorithm robustness to PF geometries. It demonstrates that
% an Lp method exists which can maximize the search ability of a
% decomposition based algorithm, and guarantees that given some
% weight, any solution along the PF can be found. Moreover, a
% simple yet effective method called Pareto adaptive scalarizing
% approximation, denoted as PaS, is proposed to approximate the
% optimal p value. In order to demonstrate the effectiveness of PaS,
% we incorporate PaS into a state-of-the-art decomposition based
% algorithm, i.e., MOEA/D, and compare the resultant MOEA/DPaS
% with some other MOEA/D variants on a set of problems with
% different PF geometries and up to seven conflicting objectives.
% Experimental results demonstrate that the PaS is effective.

% Please contact Rui Wang (ruiwangnudt@gmail.com) for details.
%%
clear all; close all; clc
fprintf('Decomposition based algorithms using Pareto adaptive scalarizing methods: \n');
warning off all
%% Parameter settings
maxGen = 100;
testNo = 4; M = 2; N = 100;
T = min([10,N*0.1]); nr = min([T*0.2,2]);
%% generate search directions

% 1 MOEA/D Simplex lattic method
H = 99;
jointWD = combn(0:1:H,M);
jointWD = jointWD(logical(sum(jointWD,2)==H),:);  % filter rows whose sum is 1
jointWD = jointWD/H;
% 2 MSOPS method
%jointWD=vspace(100,M);
jointWnum = size(jointWD,1);
jointFnum = jointWnum;
%% neighbours between weights
WdegreeMatrix = neighboringWW(jointWD,T);
%% WFG problem configuration
nVar = 100; k = 6; l = nVar-k;
% bounds of decison variables
bounds=[zeros(1, nVar); 2*(1:nVar)];
% range the PF shape
F_bounds = 2*ones(1,M); % having the same range
% F_bounds = 2*(1:M);    % standard WFG range setting
%% plot setting
hf = figure;
set (gcf,'Position',[400,150,800,400])
for iRunindex = 1:2
    limitP = 11;
    switch iRunindex
        case 1
            %% Lp methods candidate p values
            pSet = limitP*ones(jointFnum,1);
            pOrder = zeros(jointFnum,1);
            candidateP = 1:10;
            candidatePnum = size(candidateP,2);
        case 2
            pSet = limitP*ones(jointFnum,1);
            %pSet(1:2:end) = 1;
            pOrder = zeros(jointFnum,1);
    end
    %% archive
    bestobjv = Inf*ones(1,M);
    Normbestobjv = Inf*ones(1,M);
    bestphen = NaN*ones(1,nVar);
    %% initialize solutions
    jointP = crtrp(jointFnum,bounds);
    jointF = wfgextend(jointP, M, k, l, testNo,F_bounds);
    z = zeros(1,M)-0.001;
    %% Loop
    for gen = 1:maxGen
        %% Prepare weight vectors
        tempjointP = jointP; tempjointF = jointF;
        MaxAllobjv = zeros(jointFnum,1);
        index1 = find(pSet<limitP);
        index2 = find(pSet==limitP);
        jointW(index1,:) = (1./(jointWD(index1,:)+0.0000001)).^(rep(pSet(index1,:)-pOrder(index1,:), [1,M]));
        jointW(index2,:) = 1./(jointWD(index2,:)+0.0000001);
        jointW = jointW./rep(sum(jointW,2),[1,M]);
        
        for iwindex = 1:jointWnum
            neighborWix = WdegreeMatrix(iwindex,:);
            ix = randperm(T);
            varix = neighborWix(ix(1:2));
            tempP = tempjointP(varix,:);
            %% generate new solutions
            tempP = sbx_sal(tempP, bounds, 15, 0, 1, 1,0.5);
            tempP = polymut_sal(tempP, bounds, 20, 1/nVar);
            newP = tempP(1,:);
            newF = wfgextend(newP, M, k, l, testNo,F_bounds);
            normAllJointF = [newF;jointF];
            %normAllJointF = normliseData([newF;jointF],[newF;jointF]);
            NormNewF = normAllJointF(1,:);
            NormJointF = normAllJointF(2:end,:);
            %% evaluation
            for ie = 1:1
                if (~isempty(index1))
                    MaxAllobjv(index1,:) =  sum(jointW(index1,:).* (abs(NormJointF(index1,:)-rep(z,[size(index1,1),1])).^rep(pSet(index1,:),[1,M])), 2); % Lp method
                end
                if (~isempty(index2))
                    MaxAllobjv(index2,:) = max(jointW(index2,:).*(abs(NormJointF(index2,:)-rep(z,[size(index2,1),1]))),[],2); %Chebyshef method
                end
            end
            %% update solutions
            updateNum = 1;
            counter = 1;
            ixGroup = [1,1+randperm(T-1)]; % To guarantee that comparision is made with its parent first
            while(updateNum <= nr+1)
                ix = ixGroup(counter); %ix = unidrnd(T);
                jointWindex = neighborWix(ix);
                if  pSet(jointWindex)==limitP
                    MaxNewobjv = max( abs(NormNewF - z) .*jointW(jointWindex,:)); % Chebyshef method
                else
                    MaxNewobjv = sum(jointW(jointWindex,:).* (abs(NormNewF - z).^pSet(jointWindex)),2); % Lp method
                end
                if(MaxNewobjv <= MaxAllobjv(jointWindex))
                    jointP(jointWindex,:) = newP;
                    jointF(jointWindex,:) = newF;
                    NormJointF(jointWindex,:) = NormNewF;
                    MaxAllobjv(jointWindex) = MaxNewobjv;
                    updateNum = updateNum+1;
                end
                counter = counter + 1;
                if(counter > T)
                    break;
                end
            end
        end
        %% obtain non-dominated solutions
        Cobjvix = find_nd(jointF);
        Hobjv =  jointF(logical(Cobjvix),:);
        NormHobjv =  NormJointF(logical(Cobjvix),:);
        HP = jointP(logical(Cobjvix),:);
        for offlinei = 1:1
            [ix,bestix] = find_nd(Hobjv,bestobjv);
            bestobjv = [bestobjv(logical(bestix),:) ; Hobjv(logical(ix),:)];
            Normbestobjv = [Normbestobjv(logical(bestix),:) ; NormHobjv(logical(ix),:)];
            bestphen = [bestphen(logical(bestix),:) ; HP(logical(ix),:)];
            bestNum = size(bestobjv,1);
            if bestNum>N
                [bestobjv,index] = reducer(bestobjv, M, N);
                Normbestobjv = Normbestobjv(index,:);
                bestphen = bestphen(index,:);
            end
        end
        if iRunindex==1
           %% estimate the P value
            RefF = Normbestobjv;
            SdegreeMatrix = angleSW(RefF,jointWD);
            pSet(1) =  limitP;
            pSet(jointWnum) =  limitP;
            for iw = 2:jointWnum-1
                if rand>gen/maxGen
                    curWD = jointWD(iw,:);
                    curW = (1./(curWD+0.00001)); curW = curW./sum(curW,2);
                  %% configure neighbouring solutions
                    % Effectively, here for each weight vector, we use all individuals as its neighbours
                    curNeighborObjv = RefF;
                    curNeighborNum = size(RefF,1);
                    % However, users can define neighbours by their own methods
                    % curNeighborNum = size(RefF,1);
                    % curWDneighborix = trunc_No(1./SdegreeMatrix(:,iw),curNeighborNum);
                    % curNeighborObjv = RefF(curWDneighborix,:);
                    % curNeighborObjv = normliseData(curNeighborObjv,RefF);
                  %% find p value
                    pSet(iw) = limitP;
                    scalarmatrix = ones(curNeighborNum,candidatePnum);
                    tempCurW = curW;
                    for ix = 1:candidatePnum
                        p = candidateP(ix);
                        curW = tempCurW.^(p); curW = curW./sum(curW,2);
                        scalarValues = (sum(rep(curW,[curNeighborNum,1]).*(curNeighborObjv.^p),2)).^(1/p);
                        scalarmatrix(:,ix) = scalarValues;
                    end
                    [value,ixmin] = min(scalarmatrix,[],1);
                    objvMin = curNeighborObjv(ixmin,:);
                    objvMinWDdegree = angleSW(curWD,objvMin);
                    [objvMinWDdegreeMin,ixdegree] = min(objvMinWDdegree);
                    equallist = find(objvMinWDdegree==objvMinWDdegreeMin);
                    pSet(iw) = candidateP(equallist(1));
                end
            end
        end
         %% Plot the results
         subplot(1,2,iRunindex);
         plot(Hobjv(:,1), Hobjv(:,2), 'o'), axis square; title (num2str(gen))
         drawnow
    end
    result{iRunindex} = Hobjv;
    offlineresult{iRunindex} = bestobjv;
end
hf = figure;
set (gcf,'Position',[400,150,800,400])
subplot(121)
res1 = result{1}; res2 = result{2};
plot(res1(:,1), res1(:,2), 'o',res2(:,1), res2(:,2), '*');
subplot(122)
res1 = offlineresult{1}; res2 = offlineresult{2};
plot(res1(:,1), res1(:,2), 'o',res2(:,1), res2(:,2), '*');
