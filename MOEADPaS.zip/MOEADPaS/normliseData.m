% This function is to normlise [Data] using the range of [rangeData] within [0 1]
% Created by Rui on 2014 09 13
function result = normliseData(Data,rangeData)
curObjv = Data;
numObjv = size(curObjv,1);
maxrangeData = max(rangeData,[],1);
minrangeData = min(rangeData,[],1);
result = (curObjv-rep(minrangeData,[numObjv,1]))./rep(maxrangeData-minrangeData,[numObjv,1]);
end