function WdegreeMatrix = neighboringWW(jointW,numWneighbor)
distance = l2matrix(jointW);
[nouse,index] = sort(distance,2);
WdegreeMatrix = index(:,1:numWneighbor);
end