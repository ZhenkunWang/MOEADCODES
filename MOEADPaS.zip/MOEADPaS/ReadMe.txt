You should run Main_MOEAPaS.m to see the performance of MOEA/D-PaS

Before running it, you may need to mex the two .c files. Commands are as follows:

	mex l2matrix.c
	mex find_nd.c

Good Luck !!


Rui Wang (ruiwangnudt@gmail.com)

Ref: Wang, R., Zhang, Q. F., Zhang, T., Decomposition based algorithms 
using Pareto adaptive scalarizing methods, IEEE Transactions on Evolutionary 
Computation, IEEE, 2015, To appear 

