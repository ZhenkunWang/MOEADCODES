function degreeMatrix = angleSW(NormJointF,jointW)
[jointFnum,M] = size(NormJointF);
[jointWnum,M] = size(jointW);

JointFD = NormJointF./rep(sum(NormJointF,2),[1,M]);
degreeMatrix=zeros(jointFnum,jointWnum);
for iw = 1:jointWnum
    vector1 = rep(jointW(iw,:),[jointFnum,1]);
    vector2 = JointFD;
    nomv1 = vector1./rep(sqrt(sum(vector1.^2,2)),[1,M]);
    nomv2 = vector2./rep(sqrt(sum(vector2.^2,2)),[1,M]);
    xtheta = acosd(sum(nomv1.*nomv2,2));
    degreeMatrix(:,iw) = xtheta;
end
end


