You should run Main_MOEADLWS.m to see the performance of MOEA.D-LWS.

Before running it, you may need to mex the two .c files. Commands are as follows:

	mex l2matrix.c
	mex find_nd.c

Good Luck !!


Rui Wang (ruiwangnudt@gmail.com)

