%% Source code of MOEAD-LWS
% Paper : Localised weighted sum method for multi objective optimization}
% By Rui Wang, Zhong bao Zhou, Hisao Ishibuchi, Tian jun Liao, Tao Zhang
% Abstract
% Decomposition via scalarization is a basic concept for multi-objective
% optimization. The weighted sum method, as a frequently used scalarizing method
% in decomposition based evolutionary multi-objective (EMO) algorithms, has
% good features such as computationally easy, high search efficiency,
% compared to other $L_p$ scalarizing methods. However, it is often
% criticized by the loss of effect on non-convex problems. This study seeks
% to utilize advantages of the weighted sum method for solving many-objective
% problems. A novel decomposition based EMO algorithm called MOEA/D-LWS is
% proposed in which the weighted sum method is applied in a local manner.
% That is, for each search direction, the  optimal solution is selected
% only amongst its neighboring solutions.
% The neighborhood is defined using a cone. The cone angle is determined
% automatically in \textit{a priori}. The effectiveness of MOEA/D-LWS is
% demonstrated by comparing it against three variants of MOEA/D, i.e.,
% MOEA/D using Chebyshev method, MOEA/D with an adaptive use of weighted sum
% and Chebyshev method, MOEA/D with a simultaneous use of weighted sum and
% Chebyshev method, and three state-of-the-art many-objective EMO algorithms,
% i.e., PICEA-g, HypE and $\theta$-DEA for the WFG benchmark problems with up
% to seven conflicting objectives. Experimental results show that MOEA/D-LWS
% outperforms the comparison algorithms for most of test problems, and is a
% competitive algorithm for many-objective optimization.
%
%%
% Created by Rui Wang, National University of Defense Technology, Changsha,
% Hu nan, P.R. China.
% Email: ruiwangnudt@gmail.com

clear all; close all; clc
warning off all
%% Parameter settings
maxGen = 100;
testNo = 4; M = 2; N = 210;
T = max([10,N*0.1]); 
% generate search directions
for i = 1:1
    if 1==1 % Qingfu method
        H = 99;
        SD = combn(0:1:H,M);
        SD = SD(logical(sum(SD,2)==H),:);  % filter rows whose sum is 1
        SD = SD/H;
        
    else % Hughes method
        disp('Generating target vectors')
        wmtx=vspace(nwt,M);   % create target weight vector set for msops.
        save (['wmtx',num2str(M)], 'wmtx');
        figure(3001)
        plot(wmtx')
        grid
        xlabel('objective')
        ylabel('magnitude')
        title('target vectors')
        SD = wmtx;
    end
end
% Search directions TO weights
jointWD = SD;
jointWD = jointWD./rep(sum(jointWD,2),[1,M]);
jointWnum = size(jointWD,1);
jointFnum = jointWnum;
% neighbours between weights
WdegreeMatrix = neighboringWW(jointWD,T);
% WFG problem configuration
nVar = 100; k = 6; l = nVar-k;  
% bounds of decison variables
bounds=[zeros(1, nVar); 2*(1:nVar)];
% range the PF shape
s_bounds = 2*ones(1,M);
% plot setting
hf = figure;
set (gcf,'Position',[400,150,800,400])
Fbounds = 1.2*s_bounds;
%% Search process
wofw = angleSW(jointWD,jointWD);
sortedwofw = sort(wofw);
wZoneDef = (mean(sortedwofw(2:M+1,:)));
bestobjv = Inf*ones(1,M);
Normbestobjv = Inf*ones(1,M);
bestphen = NaN*ones(1,nVar);
z = -0.00001;
jointW = 1./(jointWD+0.0000001);
jointW = jointW./rep(sum(jointW,2),[1,M]);
jointP = crtrp(jointFnum,bounds);
jointF = wfgextend(jointP, M, k, l, testNo,s_bounds);

for gen = 1:maxGen
    %wZone = 5*wZoneDef-4*wZoneDef*(gen/maxGen);
    wZone = wZoneDef;
    tempjointP = jointP; tempjointF = jointF;
    for i = 1:jointWnum
        if rand<0.8
            neighborWix = WdegreeMatrix(i,:);
            ix = randperm(T);
            varix = neighborWix(ix(1:2));
        else
            ix = randperm(jointWnum);
            varix = ix(1:2);
        end
        tempP = tempjointP(varix,:);
        tempP = sbx_sal(tempP, bounds, 15, 0, 1, 1,0.5);
        tempP = polymut_sal(tempP, bounds, 20, 1/nVar);
        newjointP(i,:) = tempP(1,:);
    end
    newjointF = wfgextend(newjointP, M, k, l, testNo,s_bounds);
    
    jointPall = [jointP;newjointP];
    jointFAll = [jointF;newjointF];
    normjointFAll = normliseData(jointFAll,jointFAll);
    for iwindex = 1:jointWnum
        scalarMatrix(:,iwindex)  =  sum(rep(jointW(iwindex,:),[2*jointFnum,1]).* abs(normjointFAll-z), 2);
    end
    neiSofW = angleSW(normjointFAll,jointWD);
    labelSofW = neiSofW<rep(wZone,[2*jointFnum,1]);
    numSofW = sum(labelSofW);
    % condition for set cloumns as true
    if 1==0
        omittedIx = find(numSofW<2);
        %omittedIx = find(numSofW==0);
        tempMatrix = neiSofW(:,omittedIx);
        [value,indexx] = sort(tempMatrix);
        temp = labelSofW(:,omittedIx);
        % set the first end closest solutions to current w as ture
        temp(indexx(1:2,:)) = 1;
        labelSofW(:,omittedIx) = temp;
    end
    newscalarMatrix = scalarMatrix.*labelSofW;
    newscalarMatrix(newscalarMatrix ==0) = max(max(newscalarMatrix))+1;
    switch 1
        case 1 % new offspring solution can replace all satisfied solutions
            [value,indexSofW] = min(newscalarMatrix,[],1);
            jointP = jointPall(indexSofW,:);
            %tempjoint = unique(jointP,'rows');
            jointF = jointFAll(indexSofW,:);
            normjointF = normjointFAll(indexSofW,:);
        case 2 % replacement MOEA/D-LWS variants
            nr = 2; %max([T*0.2,2]);
            markSel = zeros(2*jointWnum,1);
            rndixlist = randperm(N);
            for ii = 1:jointWnum
                ijointw = rndixlist(ii);
                [value,minix] = min(newscalarMatrix(:,ijointw));
                markSel(minix) = markSel(minix)+1;
                temp = markSel(minix);
                if temp<=nr
                    jointF(ijointw,:) = jointFAll(minix,:);
                    jointP(ijointw,:) = jointPall(minix,:);
                    normjointF(ijointw,:) = normjointFAll(minix,:);
                else
                    while(temp>nr)
                        newscalarMatrix(minix,:) = 100000;
                        [value,minix] = min(newscalarMatrix(:,ijointw));
                        markSel(minix) = markSel(minix)+1;
                        temp = markSel(minix);
                    end
                    jointF(ijointw,:) = jointFAll(minix,:);
                    jointP(ijointw,:) = jointPall(minix,:);
                    normjointF(ijointw,:) = normjointFAll(minix,:);
                end
            end
    end
    %% show the results
    for offlinei = 1:1
        Cobjvix = find_nd(jointF);
        Hobjv =  jointF(logical(Cobjvix),:);
        NormHobjv =  normjointF(logical(Cobjvix),:);
        HP = jointP(logical(Cobjvix),:);
        
        [ix,bestix] = find_nd(Hobjv,bestobjv);
        bestobjv = [bestobjv(logical(bestix),:) ; Hobjv(logical(ix),:)];
        Normbestobjv = [Normbestobjv(logical(bestix),:) ; NormHobjv(logical(ix),:)];
        bestphen = [bestphen(logical(bestix),:) ; HP(logical(ix),:)];
        bestNum = size(bestobjv,1);
        if bestNum>N
            [bestobjv,index] = reducer(bestobjv, M, N);
            Normbestobjv = Normbestobjv(index,:);
            bestphen = bestphen(index,:);
        end
    end
    showHobjv = Hobjv; showbestobjv = bestobjv; showjointW = jointWD;
    %% Plot the results
    for i= 1:1
        subplot(121)
        plot(showHobjv(:,1), showHobjv(:,2), 'o',showjointW(:,1),showjointW(:,2),'.'), axis square
        grid on
        subplot(122)
        plot(showbestobjv(:,1), showbestobjv(:,2), 'o'),  axis square
        grid on
    end
    drawnow
end

