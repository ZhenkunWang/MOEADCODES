sprintf('build IH metric')
mex IH.cpp;

S = zeros(2,100);
Q = zeros(2,100);
Q(1,:) = 1 + sin(linspace(pi,1.5*pi,100));
Q(2,:) = 1 + cos(linspace(pi,1.5*pi,100));
% S(1,:) = 1.2 + sin(linspace(pi,1.5*pi,100));
% S(2,:) = 1.2 + cos(linspace(pi,1.5*pi,100));
% S = S + randn(2,100)*0.05;
S(1,:) = 1.03 + sin(linspace(pi,1.5*pi,100));
S(2,:) = 1.03 + cos(linspace(pi,1.5*pi,100));
S = S + randn(2,100)*0.02;

m4=IH(S,[10 10]')