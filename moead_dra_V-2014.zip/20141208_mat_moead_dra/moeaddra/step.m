function step(mop)

global params population;

    % utility select
    subindex = utility_select();
    % random permulate selected index
    rndi     = randperm(length(subindex));
    subindex = subindex(rndi);
    params.fes = params.fes + length(subindex);
    
    for i=1:length(subindex)
        %dynamic neighborhood
        if rand() < params.pns
            neighborhood = population.neighbor(1:params.niche,subindex(i));
        else
            neighborhood = 1:params.popsize;
        end

        %new point generation using genetic operations, and evaluate it.
        ind     = de(subindex(i), neighborhood);
        obj     = evaluate(mop, ind);
        
        %update the idealpoint.
        population.ideapoint  = min(population.ideapoint, obj);

        %update the neighbours.
        update(obj, ind, neighborhood);
    end
    
    % update utility
    if mod(params.iter, params.upint) == 0
        utility_update();   
    end 
    
    % update iterate counter
    params.iter = params.iter + 1;
    
    clear subindex rndi ind obj neighbourhood;
end

%%
function update(obj, parameter, neighborhood)
%updating of the neighborindex with the given new individuals
global params population;
    
    %objective values of current solution
    newobj  = subobjective(population.W(:,neighborhood), obj, population.ideapoint, params.dmethod);
    %previous objective values
    oldobj  = subobjective(population.W(:,neighborhood), population.objective(:,neighborhood), population.ideapoint, params.dmethod);    
    %new solution is better?
    C       = newobj < oldobj; 
    
    %repace with the new one
    if (length(C(C==1)) <= params.updatesize)
        toupdate = neighborhood(C);
    else
        toupdate = randsample(neighborhood(C), params.updatesize);
    end    
    population.parameter(:,toupdate) = repmat(parameter, 1, size(toupdate));
    population.objective(:,toupdate) = repmat(obj, 1, size(toupdate)); 
    clear subp newobj oops oldobj C toupdate;
end

%%
function ind = de(index, neighborhood)

global population params;
    %parents
    si      = ones(1,3)*index;
    while si(2)==si(1) || si(3)==si(1) || si(3)==si(2)
        si(2:3) = randsample(neighborhood, 2);
    end

    %retrieve the individuals.
    selectpoints    = population.parameter(:, si);

    %generate new trial point
    newpoint        = selectpoints(:,1)+params.F*(selectpoints(:,2)-selectpoints(:,3));

    %repair the new value
    rnds            = rand(params.xdim,1);
    pos             = newpoint>params.xupp;
    if sum(pos)>0
        newpoint(pos) = selectpoints(pos,1) + rnds(pos,1).*(params.xupp(pos)-selectpoints(pos,1));
    end
    pos             = newpoint<params.xlow;
    if sum(pos)>0
        newpoint(pos) = selectpoints(pos,1) - rnds(pos,1).*(selectpoints(pos,1)-params.xlow(pos));
    end
    
    ind             = realmutate(newpoint, params.pm);

    clear si selectpoints newpoint pos;
end

%%
function ind = realmutate(ind, rate)
%REALMUTATE Summary of this function goes here
%   Detailed explanation goes here
global params;

    eta_m = params.etam;

    for j = 1:params.xdim
      r = rand();
      if (r <= rate) 
        y       = ind(j);
        yl      = params.xlow(j);
        yu      = params.xupp(j);
        delta1  = (y - yl) / (yu - yl);
        delta2  = (yu - y) / (yu - yl);

        rnd     = rand();
        mut_pow = 1.0 / (eta_m + 1.0);
        if (rnd <= 0.5) 
          xy    = 1.0 - delta1;
          val   = 2.0 * rnd + (1.0 - 2.0 * rnd) * (xy^(eta_m + 1.0));
          deltaq= (val^mut_pow) - 1.0;
        else 
          xy    = 1.0 - delta2;
          val   = 2.0 * (1.0 - rnd) + 2.0 * (rnd - 0.5) * (xy^ (eta_m + 1.0));
          deltaq= 1.0 - (val^mut_pow);
        end

        y   = y + deltaq * (yu - yl);
        if y < yl, y = yl; end
        if y > yu, y = yu; end

        ind(j) = y;        
      end
    end
end

%%
function index = utility_select()

global population params

if params.utility < 1
    index = 1:params.popsize;
    return;
end

% extreme subproblems are always selected
[~,index]   = max(population.W,[],2);
index       = index';

% candidate index
cindex      = 1:params.popsize;
cindex      = setdiff(cindex, index);

while(length(index)<params.searchsize)
    is      = cindex(ceil(rand(1,params.poolsize)*length(cindex)));
    [~,ib]  = max(population.utility(is));
    ib      = is(ib);
    index   = [index,ib];
    cindex  = setdiff(cindex, index);
end
end

%%
function utility_update()

global params population popold

% current objective values
newobj  = subobjective(population.W, population.objective, population.ideapoint, params.dmethod);
% previous objective values
oldobj  = subobjective(population.W, popold.objective, population.ideapoint, params.dmethod);    
% objective changes
delta   = (oldobj - newobj)./abs(oldobj);
% set the ones to be 1
pos     = delta >= params.threshold;
population.utility(pos) = 1.0;
% descrease the ones
pos     = delta < params.threshold;
if any(pos)
    utility = (0.95 + 0.05*delta/params.threshold).*population.utility;
    population.utility(pos) = utility(pos);
end

%back up the old optimal values.
popold.objective    = population.objective;

end