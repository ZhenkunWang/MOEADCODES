function stas(pp)

path('../problem',path); 
path('../problem/cec09',path); 
path('../public',path);

paras = [20 40 60 80 20 40 60 80 20 40 60 80 20 40 60 80;
         0 0.05 0.1 0.2 0 0.05 0.1 0.2 0 0.05 0.1 0.2 0 0.05 0.1 0.2];   

problems = {'tec09_f1','tec09_f2','tec09_f3','tec09_f4','tec09_f5','tec09_f6','tec09_f7','tec09_f8','tec09_f9',...
            'uf1','uf2','uf3','uf4','uf5','uf6','uf7',...
            'uf8','uf9','uf10',...
            'r2_dtlz2_m5', 'r3_dtlz3_m5', 'wfg1_m5'};
pops     = [300 300 300 300 300 600 300 300 300 ...
            600 600 600 600 600 600 600 ...
            1500 1500 1500];
fes      = 300000;
runs     = 10;

for i=1:length(pp)
    for r=1:runs
        run_dra0(char(problems(pp(i))), 30, fes, pops(pp(i)), r);
        str = sprintf('%s %s : DRA0', datestr(clock), char(problems(pp(i))));
        disp(str);
        for h=1:16
            run_dra1(char(problems(pp(i))), 30, fes, pops(pp(i)), r, paras(1,h), paras(2,h), h);
        end
        str = sprintf('%s %s : DRA%d', datestr(clock), char(problems(pp(i))),h);
        disp(str);        
    end
end

end

%%
function run_dra1(problem, dim, fes, popsize, run, hno, pgs, mindex)

global params population

params  = [];

mop     = testmop(problem, dim);

iinit('problem', mop, 'popsize', popsize, 'niche', 30, 'pns', 0.9, 'F', 0.5, 'pgs', pgs,'hno', hno, 'method', 'ts', 'updatesize', 2);

it      = 0;

df      = [];
ds      = [];
while params.fes < fes
    istep(mop);
    
    if params.fes >= it*10000 
%         sname = sprintf('data/dra%d_%s_%d_%d',mindex, problem, run, it);
%         savedata(sname);
        it    = it+1;
        df    = [df; population.objective'];
        ds    = [ds; population.parameter'];
    end
end
sname = sprintf('data/dra%d_%s_%d',mindex, problem, run);
save(sname, 'df', 'ds');
end

%%
function run_dra0(problem, dim, fes, popsize, run)

global params population

params  = [];

mop     = testmop(problem, dim);

init('problem', mop, 'popsize', popsize, 'niche', 30, 'pns', 0.9, 'F', 0.5, 'method', 'ts', 'updatesize', 2);

it      = 0;
df      = [];
ds      = [];
while params.fes < fes
    step(mop);
    
    if params.fes >= it*10000 
%         sname = sprintf('data/dra0_%s_%d_%d', problem, run, it);
%         savedata(sname);
        it    = it+1;
        df    = [df; population.objective'];
        ds    = [ds; population.parameter'];        
    end
end
sname = sprintf('data/dra0_%s_%d', problem, run);
save(sname, 'df', 'ds');
end


% %%
% function savedata(name)
% global population;
% 
% df      = population.objective'; 
% ds      = population.parameter'; 
% 
% save(name, 'df', 'ds');
% 
% clear pareto df ds;
% end