function sta_dra(rs)

path('../problem',path); 
path('../public',path);
folder  = '../moeaddra2_20141215/data';
problems = {'tec09_f1','tec09_f2','tec09_f3','tec09_f4','tec09_f5','tec09_f6','tec09_f7','tec09_f8','tec09_f9',...
            'uf1','uf2','uf3','uf4','uf5','uf6','uf7','uf8','uf9','uf10'};%'r2_dtlz2_m5', 'r3_dtlz3_m5', 'wfg1_m5'};
dims     = [30,30,30,30,30,30,30,30,30, ...
            30,30,30,30,30,30,30,30,30,30,30,30,30];
pops     = [300 300 300 300 300 600 300 300 300 ...
            600 600 600 600 600 600 600 600 600 600 ...
            1500 1500 1500];
fes      = [150000 150000 150000 150000 150000 300000 150000 150000 150000 ...
            300000 300000 300000 300000 300000 300000 300000 300000 300000 300000 300000 300000 300000];

for r=1:length(rs)
    for i=1:length(problems)
        run_dra(char(problems(i)), 30, fes(i), pops(i), rs(r), folder)
        str = sprintf('DRA\t %s %s %d', datestr(clock), char(problems(i)), rs(r));
        disp(str);
    end
end

end

%%
function run_dra(problem, dim, maxfes, popsize, run, folder)

global params population

params  = [];

tic;
mop     = testmop(problem, dim);
init('problem', mop, 'popsize', popsize, 'niche', 0.1*popsize, 'pns', 0.9, 'F', 0.5, 'method', 'ts', 'updatesize', 0.01*popsize);

it      = 0;
df      = [];
ds      = [];
fes     = [];
while params.fes < maxfes
    step(mop);
    if params.fes >= it*1000
        it    = it+1;
        df    = [df; population.objective'];
        ds    = [ds; population.parameter'];
        fes   = [fes,params.fes];
    end
end
endt    = toc;
sname = sprintf('%s/%s_%s_%d', folder, 'DRA', problem, run);
save(sname, 'df', 'ds', 'fes', 'endt');

end