function init(varargin)

global params population popold

    % call global init function
    initpub(varargin);
    
    % Set up the initial setting for the MOEA/D
    %the parameter for the DE.
    params.F 	= 0.5;

    %handle the parameters, mainly about the popsize        
    for k=1:2:length(varargin)
        switch varargin{k}
            case 'F'
                params.F = varargin{k+1};
        end
    end
    params.pm   = 1.0/params.xdim;
    
    % init old population
    popold.objective = population.objective;
    
    % init utility values
    population.utility = ones(1, params.popsize);
    
    params.fes          = 0;
    
    params.iter         = 0;
    params.utility      = 1;
    params.searchsize   = ceil(0.2*params.popsize);
    params.poolsize     = 10;
    params.threshold    = 0.001;
    params.upint        = 50;
end
