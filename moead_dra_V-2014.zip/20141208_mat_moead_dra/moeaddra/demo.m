function demo(problem)

global params;

path('../problem',path); 
path('../public',path);

%problem = 'tec09_f3';

mop     = testmop(problem, 30);
popsize = 300;
maxfes  = 150000;

tic;
init('problem', mop, 'popsize', popsize, 'niche', 0.1*popsize, 'pns', 0.9, 'F', 0.5, 'method', 'ts', 'updatesize', 0.01*popsize);
g = 1;
while params.fes < maxfes
    step(mop);
    updateplot(g);
    g = g + 1;
end
endt    = toc;
disp(endt); 

end

%%
function updateplot(gen)

global population;

df      = population.objective; df = df';
ds      = population.parameter; ds = ds';
str     = sprintf('gen=%d', gen);

hold off; 
subplot(1,2,1);
if size(df,2) == 2
    plot(df(:,1), df(:,2), 'ro', 'MarkerSize',4);
    xlabel('f1', 'FontSize', 6);
    ylabel('f2', 'FontSize', 6);
else
    plot3(df(:,1), df(:,2), df(:,3), 'ro', 'MarkerSize',4);
    xlabel('f1', 'FontSize', 6);
    ylabel('f2', 'FontSize', 6);
    zlabel('f3', 'FontSize', 6);
end
title(str, 'FontSize', 8);
box on;
drawnow;

subplot(1,2,2);
if size(ds,2) >= 3
    plot3(ds(:,1), ds(:,2), ds(:,3), 'ro', 'MarkerSize',4);
    xlabel('x1', 'FontSize', 6);
    ylabel('x2', 'FontSize', 6);
    zlabel('x3', 'FontSize', 6);    
elseif size(ds,2) >= 2
    plot(ds(:,1), ds(:,2), 'ro', 'MarkerSize',4);
    xlabel('x1', 'FontSize', 6);
    ylabel('x2', 'FontSize', 6);
end
box on;
drawnow;
clear pareto df ds;
end