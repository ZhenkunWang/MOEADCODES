#include "GlobalObject.h"


CTestInstance    TestInstance;
CUtilityToolBox  UtilityToolBox;