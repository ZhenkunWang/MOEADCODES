
#include "TestInstance.h"
#include "UtilityToolBox.h"


extern CUtilityToolBox  UtilityToolBox;
extern CTestInstance    TestInstance;