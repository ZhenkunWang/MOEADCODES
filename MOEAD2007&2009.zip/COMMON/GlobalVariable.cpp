#include "GlobalVariable.h"

char  strTestInstance[1024];
char  strCrossOverType[1024];

long  rnd_uni_init;      
int   rnd_uni_seed;


int   NumberOfVariables;
int   NumberOfObjectives;
int   NumberOfFuncEvals;


